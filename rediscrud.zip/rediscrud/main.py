"""
contact-metadata-service
------------------------
Cloud Run service that stores per-contact metadata in Redis (Memorystore).

Storage model:
  - Key:   user:{contact_number}          (prefix configurable via KEY_PREFIX)
  - Type:  Redis hash — HSET merges fields natively, so repeated POSTs
           update/add fields without clobbering the rest.
  - Values: every field value is JSON-encoded on write and JSON-decoded on
           read, so ints, bools, nested objects and lists round-trip cleanly.
  - TTL:   rolling 2 hours (refreshed on every write), matching the rest of
           the pipeline. Configurable via METADATA_TTL_SECONDS.

Agent ownership:
  - Every POST must include an "agent_id" field — this marks which agent
    owns the contact.
  - Fetch/delete require ?agent_id=... and only succeed when it matches the
    stored one; otherwise 409 (contact is on a call with another agent).

Endpoints:
  POST   /metadata                                   -> store/merge metadata (contact_number + agent_id in body)
  GET    /metadata/{contact_number}?agent_id=...     -> fetch full metadata as JSON (ownership-checked)
  DELETE /metadata/{contact_number}?agent_id=...     -> remove metadata (ownership-checked)
  GET    /health                                     -> liveness + Redis ping
"""

import json
import logging
import os
import re
from contextlib import asynccontextmanager
from typing import Any

import redis.asyncio as redis
from fastapi import FastAPI, HTTPException, Request

# --------------------------------------------------------------------------
# Config
# --------------------------------------------------------------------------
REDIS_HOST = os.environ.get("REDIS_HOST", "localhost")
REDIS_PORT = int(os.environ.get("REDIS_PORT", "6379"))
KEY_PREFIX = os.environ.get("KEY_PREFIX", "user")
METADATA_TTL_SECONDS = int(os.environ.get("METADATA_TTL_SECONDS", "7200"))  # 2h

# Accepts optional +, 7-15 digits (E.164-ish). Loosen/tighten as needed.
CONTACT_NUMBER_PATTERN = re.compile(r"^\+?\d{7,15}$")

logging.basicConfig(
    level=logging.INFO,
    format='{"severity": "%(levelname)s", "message": "%(message)s"}',
)
logger = logging.getLogger("contact-metadata-service")

# --------------------------------------------------------------------------
# App / Redis lifecycle
# --------------------------------------------------------------------------
redis_client: redis.Redis | None = None


@asynccontextmanager
async def lifespan(app: FastAPI):
    global redis_client
    redis_client = redis.Redis(
        host=REDIS_HOST,
        port=REDIS_PORT,
        decode_responses=True,
        socket_connect_timeout=5,
        socket_timeout=5,
        health_check_interval=30,
    )
    logger.info(f"Redis client configured for {REDIS_HOST}:{REDIS_PORT}")
    yield
    await redis_client.aclose()
    logger.info("Redis client closed")


app = FastAPI(title="contact-metadata-service", lifespan=lifespan)


# --------------------------------------------------------------------------
# Helpers
# --------------------------------------------------------------------------
def make_key(contact_number: str) -> str:
    return f"{KEY_PREFIX}:{contact_number}"


def normalize_contact_number(raw: Any) -> str:
    """Validate and normalize the contact number (strip spaces/dashes)."""
    if raw is None:
        raise HTTPException(status_code=400, detail="contact_number is required")
    number = re.sub(r"[\s\-()]", "", str(raw))
    if not CONTACT_NUMBER_PATTERN.match(number):
        raise HTTPException(
            status_code=400,
            detail="contact_number must be 7-15 digits (optional leading +)",
        )
    return number


def encode_fields(data: dict[str, Any]) -> dict[str, str]:
    """JSON-encode every value so types survive the round trip."""
    return {k: json.dumps(v) for k, v in data.items()}


def decode_fields(data: dict[str, str]) -> dict[str, Any]:
    """JSON-decode hash values; fall back to raw string for legacy data."""
    out: dict[str, Any] = {}
    for k, v in data.items():
        try:
            out[k] = json.loads(v)
        except (json.JSONDecodeError, TypeError):
            out[k] = v
    return out


async def verify_agent_ownership(key: str, contact_number: str, agent_id: str | None) -> dict[str, str]:
    """
    Fetch the hash and enforce agent ownership.
    Returns the raw hash data if the requesting agent owns the contact.
    """
    if not agent_id or not str(agent_id).strip():
        raise HTTPException(
            status_code=400,
            detail="agent_id is required. Provide it as a query parameter, e.g. ?agent_id=AG123",
        )
    agent_id = str(agent_id).strip()

    try:
        data = await redis_client.hgetall(key)
    except redis.RedisError as e:
        logger.error(f"Redis read failed for {key}: {e}")
        raise HTTPException(status_code=503, detail="Redis unavailable")

    if not data:
        raise HTTPException(
            status_code=404,
            detail=f"No data available for contact number {contact_number}",
        )

    stored_raw = data.get("agent_id")
    if stored_raw is None:
        raise HTTPException(
            status_code=409,
            detail="No agent is assigned to this contact yet",
        )
    try:
        stored_agent = json.loads(stored_raw)
    except (json.JSONDecodeError, TypeError):
        stored_agent = stored_raw

    if str(stored_agent) != agent_id:
        logger.warning(
            f"Ownership mismatch for {key}: requested by agent {agent_id}, "
            f"owned by another agent"
        )
        raise HTTPException(
            status_code=409,
            detail="This user is already on a call with another agent",
        )

    return data


# --------------------------------------------------------------------------
# Routes
# --------------------------------------------------------------------------
@app.post("/metadata", status_code=200)
async def store_metadata(request: Request):
    """
    Store/merge metadata for a contact number.

    Body: JSON object containing "contact_number" plus arbitrary metadata
    fields. Existing fields are updated, new fields are added, fields not
    present in the request are left untouched (merge semantics).
    """
    try:
        body = await request.json()
    except json.JSONDecodeError:
        raise HTTPException(status_code=400, detail="Request body must be valid JSON")

    if not isinstance(body, dict):
        raise HTTPException(status_code=400, detail="Request body must be a JSON object")

    contact_number = normalize_contact_number(body.pop("contact_number", None))

    agent_id = body.get("agent_id")
    if agent_id is None or not str(agent_id).strip():
        raise HTTPException(
            status_code=400,
            detail="agent_id is required in the request body",
        )
    body["agent_id"] = str(agent_id).strip()

    if len(body) == 1:  # only agent_id, no actual metadata
        raise HTTPException(
            status_code=400,
            detail="No metadata fields provided besides contact_number and agent_id",
        )

    key = make_key(contact_number)
    try:
        existed = await redis_client.exists(key)
        pipe = redis_client.pipeline(transaction=True)
        pipe.hset(key, mapping=encode_fields(body))
        pipe.expire(key, METADATA_TTL_SECONDS)  # rolling TTL, refreshed on write
        await pipe.execute()
    except redis.RedisError as e:
        logger.error(f"Redis write failed for {key}: {e}")
        raise HTTPException(status_code=503, detail="Redis unavailable")

    logger.info(
        f"{'Merged' if existed else 'Created'} metadata for {key} "
        f"({len(body)} field(s))"
    )
    return {
        "status": "merged" if existed else "created",
        "contact_number": contact_number,
        "fields_written": sorted(body.keys()),
        "ttl_seconds": METADATA_TTL_SECONDS,
    }


@app.get("/metadata")
async def get_metadata_missing_number():
    """Friendly error when the contact number is missing from the URL."""
    raise HTTPException(
        status_code=400,
        detail="Contact number is required. Use GET /metadata/{contact_number}?agent_id=...",
    )


@app.get("/metadata/{contact_number}")
async def get_metadata(contact_number: str, agent_id: str | None = None):
    """
    Return the full metadata object for a contact number.

    Requires ?agent_id=... — data is only returned when it matches the
    agent_id stored with this contact; otherwise the contact is considered
    on a call with another agent (409).
    """
    contact_number = normalize_contact_number(contact_number)
    key = make_key(contact_number)

    data = await verify_agent_ownership(key, contact_number, agent_id)
    return {"contact_number": contact_number, "metadata": decode_fields(data)}


@app.delete("/metadata/{contact_number}")
async def delete_metadata(contact_number: str, agent_id: str | None = None):
    """Delete all metadata for a contact number (owning agent only)."""
    contact_number = normalize_contact_number(contact_number)
    key = make_key(contact_number)

    # Enforce the same ownership rule before deleting
    await verify_agent_ownership(key, contact_number, agent_id)

    try:
        await redis_client.delete(key)
    except redis.RedisError as e:
        logger.error(f"Redis delete failed for {key}: {e}")
        raise HTTPException(status_code=503, detail="Redis unavailable")

    return {"status": "deleted", "contact_number": contact_number}


@app.get("/health")
async def health():
    """Liveness check including Redis connectivity."""
    try:
        await redis_client.ping()
        return {"status": "ok", "redis": "connected"}
    except Exception as e:
        logger.error(f"Health check failed: {e}")
        raise HTTPException(status_code=503, detail="Redis unreachable")