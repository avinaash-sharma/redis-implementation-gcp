"""
ADT Pub/Sub Interceptor: Cloud Run entrypoint (`uvicorn main:app`).

Dialogflow publishes conversation events to Pub/Sub; push subscriptions POST
them here. Each event is buffered in Redis (keyed by the SHORT conversation
id) and live-published to the UI-connector instance serving that conversation.

  main.py       builds the app
  routes.py     HTTP endpoints
  handlers.py   what happens to each event, including the end-of-call summary
  functions.py  config + building blocks (Redis ops, keys, message shapes, id parsing)
  utils.py      shared structured logging (level from ENVIRONMENT)

Imports only point downward (routes → handlers → functions → utils), so
there are no circular imports.
"""

from fastapi import FastAPI

from routes import admin_router, health_router, intercept_router

app = FastAPI(title="Pub/Sub Interceptor")
app.include_router(health_router)
app.include_router(intercept_router)
app.include_router(admin_router)  # debug only; drop this line before TST
