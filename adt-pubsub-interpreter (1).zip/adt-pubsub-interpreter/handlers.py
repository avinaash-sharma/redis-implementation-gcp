"""
Everything that reacts to an event.

  1. process_envelope    Pub/Sub push envelope → decode → log → persist → publish
  2. Per-data_type rules what each event type writes to Redis before the publish
  3. Summary flow        call ended → suggestConversationSummary → Redis + live channel

process_envelope always returns True (ack). A non-2xx response makes Pub/Sub
redeliver, and a message this service can't process now won't be processable
on retry either, so bad input is logged and dropped.
"""

import base64
import json
import time
import traceback
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from threading import Lock
from typing import Optional

from functions import (
    BUFFER_AGENT_ASSIST,
    CONVERSATION_DATA_TTL_SECONDS,
    DIALOGFLOW_LOCATION,
    GCP_PROJECT_ID,
    LOG_SUGGESTION_TYPES,
    SUMMARY_CONTEXT_SIZE,
    SUMMARY_INITIAL_DELAY_SECONDS,
    SUMMARY_INLINE,
    SUMMARY_MAX_ATTEMPTS,
    SUMMARY_ON_END,
    SUMMARY_RETRY_BACKOFF_SECONDS,
    SUMMARY_TRIGGER_STATUSES,
    SUMMARY_WORKERS,
    DataType,
    acquire_summary_lock,
    append_turn,
    build_event_message,
    build_summary_message,
    display_name,
    extract_conversation_path,
    extract_short_conversation_id,
    get_dialogflow_client,
    get_meta_field,
    has_summary,
    publish_live,
    release_summary_lock,
    suggestion_errors,
    suggestion_types,
    summary_to_dict,
    update_meta,
    utc_now,
)
from utils import log_debug, log_error, log_info, log_metric, log_warning

_PUBSUB_MESSAGE_DOCS = "https://cloud.google.com/pubsub/docs/reference/rest/v1/PubsubMessage"


@dataclass(frozen=True)
class Event:
    conversation_id: str   # SHORT id; every Redis key is built from this
    data_type: str
    data: dict             # decoded Pub/Sub payload
    message: dict          # envelope sent to the connector (build_event_message)
    encoded: str           # json.dumps(message): buffered and published byte-for-byte
    participant_role: str = ""


# ══════════════════════════════════════════════════════════════════════════════
# 1. process_envelope
# ══════════════════════════════════════════════════════════════════════════════
#
# Each stage is guarded separately so that neither logging nor buffering can
# ever stop the live publish.

def process_envelope(envelope, data_type: str) -> bool:
    try:
        pubsub_message = _unwrap_envelope(envelope)
        if pubsub_message is None:
            return True

        data = _decode_data(pubsub_message)
        if data is None:
            return True

        conversation_id = extract_short_conversation_id(data)
        if not conversation_id:
            log_warning(
                "Cannot extract conversation id from Pub/Sub payload",
                data_type=data_type,
                payload_keys=list(data.keys()),
            )
            return True

        event = _build_event(conversation_id, data_type, data, pubsub_message)
        _log_event(event)
        _persist(event)
        _publish(event)
    except Exception as err:
        log_error(
            "Unhandled error while processing Pub/Sub envelope",
            data_type=data_type,
            error=str(err),
            traceback=traceback.format_exc(),
        )
    return True


def _unwrap_envelope(envelope) -> Optional[dict]:
    """Returns the inner PubsubMessage, or None (logged) if the envelope is unusable."""
    if not envelope:
        log_warning("No Pub/Sub message received")
        return None
    if not isinstance(envelope, dict) or "message" not in envelope:
        log_warning("Invalid Pub/Sub envelope; missing 'message'")
        return None

    message = envelope["message"]
    if not isinstance(message, dict):
        log_warning("Invalid Pub/Sub message; 'message' must be a JSON object", docs=_PUBSUB_MESSAGE_DOCS)
        return None
    if "data" not in message:
        log_warning("Pub/Sub message has no 'data' field", message_id=message.get("messageId"))
        return None
    return message


def _decode_data(pubsub_message: dict) -> Optional[dict]:
    """base64 → UTF-8 → JSON object, or None (logged) if any step fails."""
    try:
        data = json.loads(base64.b64decode(pubsub_message["data"]).decode("utf-8"))
    except Exception as err:
        log_error(
            "Failed to decode/parse Pub/Sub message data",
            message_id=pubsub_message.get("messageId"),
            error=str(err),
        )
        return None

    if not isinstance(data, dict):
        log_warning(
            "Pub/Sub message data is not a JSON object",
            message_id=pubsub_message.get("messageId"),
            data_kind=type(data).__name__,
        )
        return None
    return data


def _build_event(conversation_id: str, data_type: str, data: dict, pubsub_message: dict) -> Event:
    attributes = pubsub_message.get("attributes")
    if not isinstance(attributes, dict):
        attributes = {}
    participant_role = attributes.get("participant_role", "")

    message = build_event_message(
        conversation_id=conversation_id,
        conversation_name=display_name(data, conversation_id),
        data=data,
        data_type=data_type,
        publish_time=pubsub_message.get("publishTime"),
        message_id=pubsub_message.get("messageId"),
        participant_role=participant_role,
        recognition_message_id=attributes.get("message_id", ""),
    )
    return Event(
        conversation_id=conversation_id,
        data_type=data_type,
        data=data,
        message=message,
        encoded=json.dumps(message),
        participant_role=participant_role,
    )


def _log_event(event: Event) -> None:
    """One summary line at INFO, the full payload at DEBUG. Never raises."""
    try:
        fields = {
            "conversation_id": event.conversation_id,
            "conversation_name": event.message["conversation_name"],
            "data_type": event.data_type,
            "message_id": event.message["message_id"],
            "publish_time": event.message["publish_time"],
            "payload_keys": list(event.data.keys()),
        }
        if event.participant_role:
            fields["participant_role"] = event.participant_role
        if LOG_SUGGESTION_TYPES and event.data_type == DataType.AGENT_ASSIST:
            try:
                fields["suggestion_types"] = suggestion_types(event.data)
                fields["has_summary"] = has_summary(event.data)
            except Exception as err:
                fields["suggestion_introspection_error"] = str(err)

        log_info("Pub/Sub event received", **fields)
        log_debug(
            "Pub/Sub event payload",
            conversation_id=event.conversation_id,
            message_id=event.message["message_id"],
            payload=event.data,
        )
    except Exception as err:
        log_warning("Event logging failed", conversation_id=event.conversation_id, error=str(err))


def _persist(event: Event) -> None:
    """Buffers to Redis regardless of whether a viewer is connected."""
    handler = HANDLERS.get(event.data_type)
    if handler is None:
        return
    try:
        handler(event)
    except Exception as err:
        log_error(
            "Redis persistence (turns/meta) failed",
            conversation_id=event.conversation_id,
            data_type=event.data_type,
            error=str(err),
        )


def _publish(event: Event) -> None:
    """Live-publishes to the connector instance serving this conversation, if any."""
    cid = event.conversation_id
    try:
        published = publish_live(cid, event.encoded)
    except Exception as err:
        log_error("Live publish failed", conversation_id=cid, data_type=event.data_type, error=str(err))
        return

    if published is None:
        log_info(
            "No active viewer (server_id) for conversation; not live-published. "
            "Buffered turns are sent as HISTORY_BATCH on join.",
            conversation_id=cid,
            data_type=event.data_type,
        )
        return

    log_info(
        "Published to live channel",
        conversation_id=cid,
        channel=published.channel,
        message_id=event.message["message_id"],
        data_type=event.data_type,
        subscribers=published.receivers,
    )
    if published.receivers == 0:
        log_warning(
            "Published but ZERO subscribers received it; server_id key exists "
            "but no live subscription on that instance",
            conversation_id=cid,
            channel=published.channel,
        )


# ══════════════════════════════════════════════════════════════════════════════
# 2. Per-data_type rules
# ══════════════════════════════════════════════════════════════════════════════
#
#   new-message                → always buffered to :turns
#   intermediate-transcription → only FINAL results buffered; interims are live-only
#   agent-assist               → buffered only with BUFFER_AGENT_ASSIST
#   conversation-lifecycle     → state in :meta (not a turn); may trigger summary

def handle_new_message(event: Event) -> None:
    # Every chat/text turn is part of the permanent record.
    key = append_turn(event.conversation_id, event.encoded)
    log_info(
        "Buffered turn",
        conversation_id=event.conversation_id,
        key=key,
        ttl_seconds=CONVERSATION_DATA_TTL_SECONDS,
    )


def handle_intermediate_transcription(event: Event) -> None:
    # Interim STT results get revised as more audio arrives, so buffering them
    # would pollute history with stale text. Only the FINAL result for an
    # utterance is kept; interims are still live-published.
    if event.data.get("is_final") or event.data.get("isFinal"):
        key = append_turn(event.conversation_id, event.encoded)
        log_info(
            "Buffered final recognition turn",
            conversation_id=event.conversation_id,
            key=key,
            ttl_seconds=CONVERSATION_DATA_TTL_SECONDS,
        )
    else:
        log_debug("Interim recognition result; live-only, not buffered", conversation_id=event.conversation_id)


def handle_agent_assist(event: Event) -> None:
    # Without buffering, agent-assist events are live-only: anything arriving
    # while no viewer is connected is acked and lost. OFF by default because
    # it puts a NEW entry shape into :turns (see BUFFER_AGENT_ASSIST).
    if not BUFFER_AGENT_ASSIST:
        return

    cid = event.conversation_id
    try:
        for error in suggestion_errors(event.data):
            log_warning("Suggestion error", conversation_id=cid, error=error)
    except Exception as err:
        log_warning("Suggestion error inspection failed", conversation_id=cid, error=str(err))

    key = append_turn(cid, event.encoded)
    log_info("Buffered agent-assist event", conversation_id=cid, key=key)

    try:
        if has_summary(event.data):
            meta = update_meta(cid, {
                "last_summary": json.dumps(event.data),
                "last_summary_at": event.message["ack_time"],
            })
            log_info("Buffered pushed summary", conversation_id=cid, key=meta)
    except Exception as err:
        log_warning("Summary detection failed", conversation_id=cid, error=str(err))


def handle_lifecycle(event: Event) -> None:
    cid = event.conversation_id

    # Real Dialogflow sends `type` (CONVERSATION_FINISHED); the mock publisher
    # sends `status` (ENDED). Reading only one means the other silently no-ops.
    status = event.data.get("type") or event.data.get("status") or ""

    fields = {
        "last_lifecycle_status": status,
        "last_lifecycle_update": event.message["ack_time"],
    }
    # Save the real resource path so the summary call doesn't have to guess
    # project/location. Only written when the payload actually carries it.
    if SUMMARY_ON_END:
        conversation_path = extract_conversation_path(event.data)
        if conversation_path:
            fields["conversation_path"] = conversation_path

    # Rolling TTL. The shortcut TTL for ended calls stays disabled; see functions.py config.
    key = update_meta(cid, fields)
    log_info(
        "Updated meta",
        conversation_id=cid,
        key=key,
        lifecycle_status=status,
        ttl_seconds=CONVERSATION_DATA_TTL_SECONDS,
    )

    if not SUMMARY_ON_END:
        return

    # Call ended → go GET the summary. Guarded so it can never stop the live publish.
    if str(status).upper() not in SUMMARY_TRIGGER_STATUSES:
        # Logged so a payload-shape mismatch is visible instead of a silent no-op.
        log_info(
            "Lifecycle status not in summary trigger set; no summary fetch",
            conversation_id=cid,
            lifecycle_status=status,
            trigger_statuses=sorted(SUMMARY_TRIGGER_STATUSES),
            payload_keys=list(event.data.keys()),
        )
        return
    try:
        log_info("Lifecycle status triggers summary fetch", conversation_id=cid, lifecycle_status=status)
        trigger_summary_fetch(cid, event.data)
    except Exception as err:
        log_error("Summary trigger failed", conversation_id=cid, error=str(err))


HANDLERS = {
    DataType.NEW_MESSAGE: handle_new_message,
    DataType.INTERMEDIATE_TRANSCRIPTION: handle_intermediate_transcription,
    DataType.AGENT_ASSIST: handle_agent_assist,
    DataType.LIFECYCLE: handle_lifecycle,
}


# ══════════════════════════════════════════════════════════════════════════════
# 3. Summary flow (only runs when SUMMARY_ON_END=true)
# ══════════════════════════════════════════════════════════════════════════════
#
# Summarization is NOT event-based: Agent Assist never pushes it to the
# agent-assist topic, it has to be asked for. This is the only place that
# happens.
#
# Verified against a real 200 OK from:
#   POST https://global-dialogflow.googleapis.com/v2/projects/{project}
#        /locations/global/conversations/{id}/suggestions:suggestConversationSummary

_summary_executor = None
_summary_executor_lock = Lock()


def _get_summary_executor() -> ThreadPoolExecutor:
    """Created lazily so the pool doesn't exist unless summarization is used."""
    global _summary_executor
    if _summary_executor is None:
        with _summary_executor_lock:
            if _summary_executor is None:
                _summary_executor = ThreadPoolExecutor(
                    max_workers=SUMMARY_WORKERS, thread_name_prefix="summary"
                )
    return _summary_executor


def trigger_summary_fetch(conversation_id: str, data: dict) -> None:
    """Resolves the conversation path, takes the one-shot lock, runs the fetch."""
    if not SUMMARY_ON_END:
        return

    conversation_path = _resolve_conversation_path(conversation_id, data)

    try:
        if not acquire_summary_lock(conversation_id):
            log_info("Summary already requested; skipping", conversation_id=conversation_id)
            return
    except Exception as err:
        # Fail open: a missed lock risks a duplicate call, not a missing summary.
        log_warning("Could not take summary lock", conversation_id=conversation_id, error=str(err))

    if SUMMARY_INLINE:
        log_info("Running inline summary fetch", conversation_id=conversation_id)
        _fetch_summary_safely(conversation_id, conversation_path)
    else:
        log_info("Dispatching background summary fetch", conversation_id=conversation_id)
        _get_summary_executor().submit(_fetch_summary_safely, conversation_id, conversation_path)


def force_summary_fetch(conversation_id: str) -> None:
    """Clears the one-shot lock and re-triggers (debug endpoint only)."""
    try:
        release_summary_lock(conversation_id)
    except Exception as err:
        log_warning("Could not clear summary lock", conversation_id=conversation_id, error=str(err))
    trigger_summary_fetch(conversation_id, {"conversation_id": conversation_id})


def _resolve_conversation_path(conversation_id: str, data: dict) -> str:
    """Prefer the path Dialogflow itself sent; then the one saved in :meta; then rebuild it."""
    path = extract_conversation_path(data)
    if path:
        return path

    try:
        path = get_meta_field(conversation_id, "conversation_path")
    except Exception as err:
        log_warning("Could not read stored conversation_path", conversation_id=conversation_id, error=str(err))
    if path:
        return path

    path = (
        f"projects/{GCP_PROJECT_ID}/locations/{DIALOGFLOW_LOCATION}"
        f"/conversations/{conversation_id}"
    )
    log_info("Reconstructed conversation path", conversation_id=conversation_id, conversation_path=path)
    return path


def _fetch_summary_safely(conversation_id: str, conversation_path: str) -> None:
    """
    An exception escaping a ThreadPoolExecutor task is stored on its Future and
    never printed, so the background path needs its own last-resort log.
    """
    try:
        _fetch_summary(conversation_id, conversation_path)
    except Exception as err:
        log_error(
            "Summary worker crashed",
            conversation_id=conversation_id,
            error=str(err),
            traceback=traceback.format_exc(),
        )


def _fetch_summary(conversation_id: str, conversation_path: str) -> None:
    """
    Calls suggestConversationSummary with retries.

    `latest_message` is deliberately omitted: the API defaults to the latest
    message of the conversation, which is exactly what we want at end of call,
    so there's no need to track message resource paths during the call.
    """
    from google.cloud import dialogflow_v2 as dialogflow  # lazy: see functions.py §6

    started = time.monotonic()
    if SUMMARY_INITIAL_DELAY_SECONDS > 0:
        time.sleep(SUMMARY_INITIAL_DELAY_SECONDS)

    last_error = None
    for attempt in range(1, SUMMARY_MAX_ATTEMPTS + 1):
        try:
            request = dialogflow.SuggestConversationSummaryRequest(
                conversation=conversation_path,
                context_size=SUMMARY_CONTEXT_SIZE,
            )
            log_info(
                "Requesting summary",
                conversation_id=conversation_id,
                conversation_path=conversation_path,
                attempt=attempt,
                max_attempts=SUMMARY_MAX_ATTEMPTS,
                context_size=SUMMARY_CONTEXT_SIZE,
            )
            response = get_dialogflow_client().suggest_conversation_summary(request=request)
            summary = summary_to_dict(response)

            if summary.get("text") or summary.get("textSections"):
                log_info("Summary received", conversation_id=conversation_id, attempt=attempt)
                _store_and_publish_summary(conversation_id, summary)
                log_metric(
                    "summary_fetch",
                    status="success",
                    conversation_id=conversation_id,
                    attempts=attempt,
                    duration_ms=int((time.monotonic() - started) * 1000),
                )
                return

            last_error = "empty summary returned"
            log_warning(
                "Summary came back empty; retrying",
                conversation_id=conversation_id,
                attempt=attempt,
                max_attempts=SUMMARY_MAX_ATTEMPTS,
            )
        except Exception as err:
            last_error = str(err)
            log_warning(
                "suggestConversationSummary failed",
                conversation_id=conversation_id,
                attempt=attempt,
                max_attempts=SUMMARY_MAX_ATTEMPTS,
                error=last_error,
            )

        if attempt < SUMMARY_MAX_ATTEMPTS:
            time.sleep(SUMMARY_RETRY_BACKOFF_SECONDS * attempt)

    log_error(
        "Gave up fetching summary",
        conversation_id=conversation_id,
        attempts=SUMMARY_MAX_ATTEMPTS,
        error=str(last_error),
    )
    log_metric(
        "summary_fetch",
        status="failed",
        conversation_id=conversation_id,
        attempts=SUMMARY_MAX_ATTEMPTS,
        duration_ms=int((time.monotonic() - started) * 1000),
        error=str(last_error),
    )
    # Recorded so the UI can show "summary unavailable" instead of waiting forever.
    try:
        update_meta(conversation_id, {
            "summary_error": str(last_error)[:500],
            "summary_error_at": utc_now(),
        })
    except Exception as err:
        log_warning("Could not record summary failure", conversation_id=conversation_id, error=str(err))


def _store_and_publish_summary(conversation_id: str, summary: dict) -> None:
    """
    Stores the summary in :meta and publishes it straight to the live Redis channel.

    Deliberately NOT republished to the Pub/Sub topic: we're already inside the
    interceptor, so a round trip through Google just to receive our own message
    back would add latency, need a publisher grant, and risk a loop.
    """
    message = build_summary_message(conversation_id, summary)
    encoded = json.dumps(message)

    try:
        meta = update_meta(conversation_id, {
            "last_summary": json.dumps(message["data"]),
            "last_summary_sections": json.dumps(summary.get("textSections", {})),
            "last_summary_text": summary.get("text", ""),
            "last_summary_answer_record": summary.get("answerRecord", ""),
            "last_summary_at": message["ack_time"],
        })
        # Only append to :turns when agent-assist buffering is on, so the
        # connector's replay never sees an entry shape it wasn't built for.
        if BUFFER_AGENT_ASSIST:
            append_turn(conversation_id, encoded)
        log_info(
            "Stored summary",
            conversation_id=conversation_id,
            key=meta,
            sections=list(summary.get("textSections", {}).keys()),
        )
    except Exception as err:
        log_error("Failed to store summary", conversation_id=conversation_id, error=str(err))

    try:
        published = publish_live(conversation_id, encoded)
        if published is None:
            log_info(
                "Summary stored but no active viewer; readable from :meta on next join",
                conversation_id=conversation_id,
            )
            return
        log_info(
            "Summary published to live channel",
            conversation_id=conversation_id,
            channel=published.channel,
            subscribers=published.receivers,
        )
    except Exception as err:
        log_error("Failed to live-publish summary", conversation_id=conversation_id, error=str(err))
