"""
Configuration and the building blocks the handlers are made of.

Nothing in here reacts to an event on its own; handlers.py decides when each
piece is used.

  1. Config              every env var and feature flag
  2. Connector contract  data_type names, Redis keys/channels, message shapes
  3. Redis               client + buffer / meta / publish / lock operations
  4. Conversation ids    short id, resource path, display name
  5. Suggestions         agent-assist payload inspection
  6. Dialogflow          Conversations client + summary response → dict
"""

import os
import threading
from datetime import datetime, timezone
from typing import NamedTuple, Optional

import redis
from redis.backoff import ExponentialBackoff
from redis.retry import Retry

from utils import format_timestamp, log_info

# ══════════════════════════════════════════════════════════════════════════════
# 1. Config
# ══════════════════════════════════════════════════════════════════════════════
#
# SAFE MODE: with none of the feature flags set, the service behaves exactly
# like the original single-file interceptor: same Redis writes, same live
# publish, same payload shapes. Every addition defaults to OFF.
#
# Turn features on ONE AT A TIME and verify live streaming after each:
#   1. LOG_SUGGESTION_TYPES=true  Adds suggestion_types / has_summary to the
#                                 per-event log line. Zero behaviour change.
#   2. BUFFER_AGENT_ASSIST=true   Write agent-assist events to :turns so they
#                                 survive when no viewer is connected.
#                                 REQUIRES the connector's normalizer to skip
#                                 data_type == agent-assist-notifications-event.
#   3. SUMMARY_ON_END=true        Pull the summary via suggestConversationSummary
#                                 when the call ends and push it to the live
#                                 Redis channel.
# Kill switch: unset a flag and redeploy. No code changes needed.
#
# Log verbosity is NOT set here: utils.py derives it from ENVIRONMENT
# (dev=DEBUG, sit/uat=INFO, prod=ERROR).

def _flag(name: str, default: str = "false") -> bool:
    return os.environ.get(name, default).lower() == "true"


def _upper_set(name: str, default: str) -> frozenset:
    """Comma-separated env var → set of trimmed, upper-cased, non-empty values."""
    return frozenset(
        value.strip().upper()
        for value in os.environ.get(name, default).split(",")
        if value.strip()
    )


# ── Feature flags (all default OFF) ──
LOG_SUGGESTION_TYPES = _flag("LOG_SUGGESTION_TYPES")
BUFFER_AGENT_ASSIST = _flag("BUFFER_AGENT_ASSIST")
SUMMARY_ON_END = _flag("SUMMARY_ON_END")

# Cloud Run throttles CPU to near-zero after the response is sent, so a
# background thread can stall until the next request. Either deploy with
# --no-cpu-throttling, or set SUMMARY_INLINE=true (which holds the Pub/Sub
# ack open, so raise the subscription's ack deadline accordingly).
SUMMARY_INLINE = _flag("SUMMARY_INLINE")

# ── Redis ──
REDIS_HOST = os.environ.get("REDISHOST", "100.72.86.38")
REDIS_PORT = int(os.environ.get("REDISPORT", 6379))

# Rolling TTL for buffered conversation data (:turns and :meta). Reset on
# every write, so keys expire after this long of INACTIVITY, not from when
# the conversation started. Change this single value to tune retention.
CONVERSATION_DATA_TTL_SECONDS = 2 * 60 * 60  # 2 hours

# Shortcut TTL (currently DISABLED). Once a lifecycle event reports the call
# is over, a short grace period (enough for a final reconnect/QA check) would
# do instead of the full rolling window.
# WARNING: with SUMMARY_ON_END on, the summary is fetched AFTER that event, so
# this must exceed worst-case summary latency or the keys expire under it.
# ENDED_CONVERSATION_TTL_SECONDS = 15 * 60  # 15 minutes
# ENDED_LIFECYCLE_STATUSES = {"ENDED"}

# ── Summarization (only used when SUMMARY_ON_END=true) ──
GCP_PROJECT_ID = os.environ.get("GCP_PROJECT_ID", "adtgcp-ent-dev-ccs-tlcm-fe10")

# 'global', NOT the GKE region. The conversation resource lives at
# projects/{p}/locations/global/conversations/{id}, confirmed against a
# working request. Using a region here yields NOT_FOUND.
DIALOGFLOW_LOCATION = os.environ.get("DIALOGFLOW_LOCATION", "global")

# Lifecycle values that mean "call is over". TWO SHAPES EXIST, accept both:
#   real Dialogflow  →  {"conversation": "...", "type": "CONVERSATION_FINISHED"}
#   mock publisher   →  {"conversation_id": "...", "status": "ENDED"}
SUMMARY_TRIGGER_STATUSES = _upper_set(
    "SUMMARY_TRIGGER_STATUSES", "CONVERSATION_FINISHED,ENDED,COMPLETED"
)

# Max messages of context. API default is 500, hard max 1000.
SUMMARY_CONTEXT_SIZE = int(os.environ.get("SUMMARY_CONTEXT_SIZE", "500"))

SUMMARY_MAX_ATTEMPTS = int(os.environ.get("SUMMARY_MAX_ATTEMPTS", "4"))
SUMMARY_RETRY_BACKOFF_SECONDS = int(os.environ.get("SUMMARY_RETRY_BACKOFF_SECONDS", "5"))
SUMMARY_INITIAL_DELAY_SECONDS = int(os.environ.get("SUMMARY_INITIAL_DELAY_SECONDS", "3"))
SUMMARY_LOCK_TTL_SECONDS = int(os.environ.get("SUMMARY_LOCK_TTL_SECONDS", "3600"))
SUMMARY_WORKERS = int(os.environ.get("SUMMARY_WORKERS", "4"))


# ══════════════════════════════════════════════════════════════════════════════
# 2. Connector contract
# ══════════════════════════════════════════════════════════════════════════════
#
# Everything in this section is READ by the UI connector as well as written
# here. Changing any of it means changing the connector too.
#
# All keys use the SHORT conversation id:
#   server_id lookup   →  {short_id}
#   live channel       →  {server_id}:{short_id}
#   buffered turns     →  conversation:{short_id}:turns
#   conversation meta  →  conversation:{short_id}:meta

class DataType:
    """data_type strings; one per Pub/Sub topic / push route."""

    AGENT_ASSIST = "agent-assist-notifications-event"
    LIFECYCLE = "conversation-lifecycle-event"
    NEW_MESSAGE = "new-message-notification-event"
    INTERMEDIATE_TRANSCRIPTION = "intermediate-transcription-notification-event"


def server_id_key(conversation_id: str) -> str:
    """Written by the connector when a viewer joins; holds its server_id."""
    return conversation_id


def live_channel(server_id: str, conversation_id: str) -> str:
    return f"{server_id}:{conversation_id}"


def turns_key(conversation_id: str) -> str:
    return f"conversation:{conversation_id}:turns"


def meta_key(conversation_id: str) -> str:
    return f"conversation:{conversation_id}:meta"


def utc_now() -> str:
    """Current time as YYYY-MM-DDTHH:MM:SSZ, the format used for ack_time and meta timestamps."""
    return format_timestamp(datetime.now(timezone.utc))


def build_event_message(
    *,
    conversation_id: str,
    conversation_name,
    data: dict,
    data_type: str,
    publish_time,
    message_id,
    participant_role: str = "",
    recognition_message_id: str = "",
) -> dict:
    """Envelope for an event received from Pub/Sub (buffered and live-published as-is)."""
    message = {
        "conversation_id": conversation_id,      # short id (canonical)
        "conversation_name": conversation_name,  # display name
        "data": data,
        "data_type": data_type,
        "ack_time": utc_now(),
        "publish_time": publish_time,
        "message_id": message_id,
    }
    if data_type == DataType.INTERMEDIATE_TRANSCRIPTION:
        message["participant_role"] = participant_role
        message["new_recognition_result_message_id"] = recognition_message_id
    return message


def build_summary_message(conversation_id: str, summary: dict) -> dict:
    """
    Envelope for a summary this service PULLED from Dialogflow.

    Shaped exactly like a pushed agent-assist event, so the connector needs no
    special-casing; `source` is the only field that tells them apart.
    """
    return {
        "conversation_id": conversation_id,
        "conversation_name": conversation_id,
        "data": {
            "conversation_id": conversation_id,
            "suggestionResults": [
                {"suggestConversationSummaryResponse": {"summary": summary}}
            ],
        },
        "data_type": DataType.AGENT_ASSIST,
        "ack_time": utc_now(),
        "publish_time": None,
        "message_id": f"summary-{conversation_id}",
        "source": "interceptor-pull",
    }


# ══════════════════════════════════════════════════════════════════════════════
# 3. Redis
# ══════════════════════════════════════════════════════════════════════════════
#
# Every write goes through these functions so the rolling-TTL rule lives in
# one place: each write to :turns or :meta resets that key's expiry.

redis_client = redis.Redis(
    host=REDIS_HOST,
    port=REDIS_PORT,
    health_check_interval=10,
    socket_connect_timeout=15,
    retry_on_timeout=True,
    socket_keepalive=True,
    retry=Retry(ExponentialBackoff(cap=5, base=1), 5),
    retry_on_error=[
        redis.exceptions.ConnectionError,
        redis.exceptions.TimeoutError,
        redis.exceptions.ResponseError,
    ],
)


class LivePublish(NamedTuple):
    channel: str
    receivers: int


def append_turn(conversation_id: str, encoded_message: str) -> str:
    """RPUSH to :turns and reset its TTL. Returns the key written."""
    key = turns_key(conversation_id)
    redis_client.rpush(key, encoded_message)
    redis_client.expire(key, CONVERSATION_DATA_TTL_SECONDS)
    return key


def update_meta(conversation_id: str, fields: dict) -> str:
    """HSET fields on :meta and reset its TTL. Returns the key written."""
    key = meta_key(conversation_id)
    redis_client.hset(key, mapping=fields)
    redis_client.expire(key, CONVERSATION_DATA_TTL_SECONDS)
    return key


def get_meta_field(conversation_id: str, field: str) -> Optional[str]:
    raw = redis_client.hget(meta_key(conversation_id), field)
    return raw.decode("utf-8") if raw else None


def publish_live(conversation_id: str, encoded_message: str) -> Optional[LivePublish]:
    """
    Publishes to the connector instance currently serving this conversation.
    Returns None when no viewer is registered (no server_id key).
    """
    server_id = redis_client.get(server_id_key(conversation_id))
    if server_id is None:
        return None
    channel = live_channel(server_id.decode("utf-8"), conversation_id)
    return LivePublish(channel, redis_client.publish(channel, encoded_message))


# One-shot summary lock. Pub/Sub redelivers; a duplicate "call ended" event
# would otherwise fire a second billable suggestConversationSummary call.

def _summary_lock_key(conversation_id: str) -> str:
    return f"summary:lock:{conversation_id}"


def acquire_summary_lock(conversation_id: str) -> bool:
    return bool(
        redis_client.set(
            _summary_lock_key(conversation_id), "1", nx=True, ex=SUMMARY_LOCK_TTL_SECONDS
        )
    )


def release_summary_lock(conversation_id: str) -> None:
    redis_client.delete(_summary_lock_key(conversation_id))


# ══════════════════════════════════════════════════════════════════════════════
# 4. Conversation ids
# ══════════════════════════════════════════════════════════════════════════════

def extract_short_conversation_id(data: dict) -> Optional[str]:
    """
    Returns the SHORT conversation id (e.g. '119D884h-wcQNGy0qy4QyS-9w'),
    the canonical key shared with the UI connector, regardless of:
      - whether the payload carries it under 'conversation_id' or 'conversation'
      - whether the value is a bare id or a full resource path
      - whether the payload carries ONLY a participant path

    The participant fallback only fires when both primary fields are absent,
    so it cannot change the id for any payload that already resolved.
    """
    raw = data.get("conversation_id") or data.get("conversation")

    if not isinstance(raw, str) or not raw:
        participant = data.get("participant") or data.get("participant_id")
        if isinstance(participant, str) and "/conversations/" in participant:
            raw = participant.split("/conversations/")[1].split("/")[0]

    if not isinstance(raw, str) or not raw:
        return None

    return raw.rstrip("/").split("/")[-1]


def extract_conversation_path(data: dict) -> Optional[str]:
    """Full `projects/.../conversations/{id}` path if the payload carries one."""
    candidates = (
        data.get("conversation"),
        data.get("conversation_id"),
        data.get("participant"),
        data.get("participant_id"),
    )
    for raw in candidates:
        if isinstance(raw, str) and "/conversations/" in raw:
            head, _, tail = raw.rstrip("/").partition("/conversations/")
            return f"{head}/conversations/{tail.split('/')[0]}"
    return None


def display_name(data: dict, conversation_id: str):
    """
    Conversation name with its location segment removed, for logs and the
    `conversation_name` field only. NEVER use this for Redis keys/channels.
    """
    raw = data.get("conversation_id") or data.get("conversation") or conversation_id
    if "/locations/" in raw:
        parts = raw.split("/")
        return "/".join(parts[i] for i in (0, 1, -2, -1))
    return raw


# ══════════════════════════════════════════════════════════════════════════════
# 5. Suggestions (read-only inspection of agent-assist payloads)
# ══════════════════════════════════════════════════════════════════════════════
#
# Google emits camelCase (REST/JSON) or snake_case (proto) depending on
# serialization, so every lookup checks both.
#
# This profile runs BOTH suggestion systems side by side:
#   - generators → generateSuggestionsResponse.{generatorSuggestionAnswers,
#                  systemActionSuggestions}
#   - legacy     → suggestConversationSummaryResponse, suggestFaqAnswersResponse

_GENERATE_RESPONSE_KEYS = ("generateSuggestionsResponse", "generate_suggestions_response")
_LEGACY_SUMMARY_KEYS = ("suggestConversationSummaryResponse", "suggest_conversation_summary_response")


def _pick(d, *keys):
    for key in keys:
        if isinstance(d, dict) and key in d:
            return d[key]
    return None


def _as_list(value) -> list:
    if value is None:
        return []
    if isinstance(value, dict):
        return [value]
    return value if isinstance(value, list) else []


def suggestion_results(data: dict) -> list:
    return _as_list(_pick(data, "suggestionResults", "suggestion_results"))


def _generator_answers(result: dict) -> list:
    response = _pick(result, *_GENERATE_RESPONSE_KEYS)
    if not isinstance(response, dict):
        return []
    return _as_list(_pick(response, "generatorSuggestionAnswers", "generator_suggestion_answers"))


def _generator_suggestion(answer):
    suggestion = _pick(answer, "generatorSuggestion", "generator_suggestion")
    return suggestion if isinstance(suggestion, dict) else None


def has_summary(data: dict) -> bool:
    """True if this payload carries a summary, in either legacy or generator shape."""
    for result in suggestion_results(data):
        if not isinstance(result, dict):
            continue
        if any(key in result for key in _LEGACY_SUMMARY_KEYS):
            return True
        for answer in _generator_answers(result):
            suggestion = _generator_suggestion(answer)
            if suggestion and _pick(suggestion, "summarySuggestion", "summary_suggestion"):
                return True
    return False


def suggestion_types(data: dict) -> list:
    """
    Names what actually arrived, drilling INTO generateSuggestionsResponse.
    Without this you only see ['generateSuggestionsResponse'] and can't tell a
    summary from a coaching tip from a system action.
    """
    types = []
    for result in suggestion_results(data):
        if not isinstance(result, dict):
            continue
        types.extend(key for key in result if key not in ("error", *_GENERATE_RESPONSE_KEYS))

        response = _pick(result, *_GENERATE_RESPONSE_KEYS)
        if not isinstance(response, dict):
            continue
        for answer in _generator_answers(result):
            suggestion = _generator_suggestion(answer)
            if suggestion:
                types.extend(
                    f"generator:{key}" for key in suggestion
                    if key not in ("toolCallInfo", "tool_call_info")
                )
        system_actions = _pick(response, "systemActionSuggestions", "system_action_suggestions")
        if system_actions:
            types.append(f"systemActions[{len(_as_list(system_actions))}]")
    return types


def suggestion_errors(data: dict) -> list:
    """The `error` entries of any suggestion results that failed."""
    return [
        result["error"]
        for result in suggestion_results(data)
        if isinstance(result, dict) and result.get("error")
    ]


# ══════════════════════════════════════════════════════════════════════════════
# 6. Dialogflow
# ══════════════════════════════════════════════════════════════════════════════
#
# The SDK is imported INSIDE functions, not at module scope: an import that
# drags in a conflicting protobuf can fail container startup, which would take
# down live streaming along with everything else.

_dialogflow_client = None
_dialogflow_client_lock = threading.Lock()


def get_dialogflow_client():
    """
    Builds (once) a Conversations client.

    Location is 'global', so the DEFAULT endpoint is correct. A regional
    api_endpoint is only used if DIALOGFLOW_LOCATION is changed to a region;
    mismatching the two yields NOT_FOUND.
    """
    global _dialogflow_client
    if _dialogflow_client is not None:
        return _dialogflow_client

    from google.api_core.client_options import ClientOptions
    from google.cloud import dialogflow_v2 as dialogflow

    with _dialogflow_client_lock:
        if _dialogflow_client is None:
            if DIALOGFLOW_LOCATION and DIALOGFLOW_LOCATION != "global":
                endpoint = f"{DIALOGFLOW_LOCATION}-dialogflow.googleapis.com"
                _dialogflow_client = dialogflow.ConversationsClient(
                    client_options=ClientOptions(api_endpoint=endpoint)
                )
            else:
                endpoint = "global (default)"
                _dialogflow_client = dialogflow.ConversationsClient()
            log_info("Dialogflow client built", endpoint=endpoint)
    return _dialogflow_client


def summary_to_dict(response) -> dict:
    """
    Flattens SuggestConversationSummaryResponse into plain JSON, using the same
    field names as the REST API so what lands in Redis matches Postman.

    Response shape (confirmed against a live 200 OK):
      {"summary": {"text": "...", "answerRecord": "projects/.../answerRecords/{id}",
                   "textSections": {"situation_concise": "...", "resolution": "N", ...}}}
    `textSections` is the useful field (a flat map the UI renders section by
    section); `text` is the same content concatenated into one blob.
    """
    summary = getattr(response, "summary", None)
    if summary is None:
        return {}

    text_sections = {}
    raw_sections = getattr(summary, "text_sections", None)
    if raw_sections:
        try:
            text_sections = dict(raw_sections)
        except Exception:
            text_sections = {}

    return {
        "text": getattr(summary, "text", "") or "",
        "textSections": text_sections,
        # Handle for AnswerRecords.UpdateAnswerRecord (thumbs up/down on the summary).
        "answerRecord": getattr(summary, "answer_record", "") or "",
        "latestMessage": getattr(response, "latest_message", "") or "",
        "contextSize": getattr(response, "context_size", 0),
    }
