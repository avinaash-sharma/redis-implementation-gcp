"""
HTTP routes: Pub/Sub push endpoints, health, and the debug summary trigger.
"""

from datetime import datetime, timezone

from fastapi import APIRouter, Request
from fastapi.responses import PlainTextResponse

from functions import (
    BUFFER_AGENT_ASSIST,
    DIALOGFLOW_LOCATION,
    GCP_PROJECT_ID,
    LOG_SUGGESTION_TYPES,
    SUMMARY_CONTEXT_SIZE,
    SUMMARY_INLINE,
    SUMMARY_ON_END,
    SUMMARY_TRIGGER_STATUSES,
    DataType,
)
from handlers import force_summary_fetch, process_envelope

health_router = APIRouter()
intercept_router = APIRouter(prefix="/intercept")
admin_router = APIRouter(prefix="/admin")


# ─── Pub/Sub push endpoints (one per topic) ───────────────────────────────────

async def _intercept(request: Request, data_type: str, ack_text: str) -> PlainTextResponse:
    envelope = await request.json()
    if not process_envelope(envelope, data_type):
        return PlainTextResponse("Bad Request", status_code=400)
    return PlainTextResponse(ack_text, status_code=200)


@intercept_router.post("/agent-assist-notifications-event", response_class=PlainTextResponse)
async def subscribe_suggestions(request: Request):
    """Human agent assist events from the agent-assist-notifications topic."""
    return await _intercept(
        request, DataType.AGENT_ASSIST,
        "Received by cloud run service as a HumanAgentAssistantEvent.",
    )


@intercept_router.post("/conversation-lifecycle-event", response_class=PlainTextResponse)
async def subscribe_lifecycle_events(request: Request):
    """Conversation lifecycle events from the conversation-lifecycle topic."""
    return await _intercept(
        request, DataType.LIFECYCLE,
        "Received by cloud run service as a ConversationEvent.",
    )


@intercept_router.post("/new-message-notification-event", response_class=PlainTextResponse)
async def subscribe_message_events(request: Request):
    """New message events from the new-message-notification topic."""
    return await _intercept(
        request, DataType.NEW_MESSAGE,
        "Received by cloud run service as a ConversationEvent.",
    )


@intercept_router.post("/intermediate-transcription-notification-event", response_class=PlainTextResponse)
async def subscribe_new_recognition_result_events(request: Request):
    """Intermediate transcription events from the intermediate-transcription-notification topic."""
    return await _intercept(
        request, DataType.INTERMEDIATE_TRANSCRIPTION,
        "Received by cloud run service as a New recognition result notification.",
    )


# ─── Health ───────────────────────────────────────────────────────────────────

@health_router.get("/")
def health():
    return {
        "status": "interceptor running",
        "time": datetime.now(timezone.utc).isoformat(),
        "flags": {
            "LOG_SUGGESTION_TYPES": LOG_SUGGESTION_TYPES,
            "BUFFER_AGENT_ASSIST": BUFFER_AGENT_ASSIST,
            "SUMMARY_ON_END": SUMMARY_ON_END,
            "SUMMARY_INLINE": SUMMARY_INLINE,
        },
        "summarization": {
            "project": GCP_PROJECT_ID,
            "location": DIALOGFLOW_LOCATION,
            "trigger_statuses": sorted(SUMMARY_TRIGGER_STATUSES),
            "context_size": SUMMARY_CONTEXT_SIZE,
        },
    }


# ─── Debug only: gate or remove before TST ────────────────────────────────────

@admin_router.post("/summary/{conversation_id}")
async def manual_summary(conversation_id: str):
    """Forces a summary fetch without waiting for a real call to end (clears the lock first)."""
    if not SUMMARY_ON_END:
        return {"status": "disabled", "note": "set SUMMARY_ON_END=true"}
    force_summary_fetch(conversation_id)
    return {
        "status": "summary fetch dispatched",
        "conversation_id": conversation_id,
        "note": "check logs for 'Requesting summary' / 'Stored summary'",
    }
