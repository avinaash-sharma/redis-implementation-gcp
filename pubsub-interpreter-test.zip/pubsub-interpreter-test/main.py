"""
ADT Pub/Sub Interceptor.

SAFE MODE
---------
With no new environment variables set, this file behaves EXACTLY like the
original: same Redis writes, same live publish, same payload shapes. Every
addition is behind a flag that defaults to OFF.

Turn features on ONE AT A TIME and verify live streaming still works after
each:

  1. LOG_SUGGESTION_TYPES=true   Extra log fields naming which suggestions
                                 arrived. Zero behaviour change.
  2. BUFFER_AGENT_ASSIST=true    Write agent-assist events to :turns so they
                                 survive when no viewer is connected.
                                 REQUIRES the connector's normalizer to skip
                                 data_type == agent-assist-notifications-event.
  3. SUMMARY_ON_END=true         Pull the summary via suggestConversationSummary
                                 when the call ends and push it to the live
                                 Redis channel.

Kill switch: unset a flag and redeploy. No code changes needed.

Verified against a real 200 OK from:
  POST https://global-dialogflow.googleapis.com/v2/projects/{project}
       /locations/global/conversations/{id}/suggestions:suggestConversationSummary

LOGGING
-------
All logging goes through utils.py, which emits one JSON object per line with
`environment` and `service` (K_SERVICE, set by Cloud Run) attached, and takes
its level from ENVIRONMENT: dev=DEBUG, sit/uat=INFO, prod=ERROR.

Two rules keep a log call from ever breaking message delivery, because
utils json.dumps() the whole payload:
  - never pass a field called `message` or `level` (they collide with _log's
    own parameters) — use message_id;
  - only pass JSON-serializable values. Anything from the Pub/Sub payload is
    already JSON; exceptions go through str(err); sets through sorted().
"""

import base64
import json
import os
import threading
import time
import traceback
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone

import redis
from fastapi import FastAPI, Request
from fastapi.responses import PlainTextResponse

from utils import format_timestamp, log_debug, log_error, log_info, log_metric, log_warning

app = FastAPI(title="Pub/Sub Interceptor")


def _utc_now() -> str:
    """ack_time / meta timestamp format shared with the connector: YYYY-MM-DDTHH:MM:SSZ."""
    return format_timestamp(datetime.now(timezone.utc))


# ─── Feature flags (ALL DEFAULT OFF) ──────────────────────────────────────────

def _flag(name: str, default: str = 'false') -> bool:
    return os.environ.get(name, default).lower() == 'true'


LOG_SUGGESTION_TYPES = _flag('LOG_SUGGESTION_TYPES')
BUFFER_AGENT_ASSIST = _flag('BUFFER_AGENT_ASSIST')
SUMMARY_ON_END = _flag('SUMMARY_ON_END')


# ─── Redis setup ────────────────────────────────────────────────────────────────

redis_host = os.environ.get('REDISHOST', '100.72.86.38')
redis_port = int(os.environ.get('REDISPORT', 6379))
redis_client = redis.StrictRedis(
    host=redis_host,
    port=redis_port,
    health_check_interval=10,
    socket_connect_timeout=15,
    retry_on_timeout=True,
    socket_keepalive=True,
    retry=redis.retry.Retry(
        redis.backoff.ExponentialBackoff(cap=5, base=1), 5
    ),
    retry_on_error=[
        redis.exceptions.ConnectionError,
        redis.exceptions.TimeoutError,
        redis.exceptions.ResponseError,
    ]
)

# Rolling TTL (seconds) for buffered conversation data (:turns and :meta).
# Reset on every write, so it only expires after this many seconds of
# INACTIVITY — not from when the conversation started. Change this single
# value to tune retention; no other code needs to change.
CONVERSATION_DATA_TTL_SECONDS = 2 * 60 * 60  # 2 hours

# ── Shortcut TTL (currently DISABLED) ───────────────────────────────────────
# Once a conversation-lifecycle-event reports the call is genuinely over,
# there's no reason to keep the full 2-hour rolling window — a short grace
# period (enough for a final reconnect/QA check) is plenty.
#
# WARNING: with SUMMARY_ON_END enabled the summary is fetched AFTER this
# event fires. ENDED_CONVERSATION_TTL_SECONDS must exceed worst-case summary
# latency or the keys expire out from under it.
# ENDED_CONVERSATION_TTL_SECONDS = 15 * 60  # 15 minutes
# ENDED_LIFECYCLE_STATUSES = {"ENDED"}

# ── Summarization config (only used when SUMMARY_ON_END=true) ───────────────
GCP_PROJECT_ID = os.environ.get('GCP_PROJECT_ID', 'adtgcp-ent-dev-ccs-tlcm-fe10')

# NOTE: this is 'global', NOT the GKE region. The conversation resource lives
# at projects/{p}/locations/global/conversations/{id} — confirmed against a
# working request. Using a region here yields NOT_FOUND.
DIALOGFLOW_LOCATION = os.environ.get('DIALOGFLOW_LOCATION', 'global')

# Lifecycle values that mean "call is over".
#
# TWO SHAPES EXIST — accept both:
#   real Dialogflow  →  {"conversation": "...", "type": "CONVERSATION_FINISHED"}
#   mock publisher   →  {"conversation_id": "...", "status": "ENDED"}
#
# Coding against only `status` silently no-ops in production: the field is
# absent, the comparison fails, and nothing is logged to say why.
SUMMARY_TRIGGER_STATUSES = {
    s.strip().upper()
    for s in os.environ.get(
        'SUMMARY_TRIGGER_STATUSES',
        'CONVERSATION_FINISHED,ENDED,COMPLETED',
    ).split(',')
    if s.strip()
}

# Max messages of context. API default is 500, hard max 1000.
SUMMARY_CONTEXT_SIZE = int(os.environ.get('SUMMARY_CONTEXT_SIZE', '500'))

SUMMARY_MAX_ATTEMPTS = int(os.environ.get('SUMMARY_MAX_ATTEMPTS', '4'))
SUMMARY_RETRY_BACKOFF_SECONDS = int(os.environ.get('SUMMARY_RETRY_BACKOFF_SECONDS', '5'))
SUMMARY_INITIAL_DELAY_SECONDS = int(os.environ.get('SUMMARY_INITIAL_DELAY_SECONDS', '3'))
SUMMARY_LOCK_TTL_SECONDS = int(os.environ.get('SUMMARY_LOCK_TTL_SECONDS', '3600'))

# Cloud Run throttles CPU to near-zero after the response is sent, so a
# background thread can stall until the next request. Either deploy with
# --no-cpu-throttling, or set SUMMARY_INLINE=true (which holds the Pub/Sub
# ack open — raise the subscription's ack deadline accordingly).
SUMMARY_INLINE = _flag('SUMMARY_INLINE')

_summary_executor = None
_summary_executor_lock = threading.Lock()
_dialogflow_client = None
_dialogflow_client_lock = threading.Lock()


def _get_executor():
    """Created lazily so the pool doesn't exist unless summarization is used."""
    global _summary_executor
    if _summary_executor is None:
        with _summary_executor_lock:
            if _summary_executor is None:
                _summary_executor = ThreadPoolExecutor(
                    max_workers=int(os.environ.get('SUMMARY_WORKERS', '4')),
                    thread_name_prefix='summary',
                )
    return _summary_executor


# ─── Helpers ───────────────────────────────────────────────────────────────────

def get_conversation_name_without_location(conversation_name: str) -> str:
    """Returns a conversation name without its location id.
    Kept for display purposes only — NEVER use this for Redis keys/channels."""
    if '/locations/' in conversation_name:
        name_array = conversation_name.split('/')
        return '/'.join(name_array[i] for i in [0, 1, -2, -1])
    return conversation_name


def extract_short_conversation_id(data_object: dict):
    """
    Returns the SHORT conversation id (e.g. '119D884h-wcQNGy0qy4QyS-9w')
    regardless of:
      - whether the payload carries it under 'conversation_id' or 'conversation'
      - whether the value is a bare id or a full resource path
      - whether the payload carries ONLY a participant path

    This short id is the canonical key used by BOTH this interceptor and the
    UI connector for:
      - the server_id lookup key           →  {short_id}
      - the live pub/sub channel           →  {server_id}:{short_id}
      - the buffered turns list            →  conversation:{short_id}:turns
      - the conversation meta hash         →  conversation:{short_id}:meta

    The participant fallback is ADDITIVE — it only fires when both primary
    fields are absent, so it cannot change the id for any payload that
    already worked.
    """
    raw = data_object.get('conversation_id') or data_object.get('conversation')

    if not isinstance(raw, str) or not raw:
        participant = data_object.get('participant') or data_object.get('participant_id')
        if isinstance(participant, str) and '/conversations/' in participant:
            raw = participant.split('/conversations/')[1].split('/')[0]

    if not isinstance(raw, str) or not raw:
        return None

    return raw.rstrip('/').split('/')[-1]


def extract_conversation_path(data_object: dict):
    """Full conversation resource path if the payload carries one, else None."""
    candidates = (
        data_object.get('conversation'),
        data_object.get('conversation_id'),
        data_object.get('participant'),
        data_object.get('participant_id'),
    )
    for raw in candidates:
        if isinstance(raw, str) and '/conversations/' in raw:
            head, _, tail = raw.rstrip('/').partition('/conversations/')
            return f"{head}/conversations/{tail.split('/')[0]}"
    return None


# ── Suggestion introspection (logging only) ──────────────────────────────────
# Google emits camelCase (REST/JSON) and snake_case (proto) depending on
# serialization, so every lookup checks both.
#
# This profile runs BOTH systems side by side:
#   - generators  → generateSuggestionsResponse.{generatorSuggestionAnswers,
#                   systemActionSuggestions}
#   - legacy      → suggestConversationSummaryResponse, suggestFaqAnswersResponse

def _pick(d, *keys):
    for k in keys:
        if isinstance(d, dict) and k in d:
            return d[k]
    return None


def _as_list(value):
    if value is None:
        return []
    if isinstance(value, dict):
        return [value]
    return value if isinstance(value, list) else []


def _suggestion_results(data_object: dict) -> list:
    return _as_list(_pick(data_object, 'suggestionResults', 'suggestion_results'))


def _generator_answers(result: dict) -> list:
    response = _pick(result, 'generateSuggestionsResponse', 'generate_suggestions_response')
    if not isinstance(response, dict):
        return []
    return _as_list(
        _pick(response, 'generatorSuggestionAnswers', 'generator_suggestion_answers')
    )


_LEGACY_SUMMARY_KEYS = (
    'suggestConversationSummaryResponse',
    'suggest_conversation_summary_response',
)


def _has_summary(data_object: dict) -> bool:
    """True if this payload carries a summary — legacy or generator shape."""
    for result in _suggestion_results(data_object):
        if not isinstance(result, dict):
            continue
        if any(k in result for k in _LEGACY_SUMMARY_KEYS):
            return True
        for answer in _generator_answers(result):
            suggestion = _pick(answer, 'generatorSuggestion', 'generator_suggestion')
            if isinstance(suggestion, dict) and _pick(
                suggestion, 'summarySuggestion', 'summary_suggestion'
            ):
                return True
    return False


def _suggestion_types(data_object: dict) -> list:
    """
    Names what actually arrived, drilling INTO generateSuggestionsResponse.
    Without this you only see ['generateSuggestionsResponse'] and can't tell a
    summary from a coaching tip from a system action.
    """
    types = []
    for result in _suggestion_results(data_object):
        if not isinstance(result, dict):
            continue
        for key in result.keys():
            if key in ('error', 'generateSuggestionsResponse', 'generate_suggestions_response'):
                continue
            types.append(key)

        response = _pick(result, 'generateSuggestionsResponse', 'generate_suggestions_response')
        if isinstance(response, dict):
            for answer in _generator_answers(result):
                suggestion = _pick(answer, 'generatorSuggestion', 'generator_suggestion')
                if isinstance(suggestion, dict):
                    types.extend(
                        f'generator:{k}' for k in suggestion.keys()
                        if k not in ('toolCallInfo', 'tool_call_info')
                    )
            system_actions = _pick(
                response, 'systemActionSuggestions', 'system_action_suggestions'
            )
            if system_actions:
                types.append(f'systemActions[{len(_as_list(system_actions))}]')
    return types


# ─── Summarization (pull via suggestConversationSummary) ───────────────────────
#
# Summarization is NOT event-based — Agent Assist never pushes it to the
# agent-assist topic. It has to be asked for. This is the only place that
# happens.
#
# Response shape (confirmed against a live 200 OK):
#   {
#     "summary": {
#       "text": "situation_concise\n...\naction_concise\n...",
#       "answerRecord": "projects/{p}/locations/global/answerRecords/{id}",
#       "textSections": {
#         "situation_concise": "...",
#         "action_concise": "...",
#         "resolution": "N",
#         "customer_satisfaction": "N",
#         "Call Summary": "..."
#       }
#     }
#   }
#
# `textSections` is the useful field — a flat map the UI can render
# section-by-section. `text` is the same content concatenated into one blob.
#
# The SDK is imported INSIDE the functions, not at module scope. An import
# that drags in a conflicting protobuf can fail container startup, which
# would take down live streaming along with everything else.


def _get_dialogflow_client():
    """
    Builds (once) a Conversations client.

    Location here is 'global', so the DEFAULT endpoint is correct. Only set a
    regional api_endpoint if DIALOGFLOW_LOCATION is ever changed to a region —
    mismatching the two yields NOT_FOUND.
    """
    global _dialogflow_client
    if _dialogflow_client is not None:
        return _dialogflow_client

    from google.cloud import dialogflow_v2 as dialogflow
    from google.api_core.client_options import ClientOptions

    with _dialogflow_client_lock:
        if _dialogflow_client is None:
            if DIALOGFLOW_LOCATION and DIALOGFLOW_LOCATION != 'global':
                endpoint = f'{DIALOGFLOW_LOCATION}-dialogflow.googleapis.com'
                _dialogflow_client = dialogflow.ConversationsClient(
                    client_options=ClientOptions(api_endpoint=endpoint)
                )
                log_info("Dialogflow client built", endpoint=endpoint)
            else:
                _dialogflow_client = dialogflow.ConversationsClient()
                log_info("Dialogflow client built", endpoint="global (default)")
    return _dialogflow_client


def _summary_to_dict(response) -> dict:
    """
    Flattens SuggestConversationSummaryResponse into plain JSON.

    Returns the same field names the REST API uses, so what lands in Redis
    matches what you saw in Postman.
    """
    summary = getattr(response, 'summary', None)
    if summary is None:
        return {}

    text_sections = {}
    raw_sections = getattr(summary, 'text_sections', None)
    if raw_sections:
        try:
            text_sections = dict(raw_sections)
        except Exception:
            text_sections = {}

    return {
        'text': getattr(summary, 'text', '') or '',
        'textSections': text_sections,
        # Handle for AnswerRecords.UpdateAnswerRecord — this is what a
        # thumbs up/down on the summary would reference.
        'answerRecord': getattr(summary, 'answer_record', '') or '',
        'latestMessage': getattr(response, 'latest_message', '') or '',
        'contextSize': getattr(response, 'context_size', 0),
    }


def _store_and_publish_summary(conversation_id: str, summary_payload: dict):
    """
    Stores the summary and publishes it straight to the live Redis channel.

    Deliberately NOT republished to the Pub/Sub topic: we're already inside the
    interceptor, so a round trip through Google just to receive our own message
    back would add latency, need a publisher grant, and risk a loop. The Redis
    channel is what the WebSocket is subscribed to.

    Wrapped in the same envelope a real pushed agent-assist event would have,
    so the connector needs no special-casing.
    """
    meta_key = f'conversation:{conversation_id}:meta'
    turns_key = f'conversation:{conversation_id}:turns'

    data_object = {
        'conversation_id': conversation_id,
        'suggestionResults': [
            {'suggestConversationSummaryResponse': {'summary': summary_payload}}
        ],
    }
    msg_data = {
        'conversation_id': conversation_id,
        'conversation_name': conversation_id,
        'data': data_object,
        'data_type': 'agent-assist-notifications-event',
        'ack_time': _utc_now(),
        'publish_time': None,
        'message_id': f'summary-{conversation_id}',
        'source': 'interceptor-pull',   # distinguishes this from a pushed event
    }
    encoded = json.dumps(msg_data)

    try:
        redis_client.hset(
            meta_key,
            mapping={
                'last_summary': json.dumps(data_object),
                'last_summary_sections': json.dumps(summary_payload.get('textSections', {})),
                'last_summary_text': summary_payload.get('text', ''),
                'last_summary_answer_record': summary_payload.get('answerRecord', ''),
                'last_summary_at': msg_data['ack_time'],
            }
        )
        redis_client.expire(meta_key, CONVERSATION_DATA_TTL_SECONDS)

        # Only append to :turns if agent-assist buffering is on, so the
        # connector's replay never sees an entry shape it wasn't built for.
        if BUFFER_AGENT_ASSIST:
            redis_client.rpush(turns_key, encoded)
            redis_client.expire(turns_key, CONVERSATION_DATA_TTL_SECONDS)

        log_info(
            "Stored summary",
            conversation_id=conversation_id,
            key=meta_key,
            sections=list(summary_payload.get('textSections', {}).keys()),
        )
    except Exception as store_err:
        log_error("Failed to store summary", conversation_id=conversation_id, error=str(store_err))

    try:
        server_id_raw = redis_client.get(conversation_id)
        if server_id_raw is None:
            log_info(
                "Summary stored but no active viewer; readable from :meta on next join",
                conversation_id=conversation_id,
            )
            return
        server_id = server_id_raw.decode('utf-8')
        channel = f'{server_id}:{conversation_id}'
        receivers = redis_client.publish(channel, encoded)
        log_info(
            "Summary published to live channel",
            conversation_id=conversation_id,
            channel=channel,
            subscribers=receivers,
        )
    except Exception as pub_err:
        log_error("Failed to live-publish summary", conversation_id=conversation_id, error=str(pub_err))


def _fetch_summary_worker(conversation_id: str, conversation_path: str):
    """
    Calls suggestConversationSummary with retries.

    `latest_message` is deliberately omitted — the API defaults to the latest
    message of the conversation, which is exactly what we want at end of call.
    That removes any need to track message resource paths during the call.
    """
    from google.cloud import dialogflow_v2 as dialogflow

    started = time.monotonic()
    if SUMMARY_INITIAL_DELAY_SECONDS > 0:
        time.sleep(SUMMARY_INITIAL_DELAY_SECONDS)

    last_error = None
    for attempt in range(1, SUMMARY_MAX_ATTEMPTS + 1):
        try:
            client = _get_dialogflow_client()
            request = dialogflow.SuggestConversationSummaryRequest(
                conversation=conversation_path,
                context_size=SUMMARY_CONTEXT_SIZE,
            )
            log_info(
                "Requesting summary",
                conversation_id=conversation_id,
                conversation_path=conversation_path,
                attempt=attempt,
                max_attempts=SUMMARY_MAX_ATTEMPTS,
                context_size=SUMMARY_CONTEXT_SIZE,
            )
            response = client.suggest_conversation_summary(request=request)
            summary_payload = _summary_to_dict(response)

            if summary_payload.get('text') or summary_payload.get('textSections'):
                log_info("Summary received", conversation_id=conversation_id, attempt=attempt)
                _store_and_publish_summary(conversation_id, summary_payload)
                # Metric logs are written whatever ENVIRONMENT's level is, so
                # summary outcomes stay visible in prod (level ERROR).
                log_metric(
                    "summary_fetch",
                    status="success",
                    conversation_id=conversation_id,
                    attempts=attempt,
                    duration_ms=int((time.monotonic() - started) * 1000),
                )
                return

            last_error = 'empty summary returned'
            log_warning(
                "Summary came back empty; retrying",
                conversation_id=conversation_id,
                attempt=attempt,
                max_attempts=SUMMARY_MAX_ATTEMPTS,
            )
        except Exception as api_err:
            last_error = str(api_err)
            log_warning(
                "suggestConversationSummary failed",
                conversation_id=conversation_id,
                attempt=attempt,
                max_attempts=SUMMARY_MAX_ATTEMPTS,
                error=last_error,
            )

        if attempt < SUMMARY_MAX_ATTEMPTS:
            time.sleep(SUMMARY_RETRY_BACKOFF_SECONDS * attempt)

    log_error(
        "Gave up fetching summary",
        conversation_id=conversation_id,
        attempts=SUMMARY_MAX_ATTEMPTS,
        error=str(last_error),
    )
    log_metric(
        "summary_fetch",
        status="failed",
        conversation_id=conversation_id,
        attempts=SUMMARY_MAX_ATTEMPTS,
        duration_ms=int((time.monotonic() - started) * 1000),
        error=str(last_error),
    )
    # Record the failure so the UI can show "summary unavailable" rather than
    # spinning forever waiting for something that is never coming.
    try:
        meta_key = f'conversation:{conversation_id}:meta'
        redis_client.hset(meta_key, mapping={
            'summary_error': str(last_error)[:500],
            'summary_error_at': _utc_now(),
        })
        redis_client.expire(meta_key, CONVERSATION_DATA_TTL_SECONDS)
    except Exception as record_err:
        log_warning(
            "Could not record summary failure",
            conversation_id=conversation_id,
            error=str(record_err),
        )


def _fetch_summary_worker_safely(conversation_id: str, conversation_path: str):
    """
    An exception escaping a ThreadPoolExecutor task is stored on its Future and
    never printed, so the background path needs its own last-resort log.
    """
    try:
        _fetch_summary_worker(conversation_id, conversation_path)
    except Exception as worker_err:
        log_error(
            "Summary worker crashed",
            conversation_id=conversation_id,
            error=str(worker_err),
            traceback=traceback.format_exc(),
        )


def trigger_summary_fetch(conversation_id: str, data_object: dict):
    """Resolves the conversation path, takes a one-shot lock, runs the fetch."""
    if not SUMMARY_ON_END:
        return

    # Prefer the path Dialogflow itself used; fall back to reconstructing it.
    conversation_path = extract_conversation_path(data_object)
    if not conversation_path:
        try:
            stored = redis_client.hget(
                f'conversation:{conversation_id}:meta', 'conversation_path'
            )
            if stored:
                conversation_path = stored.decode('utf-8')
        except Exception as meta_err:
            log_warning(
                "Could not read stored conversation_path",
                conversation_id=conversation_id,
                error=str(meta_err),
            )
    if not conversation_path:
        conversation_path = (
            f'projects/{GCP_PROJECT_ID}/locations/{DIALOGFLOW_LOCATION}'
            f'/conversations/{conversation_id}'
        )
        log_info(
            "Reconstructed conversation path",
            conversation_id=conversation_id,
            conversation_path=conversation_path,
        )

    # Pub/Sub redelivers; a duplicate ENDED would fire a second billable call.
    lock_key = f'summary:lock:{conversation_id}'
    try:
        if not redis_client.set(lock_key, '1', nx=True, ex=SUMMARY_LOCK_TTL_SECONDS):
            log_info("Summary already requested; skipping", conversation_id=conversation_id)
            return
    except Exception as lock_err:
        log_warning("Could not take summary lock", conversation_id=conversation_id, error=str(lock_err))

    if SUMMARY_INLINE:
        log_info("Running inline summary fetch", conversation_id=conversation_id)
        _fetch_summary_worker_safely(conversation_id, conversation_path)
    else:
        log_info("Dispatching background summary fetch", conversation_id=conversation_id)
        _get_executor().submit(_fetch_summary_worker_safely, conversation_id, conversation_path)


# ─── Main handler ──────────────────────────────────────────────────────────────

def cloud_pubsub_handler(envelope: dict, data_type: str) -> bool:
    """
    Decodes and processes a Pub/Sub push envelope.
    Buffers to Redis (keyed by SHORT conversation id) and live-publishes to
    the connected UI-connector instance if a viewer is registered.
    """

    try:
        if not envelope:
            log_warning("No Pub/Sub message received", data_type=data_type)
            return True

        if not isinstance(envelope, dict) or 'message' not in envelope:
            log_warning("Invalid Pub/Sub envelope; missing 'message'", data_type=data_type)
            return True

        pubsub_message = envelope['message']
        participant_role = ""
        new_recognition_result_message_id = ""

        if not isinstance(pubsub_message, dict):
            log_warning(
                "Invalid Pub/Sub message; 'message' inside the envelope must be a JSON object",
                data_type=data_type,
                docs="https://cloud.google.com/pubsub/docs/reference/rest/v1/PubsubMessage",
            )
            return True

        # Extract attributes
        if 'attributes' in pubsub_message:
            attributes = pubsub_message['attributes']
            if isinstance(attributes, dict):
                participant_role = attributes.get('participant_role', '')
                new_recognition_result_message_id = attributes.get('message_id', '')

        if 'data' not in pubsub_message:
            log_warning(
                "Pub/Sub message has no 'data' field",
                data_type=data_type,
                message_id=pubsub_message.get('messageId'),
            )
            return True

        # Decode base64 payload
        try:
            decoded_data = base64.b64decode(pubsub_message['data']).decode('utf-8')
            data_object = json.loads(decoded_data)
        except Exception as decode_err:
            log_error(
                "Failed to decode/parse Pub/Sub message",
                data_type=data_type,
                message_id=pubsub_message.get('messageId'),
                error=str(decode_err),
            )
            return True

        # Anything other than a JSON object has no conversation id to find, and
        # calling .keys() on it below would raise.
        if not isinstance(data_object, dict):
            log_warning(
                "Pub/Sub message data is not a JSON object",
                data_type=data_type,
                message_id=pubsub_message.get('messageId'),
                data_kind=type(data_object).__name__,
            )
            return True

        # ── Canonical SHORT conversation id (must match UI connector exactly) ──
        conversation_id = extract_short_conversation_id(data_object)
        if not conversation_id:
            log_warning(
                "Cannot extract conversation id from Pub/Sub request",
                data_type=data_type,
                payload_keys=list(data_object.keys()),
            )
            return True

        # Full/display name — for logging and payload context only.
        raw_conversation_name = (
            data_object.get('conversation_id')
            or data_object.get('conversation')
            or conversation_id
        )
        conversation_name = get_conversation_name_without_location(raw_conversation_name)

        msg_data = {
            'conversation_id': conversation_id,          # short id (canonical)
            'conversation_name': conversation_name,       # display name
            'data': data_object,
            'data_type': data_type,
            'ack_time': _utc_now(),
            'publish_time': pubsub_message.get('publishTime'),
            'message_id': pubsub_message.get('messageId'),
        }

        if data_type == 'intermediate-transcription-notification-event':
            msg_data['participant_role'] = participant_role
            msg_data['new_recognition_result_message_id'] = new_recognition_result_message_id

        # ── Logging ──
        # One structured line per event instead of the old 8-line banner, and
        # the whole block is guarded: a helper that throws here would otherwise
        # escape to the outer handler and SKIP THE LIVE PUBLISH BELOW —
        # logging must never be able to break message delivery.
        try:
            log_fields = {
                'conversation_id': conversation_id,
                'conversation_name': conversation_name,
                'data_type': data_type,
                'message_id': msg_data['message_id'],
                'publish_time': msg_data['publish_time'],
                'payload_keys': list(data_object.keys()),
            }
            if participant_role:
                log_fields['participant_role'] = participant_role
            if LOG_SUGGESTION_TYPES and data_type == 'agent-assist-notifications-event':
                try:
                    log_fields['suggestion_types'] = _suggestion_types(data_object)
                    log_fields['has_summary'] = _has_summary(data_object)
                except Exception as introspect_err:
                    log_fields['suggestion_introspection_error'] = str(introspect_err)

            log_info("Pub/Sub event received", **log_fields)
            # Full payload only at DEBUG, i.e. ENVIRONMENT=dev. It is the
            # single biggest log line the service writes.
            log_debug(
                "Pub/Sub event payload",
                conversation_id=conversation_id,
                message_id=msg_data['message_id'],
                payload=data_object,
            )
        except Exception as log_err:
            log_warning("Event logging failed", conversation_id=conversation_id, error=str(log_err))

        # ── Persist to Redis (always — independent of whether a viewer is connected) ──
        try:
            if data_type == 'new-message-notification-event':
                # Every chat/text turn is part of the permanent record.
                turns_key = f'conversation:{conversation_id}:turns'
                redis_client.rpush(turns_key, json.dumps(msg_data))
                # Rolling TTL: reset on every new turn, so this only expires
                # after CONVERSATION_DATA_TTL_SECONDS of INACTIVITY.
                redis_client.expire(turns_key, CONVERSATION_DATA_TTL_SECONDS)
                log_info(
                    "Buffered turn",
                    conversation_id=conversation_id,
                    key=turns_key,
                    ttl_seconds=CONVERSATION_DATA_TTL_SECONDS,
                )

            elif data_type == 'intermediate-transcription-notification-event':
                # Only persist the FINAL recognition result for an utterance.
                # Interim/partial STT results get revised as more audio arrives,
                # so buffering them would pollute history with stale text.
                # NOTE: interims are still LIVE-PUBLISHED below.
                is_final = data_object.get('is_final') or data_object.get('isFinal')
                if is_final:
                    turns_key = f'conversation:{conversation_id}:turns'
                    redis_client.rpush(turns_key, json.dumps(msg_data))
                    redis_client.expire(turns_key, CONVERSATION_DATA_TTL_SECONDS)
                    log_info(
                        "Buffered final recognition turn",
                        conversation_id=conversation_id,
                        key=turns_key,
                        ttl_seconds=CONVERSATION_DATA_TTL_SECONDS,
                    )
                else:
                    # DEBUG: this fires several times a second during a call.
                    log_debug(
                        "Interim recognition result; live-only, not buffered",
                        conversation_id=conversation_id,
                    )

            elif data_type == 'agent-assist-notifications-event':
                # ── OPTIONAL: buffer agent-assist events ─────────────────────
                # Without this they're live-only: anything arriving while no
                # viewer is connected is logged, acked with a 200, and lost.
                #
                # OFF by default because it puts a NEW entry shape into :turns.
                # The connector's normalizer must skip entries whose data_type
                # is 'agent-assist-notifications-event' before enabling this.
                if BUFFER_AGENT_ASSIST:
                    turns_key = f'conversation:{conversation_id}:turns'
                    meta_key = f'conversation:{conversation_id}:meta'

                    try:
                        for r in _suggestion_results(data_object):
                            if isinstance(r, dict) and r.get('error'):
                                log_warning(
                                    "Suggestion error",
                                    conversation_id=conversation_id,
                                    error=r['error'],
                                )
                    except Exception as inspect_err:
                        log_warning(
                            "Suggestion error inspection failed",
                            conversation_id=conversation_id,
                            error=str(inspect_err),
                        )

                    redis_client.rpush(turns_key, json.dumps(msg_data))
                    redis_client.expire(turns_key, CONVERSATION_DATA_TTL_SECONDS)
                    log_info(
                        "Buffered agent-assist event",
                        conversation_id=conversation_id,
                        key=turns_key,
                    )

                    try:
                        if _has_summary(data_object):
                            redis_client.hset(meta_key, mapping={
                                'last_summary': json.dumps(data_object),
                                'last_summary_at': msg_data['ack_time'],
                            })
                            redis_client.expire(meta_key, CONVERSATION_DATA_TTL_SECONDS)
                            log_info(
                                "Buffered pushed summary",
                                conversation_id=conversation_id,
                                key=meta_key,
                            )
                    except Exception as sum_err:
                        log_warning(
                            "Summary detection failed",
                            conversation_id=conversation_id,
                            error=str(sum_err),
                        )

            elif data_type == 'conversation-lifecycle-event':
                # Lifecycle is conversation-level STATE, not a turn — :meta, not :turns.
                meta_key = f'conversation:{conversation_id}:meta'

                # `type` is what real Dialogflow sends (CONVERSATION_FINISHED);
                # `status` is what the mock publisher sends (ENDED). Reading
                # only one of them means the other shape silently does nothing.
                status = (
                    data_object.get('type')
                    or data_object.get('status')
                    or ''
                )

                meta_updates = {
                    'last_lifecycle_status': status,
                    'last_lifecycle_update': msg_data['ack_time'],
                }
                # Capture the real resource path so the summary call doesn't
                # have to guess project/location. Only written when the
                # payload actually carries it.
                if SUMMARY_ON_END:
                    conversation_path = extract_conversation_path(data_object)
                    if conversation_path:
                        meta_updates['conversation_path'] = conversation_path

                redis_client.hset(meta_key, mapping=meta_updates)

                # ── Shortcut TTL (currently DISABLED) ──────────────────────
                # Keep OFF while SUMMARY_ON_END is on — the summary is fetched
                # after this event and would race a short expiry.
                #
                # if status in ENDED_LIFECYCLE_STATUSES:
                #     turns_key = f'conversation:{conversation_id}:turns'
                #     redis_client.expire(meta_key, ENDED_CONVERSATION_TTL_SECONDS)
                #     redis_client.expire(turns_key, ENDED_CONVERSATION_TTL_SECONDS)
                # else:
                #     redis_client.expire(meta_key, CONVERSATION_DATA_TTL_SECONDS)

                redis_client.expire(meta_key, CONVERSATION_DATA_TTL_SECONDS)
                log_info(
                    "Updated meta",
                    conversation_id=conversation_id,
                    key=meta_key,
                    lifecycle_status=status,
                    ttl_seconds=CONVERSATION_DATA_TTL_SECONDS,
                )

                # ── OPTIONAL: call ended → go GET the summary ────────────────
                # Summarization is never pushed to the topic. This is the only
                # place it gets asked for. Wrapped so a failure here can never
                # stop the live publish below.
                if SUMMARY_ON_END:
                    if str(status).upper() in SUMMARY_TRIGGER_STATUSES:
                        try:
                            log_info(
                                "Lifecycle status triggers summary fetch",
                                conversation_id=conversation_id,
                                lifecycle_status=status,
                            )
                            trigger_summary_fetch(conversation_id, data_object)
                        except Exception as summary_err:
                            log_error(
                                "Summary trigger failed",
                                conversation_id=conversation_id,
                                error=str(summary_err),
                            )
                    else:
                        # Explicit so a shape mismatch is visible instead of
                        # being a silent no-op.
                        log_info(
                            "Lifecycle status not in summary trigger set; no summary fetch",
                            conversation_id=conversation_id,
                            lifecycle_status=status,
                            trigger_statuses=sorted(SUMMARY_TRIGGER_STATUSES),
                            payload_keys=list(data_object.keys()),
                        )

        except Exception as persist_err:
            # Buffering/meta failures shouldn't block the live-publish below.
            log_error(
                "Redis persistence (turns/meta) failed",
                conversation_id=conversation_id,
                data_type=data_type,
                error=str(persist_err),
            )

        # ── Live publish (server_id lookup + channel keyed by SHORT id) ──
        try:
            server_id_raw = redis_client.get(conversation_id)
            if server_id_raw is None:
                log_info(
                    "No active viewer (server_id) for conversation; buffered only, "
                    "will be sent as HISTORY_BATCH on join",
                    conversation_id=conversation_id,
                    data_type=data_type,
                )
                return True

            server_id = server_id_raw.decode('utf-8')
            channel = f'{server_id}:{conversation_id}'

            receivers = redis_client.publish(channel, json.dumps(msg_data))
            log_info(
                "Published to live channel",
                conversation_id=conversation_id,
                channel=channel,
                message_id=msg_data['message_id'],
                data_type=data_type,
                subscribers=receivers,
            )
            if receivers == 0:
                log_warning(
                    "Published but ZERO subscribers received it; server_id key exists "
                    "but no live subscription on that instance",
                    conversation_id=conversation_id,
                    channel=channel,
                )

        except Exception as redis_err:
            log_error(
                "Redis operation failed",
                conversation_id=conversation_id,
                data_type=data_type,
                error=str(redis_err),
            )
            return True

        return True

    except Exception as e:
        log_error(
            "Unhandled error in cloud_pubsub_handler",
            data_type=data_type,
            error=str(e),
            traceback=traceback.format_exc(),
        )
        return True


# ─── Health ────────────────────────────────────────────────────────────────────

@app.get("/")
def health():
    return {
        "status": "interceptor running",
        "time": datetime.now(timezone.utc).isoformat(),
        "flags": {
            "LOG_SUGGESTION_TYPES": LOG_SUGGESTION_TYPES,
            "BUFFER_AGENT_ASSIST": BUFFER_AGENT_ASSIST,
            "SUMMARY_ON_END": SUMMARY_ON_END,
            "SUMMARY_INLINE": SUMMARY_INLINE,
        },
        "summarization": {
            "project": GCP_PROJECT_ID,
            "location": DIALOGFLOW_LOCATION,
            "trigger_statuses": sorted(SUMMARY_TRIGGER_STATUSES),
            "context_size": SUMMARY_CONTEXT_SIZE,
        },
    }


# ─── Manual summary trigger (debugging) ────────────────────────────────────────

@app.post("/admin/summary/{conversation_id}")
async def manual_summary(conversation_id: str):
    """
    Forces a summary fetch without waiting for a real call to end. Clears the
    one-shot lock first so it can be re-run. Gate or remove before TST.
    """
    if not SUMMARY_ON_END:
        return {"status": "disabled", "note": "set SUMMARY_ON_END=true"}
    try:
        redis_client.delete(f'summary:lock:{conversation_id}')
    except Exception as lock_err:
        log_warning("Could not clear summary lock", conversation_id=conversation_id, error=str(lock_err))
    trigger_summary_fetch(conversation_id, {'conversation_id': conversation_id})
    return {
        "status": "summary fetch dispatched",
        "conversation_id": conversation_id,
        "note": "check logs for 'Requesting summary' / 'Stored summary'",
    }


# ─── Routes ────────────────────────────────────────────────────────────────────

@app.post("/intercept/agent-assist-notifications-event", response_class=PlainTextResponse)
async def subscribe_suggestions(request: Request):
    """Receives human agent assist events from agent-assist-notifications topic."""
    envelope = await request.json()
    if not cloud_pubsub_handler(envelope, 'agent-assist-notifications-event'):
        return PlainTextResponse("Bad Request", status_code=400)

    return PlainTextResponse(
        "Received by cloud run service as a HumanAgentAssistantEvent.", status_code=200
    )


@app.post("/intercept/conversation-lifecycle-event", response_class=PlainTextResponse)
async def subscribe_lifecycle_events(request: Request):
    """Receives conversation lifecycle events from conversation-lifecycle topic."""
    envelope = await request.json()
    if not cloud_pubsub_handler(envelope, 'conversation-lifecycle-event'):
        return PlainTextResponse("Bad Request", status_code=400)

    return PlainTextResponse(
        "Received by cloud run service as a ConversationEvent.", status_code=200
    )


@app.post("/intercept/new-message-notification-event", response_class=PlainTextResponse)
async def subscribe_message_events(request: Request):
    """Receives new message events from new-message-notification topic."""
    envelope = await request.json()
    if not cloud_pubsub_handler(envelope, 'new-message-notification-event'):
        return PlainTextResponse("Bad Request", status_code=400)

    return PlainTextResponse(
        "Received by cloud run service as a ConversationEvent.", status_code=200
    )


@app.post("/intercept/intermediate-transcription-notification-event", response_class=PlainTextResponse)
async def subscribe_new_recognition_result_events(request: Request):
    """Receives intermediate transcription events from intermediate-transcription-notification topic."""
    envelope = await request.json()
    if not cloud_pubsub_handler(envelope, 'intermediate-transcription-notification-event'):
        return PlainTextResponse("Bad Request", status_code=400)
    return PlainTextResponse(
        "Received by cloud run service as a New recognition result notification.", status_code=200
    )
