import asyncio
import base64
import hashlib
import json
import logging
import math
import os
import re
import time
import traceback
from datetime import datetime, timezone
from typing import Dict, Optional, Set, Tuple

import httpx
from fastapi import FastAPI, WebSocket, WebSocketDisconnect, Query, HTTPException, Request
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from google.auth import jwt as google_jwt

from cryptography.hazmat.primitives import padding as sym_padding
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes

from utils import (
    ENVIRONMENT,
    LOG_LEVEL,
    log_debug,
    log_error,
    log_info,
    log_warning,
    trace_id_var,
)


# ─── Log scrubbing ────────────────────────────────────────────────────────────
# The ticket (or legacy token) rides in the query string. Everything this app
# logs goes through `log` below, which scrubs it. uvicorn still logs through
# the stdlib `logging` module (access lines, websocket handshakes), so the same
# scrubber is attached there as a filter. Neither covers GCP ILB or F5 XC
# request logs — those are written upstream, before the request reaches us.

_SECRET_PARAM_RE = re.compile(
    r"([?&](?:token|ticket|params|access_token|id_token)=)([^&\s\"']+)",
    re.IGNORECASE,
)
_BARE_JWT_RE = re.compile(
    r"\beyJ[A-Za-z0-9_\-]{8,}\.[A-Za-z0-9_\-]{8,}\.[A-Za-z0-9_\-]+"
)


def scrub_secrets(text: str) -> str:
    text = _SECRET_PARAM_RE.sub(r"\1REDACTED", text)
    text = _BARE_JWT_RE.sub("REDACTED_JWT", text)
    return text


class SecretScrubbingFilter(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:
        if isinstance(record.msg, str):
            record.msg = scrub_secrets(record.msg)
        if record.args:
            if isinstance(record.args, dict):
                record.args = {
                    k: scrub_secrets(v) if isinstance(v, str) else v
                    for k, v in record.args.items()
                }
            else:
                record.args = tuple(
                    scrub_secrets(a) if isinstance(a, str) else a
                    for a in record.args
                )
        return True


def _install_log_scrubbing() -> None:
    scrubber = SecretScrubbingFilter()
    for name in ("uvicorn.access", "uvicorn.error", "uvicorn", ""):
        logging.getLogger(name).addFilter(scrubber)
    # Filters on a logger only apply to records logged directly to it, not to
    # records propagating up from child loggers. Attaching to handlers catches
    # those too.
    for handler in logging.getLogger().handlers:
        handler.addFilter(scrubber)


_install_log_scrubbing()


# ─── Structured logging (utils.py) ────────────────────────────────────────────
# Every line is one JSON object on stdout, which Cloud Logging parses into
# severity + jsonPayload. Each line carries `conversation_id` as a field and
# leads its message with it, so both of these work in Logs Explorer:
#
#   jsonPayload.conversation_id="conv-52e5bf76"
#   jsonPayload.message:"conv-52e5bf76"
#
# Log level comes from ENVIRONMENT (see utils.py):
#   dev  → debug and up (per-message forwarding, subscribes)
#   sit / uat → info and up (connects, auth results, session summaries)
#   prod → errors only

_JSON_SAFE = (str, int, float, bool, type(None))
# utils._log(level, message, **kwargs) also writes these keys itself; a field
# with the same name would raise TypeError or overwrite them.
_RESERVED_FIELDS = {"level", "message", "severity", "environment", "service"}


class ConversationLog:
    """Thin wrapper over utils.py: adds the conversation prefix, scrubs secrets,
    and keeps every field JSON-serialisable so a log call can never raise."""

    @staticmethod
    def _emit(fn, conversation_id, message, fields):
        conv = conversation_id or "-"
        safe = {}
        for k, v in fields.items():
            if k in _RESERVED_FIELDS:
                k = f"field_{k}"
            if not isinstance(v, _JSON_SAFE):
                v = str(v)
            if isinstance(v, str):
                v = scrub_secrets(v)
            safe[k] = v
        try:
            fn(scrub_secrets(f"{conv} | {message}"), conversation_id=conv, **safe)
        except Exception:
            # Logging must never take a connection down.
            pass

    def debug(self, conversation_id, message, **fields):
        self._emit(log_debug, conversation_id, message, fields)

    def info(self, conversation_id, message, **fields):
        self._emit(log_info, conversation_id, message, fields)

    def warning(self, conversation_id, message, **fields):
        self._emit(log_warning, conversation_id, message, fields)

    def error(self, conversation_id, message, **fields):
        self._emit(log_error, conversation_id, message, fields)

    def exception(self, conversation_id, message, exc, **fields):
        """Error line with the exception type, text and traceback as fields."""
        fields["error"] = f"{type(exc).__name__}: {exc}"
        fields["traceback"] = "".join(
            traceback.format_exception(type(exc), exc, exc.__traceback__)
        )
        self._emit(log_error, conversation_id, message, fields)


log = ConversationLog()


def bind_trace(headers) -> None:
    """
    Attach the Cloud Trace id to every log line of this request, so Logs
    Explorer groups a connection's lines under the request that opened it.
    Header format: X-Cloud-Trace-Context: TRACE_ID/SPAN_ID;o=1
    """
    raw = headers.get("x-cloud-trace-context") or ""
    trace_id_var.set(raw.split("/", 1)[0].strip() if raw else "")


app = FastAPI(title="UI Connector — WebSocket Gateway")

# CORS — lock down to frontend domain in production
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.middleware("http")
async def _trace_http_requests(request: Request, call_next):
    # HTTP only — FastAPI's http middleware does not run for websockets, so
    # websocket_endpoint calls bind_trace() itself.
    bind_trace(request.headers)
    return await call_next(request)


# ─── Config ───────────────────────────────────────────────────────────────────
PROJECT_ID  = os.environ.get("GCP_PROJECT_ID", "adtgcp-ent-dev-ccs-tlcm-fe10")
LOCATION    = os.environ.get("LOCATION", "us-central1")

# Key for the buffered-turns list written by the interpreter.
# Must match conversation_id EXACTLY as the interpreter writes it
# (the short id, e.g. "conv-52e5bf76" — NOT the full resource path).
TURNS_KEY_TEMPLATE = "conversation:{conversation_id}:turns"
META_KEY_TEMPLATE = "conversation:{conversation_id}:meta"

# TTL (seconds) for the server_id lookup key, so a crashed instance doesn't
# leave a stale pointer forever. Refreshed on every connect; cleared on disconnect.
SERVER_ID_KEY_TTL = 3600


# ─── Auth config ──────────────────────────────────────────────────────────────

ALLOWED_SAS = {
    s.strip().lower()
    for s in os.environ.get("ALLOWED_SAS", "").split(",")
    if s.strip()
}
EXPECTED_AUDIENCE = os.environ.get("WS_TOKEN_AUDIENCE", "").strip()
CLOCK_SKEW_SECONDS = int(os.environ.get("WS_TOKEN_CLOCK_SKEW", "10"))
SINGLE_USE_TOKENS = os.environ.get("WS_TOKEN_SINGLE_USE", "false").lower() == "true"
ENFORCE_CONV_AUTHZ = os.environ.get("WS_ENFORCE_CONV_AUTHZ", "false").lower() == "true"

VALID_ISSUERS = ("https://accounts.google.com", "accounts.google.com")
GOOGLE_CERTS_URL = "https://www.googleapis.com/oauth2/v1/certs"

# Namespaced so it cannot collide with join_conversation(), which uses the bare
# conversation_id as a Redis key.
REPLAY_KEY_TEMPLATE = "ws:tok:{fingerprint}"


# ─── Ticket config ────────────────────────────────────────────────────────────
# The encrypted ticket minted by Apex. The plaintext is JSON with exactly two
# fields — there is NO Google token inside:
#
#   {"conversation_id": "conv-52e5bf76", "timestamp": 1756963200000}
#
# Wire format:
#
#   ticket = base64( IV(16) || AES-256-CBC/PKCS#7(plaintext) )
#
# = exactly what Apex Crypto.encryptWithManagedIV('AES256', key, blob) returns,
# base64-encoded. The key is WS_TICKET_KEY, used directly. A ticket that decrypts
# to valid JSON with a conversation_id and a timestamp younger than
# TICKET_MAX_AGE seconds is the whole credential.
#
# NOTE: there is deliberately no MAC. The ticket proves only that its bytes
# decrypt under the key; it is not tamper-evident. WS_TICKET_SINGLE_USE=true
# (replay guard) and rate limiting /ws at F5 are the main compensating controls.

WS_AUTH_MODE = os.environ.get("WS_AUTH_MODE", "both").strip().lower()
if WS_AUTH_MODE not in ("ticket", "token", "both"):
    raise RuntimeError(
        f"WS_AUTH_MODE must be one of ticket|token|both, got {WS_AUTH_MODE!r}"
    )

# A ticket is accepted only while it is strictly younger than this many seconds.
TICKET_MAX_AGE = int(os.environ.get("WS_TICKET_MAX_AGE", "10"))
TICKET_SINGLE_USE = os.environ.get("WS_TICKET_SINGLE_USE", "false").lower() == "true"

TICKET_CLAIM_KEY_TEMPLATE = "ws:tkt:{fingerprint}"

# A ticket is consumed at the handshake and carries no session expiry of its
# own, so a ticket session gets a fixed lifetime for close_at_token_expiry().
# Matched to BackendConfig timeoutSec so the LB and the app agree on when the
# socket dies.
TICKET_SESSION_TTL = 3600


def _load_key(var_name: str) -> Optional[bytes]:
    """
    Load a base64 32-byte key from the environment.

    Raises at import time rather than on first connect — a bad key should kill
    the container where it is obvious, not surface as every handshake failing
    with a generic invalid_ticket an hour later.
    """
    raw = os.environ.get(var_name, "").strip()
    if not raw:
        return None
    try:
        key = base64.b64decode(raw, validate=True)
    except Exception as exc:
        log.error(None, f"{var_name} is not valid base64 — refusing to start", error=str(exc))
        raise RuntimeError(f"{var_name} is not valid base64: {exc}") from exc
    if len(key) != 32:
        log.error(None, f"{var_name} has the wrong length — refusing to start", decoded_bytes=len(key))
        raise RuntimeError(
            f"{var_name} decoded to {len(key)} bytes; expected 32 (AES-256)."
        )
    return key


def _key_fp(key: Optional[bytes]) -> Optional[str]:
    """First 12 hex of SHA-256(key). Safe to log; Salesforce computes the same."""
    return hashlib.sha256(key).hexdigest()[:12] if key else None


# ONE shared AES-256 key. Salesforce and this service hold the same value.
TICKET_KEY = _load_key("WS_TICKET_KEY")

if WS_AUTH_MODE in ("ticket", "both") and TICKET_KEY is None:
    if WS_AUTH_MODE == "ticket":
        log.error(None, "WS_AUTH_MODE=ticket but WS_TICKET_KEY is unset — refusing to start")
        raise RuntimeError(
            "WS_AUTH_MODE=ticket but WS_TICKET_KEY is unset — no connection "
            "could ever authenticate."
        )
    log.warning(None, "WS_TICKET_KEY unset — ticket auth unavailable, only the legacy ?token= path will work")

if WS_AUTH_MODE in ("token", "both"):
    if not EXPECTED_AUDIENCE:
        log.warning(
            None,
            "WS_TOKEN_AUDIENCE unset — audience validation SKIPPED on the legacy ?token= path. "
            "Set this before this leaves DEV.",
        )
    if not ALLOWED_SAS:
        log.warning(None, "ALLOWED_SAS empty — any verified Google identity is accepted on the legacy ?token= path")


# ─── WebSocket Close Codes ────────────────────────────────────────────────────
# Standard RFC 6455 codes used by this service:
#   1008 → Policy violation (auth failure)
#   1011 → Internal server error (unexpected failure)
#   1013 → Try again later (Redis/backend unavailable)
WS_CLOSE_POLICY_VIOLATION = 1008
WS_CLOSE_INTERNAL_ERROR  = 1011
WS_CLOSE_TRY_AGAIN_LATER = 1013

# RFC 6455 caps the close reason at 123 bytes. Longer strings raise on some
# websocket stacks rather than truncating, so every close reason is sliced.
WS_CLOSE_REASON_MAX = 123


# ─── Server-side Event Types (sent to client) ─────────────────────────────────
# Kept as constants so the frontend contract stays discoverable in one place.
EVENT_HISTORY_BATCH  = "HISTORY_BATCH"
EVENT_ERROR          = "ERROR"


# ─── Redis ──────────────────────────────────────────────────────────────────────
import redis.asyncio as aioredis
from redis.exceptions import (
    ConnectionError as RedisConnectionError,
    TimeoutError as RedisTimeoutError,
    RedisError,
)

redis_host = os.environ.get('REDISHOST', '100.72.86.38')
redis_port = int(os.environ.get('REDISPORT', 6379))
redis_client = aioredis.StrictRedis(
    host=redis_host,
    port=redis_port,
    health_check_interval=10,
    socket_connect_timeout=15,
    retry_on_timeout=True,
    socket_keepalive=True,
)


# ─── Startup summary ──────────────────────────────────────────────────────────
# One line per container start with the live config (never secret values), so
# "what was this revision running with?" is answerable from logs alone.
log.info(
    None,
    "UI connector starting",
    log_level=logging.getLevelName(LOG_LEVEL),
    auth_mode=WS_AUTH_MODE,
    ticket_key_fp=_key_fp(TICKET_KEY),
    ticket_max_age_s=TICKET_MAX_AGE,
    ticket_single_use=TICKET_SINGLE_USE,
    enforce_conv_authz=ENFORCE_CONV_AUTHZ,
    redis=f"{redis_host}:{redis_port}",
)


# ─── Google signing certs (cached) ────────────────────────────────────────────
# Used by the legacy ?token= path only. Fetching these on every handshake would
# add a Google round trip per connection. Cached in-process and honouring the
# endpoint's own Cache-Control max-age. Requires egress to www.googleapis.com —
# if the pod has no route out, EVERY token fails with verification_unavailable,
# which reads like a token problem but is a networking one.

_certs_cache: Dict[str, object] = {"certs": None, "expires_at": 0.0}
_certs_lock = asyncio.Lock()


async def _fetch_google_certs(force: bool = False) -> dict:
    now = time.time()
    if not force and _certs_cache["certs"] and now < _certs_cache["expires_at"]:
        return _certs_cache["certs"]

    async with _certs_lock:
        # Re-check inside the lock — another coroutine may have refreshed while
        # we waited.
        now = time.time()
        if not force and _certs_cache["certs"] and now < _certs_cache["expires_at"]:
            return _certs_cache["certs"]

        async with httpx.AsyncClient(timeout=5.0) as client:
            resp = await client.get(GOOGLE_CERTS_URL)
            resp.raise_for_status()
            certs = resp.json()

        ttl = 3600
        match = re.search(r"max-age=(\d+)", resp.headers.get("cache-control", ""))
        if match:
            ttl = max(int(match.group(1)), 60)

        _certs_cache["certs"] = certs
        _certs_cache["expires_at"] = time.time() + ttl
        log.debug(None, "Fetched Google signing certs", cert_count=len(certs), cache_ttl_s=ttl, forced=force)
        return certs


# ─── Auth types ───────────────────────────────────────────────────────────────

class AuthFailure(Exception):
    """`reason` is a short, stable string that is safe to send to the client."""

    def __init__(self, reason: str, detail: str = ""):
        self.reason = reason
        self.detail = detail
        super().__init__(f"{reason}: {detail}" if detail else reason)


class Principal:
    """The verified caller behind a websocket connection."""

    __slots__ = ("email", "subject", "expires_at", "fingerprint")

    def __init__(self, email: str, subject: str, expires_at: int, fingerprint: str):
        self.email = email
        self.subject = subject
        self.expires_at = expires_at
        self.fingerprint = fingerprint


def _token_fingerprint(token: str) -> str:
    """Short, non-reversible handle for a token or ticket. Safe to log."""
    return hashlib.sha256(token.encode("utf-8")).hexdigest()[:32]


async def verify_salesforce_token(token: Optional[str]) -> Principal:
    """
    Verify the Google-issued ID token supplied as the `token` query parameter
    (legacy path only — tickets no longer carry a token).

    Minted by Apex (GcpTokenService.getIdToken) with audience
    WS_TOKEN_AUDIENCE. Checks signature, issuer, audience, expiry, and the
    ALLOWED_SAS allowlist.

    Returns a Principal. RAISES AuthFailure on every rejection path — it does
    NOT return a bool. A Principal is always truthy, so a caller written as
    `if not await verify_salesforce_token(...)` would silently accept
    everything.
    """
    if not token or not token.strip():
        raise AuthFailure("missing_token")

    token = token.strip()

    # Cheap structural gate before spending CPU on RSA verification.
    if token.count(".") != 2 or len(token) > 8192:
        raise AuthFailure("malformed_token", f"len={len(token)}")

    fp = _token_fingerprint(token)

    try:
        certs = await _fetch_google_certs()
    except Exception as exc:
        log.exception(None, "Could not fetch Google signing certs", exc, fp=fp)
        raise AuthFailure("verification_unavailable", str(exc)) from exc

    def _decode(c):
        return google_jwt.decode(
            token,
            certs=c,
            audience=EXPECTED_AUDIENCE or None,
            clock_skew_in_seconds=CLOCK_SKEW_SECONDS,
        )

    try:
        claims = await asyncio.get_running_loop().run_in_executor(None, _decode, certs)
    except ValueError as exc:
        msg = str(exc).lower()
        if "expired" in msg:
            raise AuthFailure("token_expired", str(exc)) from exc
        if "audience" in msg:
            raise AuthFailure("bad_audience", str(exc)) from exc
        # Could be genuine tampering, or Google rotated its signing keys and our
        # cache is stale. Refetch once and retry before rejecting.
        log.debug(None, "Token failed verification, retrying with refreshed certs", fp=fp)
        try:
            certs = await _fetch_google_certs(force=True)
            claims = await asyncio.get_running_loop().run_in_executor(
                None, _decode, certs
            )
        except ValueError as exc2:
            raise AuthFailure("invalid_token", str(exc2)) from exc2
        except Exception as exc2:
            log.exception(None, "Cert refresh failed during retry", exc2, fp=fp)
            raise AuthFailure("verification_unavailable", str(exc2)) from exc2
    except Exception as exc:
        log.exception(None, "Unexpected token verification failure", exc, fp=fp)
        raise AuthFailure("verification_unavailable", str(exc)) from exc

    if claims.get("iss") not in VALID_ISSUERS:
        raise AuthFailure("invalid_issuer", str(claims.get("iss")))

    email = (claims.get("email") or "").lower()
    if not email:
        raise AuthFailure("no_email_claim")
    if not claims.get("email_verified", False):
        raise AuthFailure("email_unverified", email)
    if ALLOWED_SAS and email not in ALLOWED_SAS:
        raise AuthFailure("caller_not_allowed", email)

    exp = int(claims.get("exp", 0))

    # ─── Replay guard (raw ?token= path only) ─────────────────────────────────
    # The token rides in the URL, so it lands in ILB request logs, F5 XC access
    # logs, and browser history. Google ID tokens live ~1h and are not
    # single-use by nature. Burning the hash on first use collapses that window
    # to zero.
    #
    # HARD PREREQUISITE: Apex must mint a fresh token per connection attempt. If
    # GcpTokenService caches for the hour, the first connect works and every
    # reconnect dies with token_replayed. Confirm before enabling.
    if SINGLE_USE_TOKENS:
        ttl = max(exp - int(time.time()), 1)
        key = REPLAY_KEY_TEMPLATE.format(fingerprint=fp)
        try:
            first_use = await redis_client.set(key, "1", ex=ttl, nx=True)
        except Exception as exc:
            # Fail OPEN — a Memorystore blip should not black out the agent
            # desktop. Change to `raise` if policy requires fail-closed.
            log.warning(None, "Token replay guard skipped, Redis unavailable (allowing)", fp=fp, error=exc)
            first_use = True
        if not first_use:
            raise AuthFailure("token_replayed", email)

    return Principal(
        email=email,
        subject=claims.get("sub", ""),
        expires_at=exp,
        fingerprint=fp,
    )


# ─── Ticket decryption ────────────────────────────────────────────────────────
# Apex side:
#   Blob key     = EncodingUtil.base64Decode(<WS_TICKET_KEY>);
#   String json  = JSON.serialize(new Map<String, Object>{
#                      'conversation_id' => conversationId,
#                      'timestamp'       => DateTime.now().getTime() });
#   Blob iv_ct   = Crypto.encryptWithManagedIV('AES256', key, Blob.valueOf(json));
#   String t     = EncodingUtil.base64Encode(iv_ct);
#   url += '?params=' + EncodingUtil.urlEncode(t, 'UTF-8');
#
# Expected plaintext (JSON), field names accepted in either snake or camel case:
#   {"conversation_id": "conv-52e5bf76",
#    "timestamp": 1756963200000}        // Apex DateTime.getTime() → epoch MILLIS

_TICKET_CONV_FIELDS  = ("conversation_id", "conversationId", "convId", "conv_id")
_TICKET_TS_FIELDS    = ("timestamp", "ts", "iat", "issued_at", "issuedAt")


def _pick(payload: dict, names: Tuple[str, ...]):
    for n in names:
        v = payload.get(n)
        if v not in (None, ""):
            return v
    return None


def _b64decode_tolerant(value: str) -> bytes:
    """
    Decode base64 that has been through a URL.

    Standard base64 uses '+', '/' and '='. If Apex forgets EncodingUtil.urlEncode,
    every '+' arrives as a literal space and the blob decodes to garbage — which
    surfaces as a padding error and looks exactly like a key mismatch. Repair
    that, and accept the base64url alphabet too, so the wire format can change
    without a redeploy here.
    """
    if " " in value:
        log.warning(
            None,
            "Ticket contained spaces — repaired '+' mangled by URL decoding. "
            "Fix properly with EncodingUtil.urlEncode() on the Apex side.",
        )
        value = value.replace(" ", "+")
    value = value.replace("-", "+").replace("_", "/")
    value += "=" * ((-len(value)) % 4)
    return base64.b64decode(value, validate=False)


def decrypt_ticket(ticket: Optional[str]) -> dict:
    """
    Decrypt and validate an Apex-minted ticket. Returns the normalized payload:
        {"conversation_id": str, "issued_at": float, "age": float}

    Accepts the ticket only if it carries a conversation_id and its timestamp
    is strictly less than TICKET_MAX_AGE seconds old.

    Raises AuthFailure. Every decode/decrypt/parse failure collapses to the
    single reason "invalid_ticket" — distinguishing "padding was valid" from
    "padding was not" is precisely the signal a padding-oracle attack needs, and
    with no MAC in front of the cipher that distinction must never leak. Detail
    goes to the log, never to the client.
    """
    if not ticket or not ticket.strip():
        raise AuthFailure("missing_ticket")
    if TICKET_KEY is None:
        raise AuthFailure("ticket_auth_unavailable", "WS_TICKET_KEY not set")

    ticket = ticket.strip()
    if len(ticket) > 8192:
        raise AuthFailure("invalid_ticket", f"oversized len={len(ticket)}")

    try:
        blob = _b64decode_tolerant(ticket)
    except Exception as exc:
        raise AuthFailure("invalid_ticket", f"base64: {exc}") from exc

    if len(blob) < 32 or (len(blob) - 16) % 16 != 0:
        raise AuthFailure("invalid_ticket", f"bad blob len={len(blob)}")

    iv, ciphertext = blob[:16], blob[16:]
    try:
        decryptor = Cipher(algorithms.AES(TICKET_KEY), modes.CBC(iv)).decryptor()
        padded = decryptor.update(ciphertext) + decryptor.finalize()
        unpadder = sym_padding.PKCS7(128).unpadder()
        plaintext = unpadder.update(padded) + unpadder.finalize()
    except Exception as exc:
        raise AuthFailure("invalid_ticket", f"decrypt: {type(exc).__name__}") from exc

    try:
        payload = json.loads(plaintext.decode("utf-8"))
    except Exception as exc:
        raise AuthFailure("invalid_ticket", f"payload not JSON: {exc}") from exc
    if not isinstance(payload, dict):
        raise AuthFailure("invalid_ticket", f"payload is {type(payload).__name__}")

    # ── Freshness. Everything below here required the encryption key, so these
    #    reasons are safe to distinguish — they leak nothing an attacker without
    #    the key could reach.
    raw_ts = _pick(payload, _TICKET_TS_FIELDS)
    if raw_ts is None:
        raise AuthFailure("ticket_no_timestamp")
    try:
        ts = float(raw_ts)
    except (TypeError, ValueError):
        raise AuthFailure("ticket_no_timestamp", f"unparseable: {raw_ts!r}")
    # json.loads accepts NaN/Infinity, and NaN fails every comparison below —
    # which would let it straight through the age check.
    if not math.isfinite(ts):
        raise AuthFailure("ticket_no_timestamp", f"non-finite: {raw_ts!r}")
    # Apex DateTime.getTime() returns epoch MILLISECONDS. Anything past ~5138 in
    # seconds is milliseconds in disguise.
    if ts > 100_000_000_000:
        ts /= 1000.0

    # Sub-second precision on purpose: rounding to whole seconds would let a
    # 10.9s-old ticket through as "10s".
    age = time.time() - ts
    if age >= TICKET_MAX_AGE:
        raise AuthFailure("ticket_expired", f"age={age:.2f}s max={TICKET_MAX_AGE}s")
    if age < -CLOCK_SKEW_SECONDS:
        raise AuthFailure("ticket_not_yet_valid", f"age={age:.2f}s")

    # ── conversation_id is mandatory: it is the only thing the ticket attests
    #    to. Coerced to str — a JSON number is legal and Apex may emit one, but
    #    everything downstream (Redis keys, channel names) assumes a string.
    conv = _pick(payload, _TICKET_CONV_FIELDS)
    if conv is None or not str(conv).strip():
        raise AuthFailure("ticket_no_conversation_id")

    return {
        "conversation_id": str(conv).strip(),
        "issued_at": ts,
        "age": age,
    }


async def burn_ticket(ticket: str, fp: str) -> None:
    """
    Claim the ticket so it cannot be replayed.

    TTL covers the whole window in which the ticket could still pass
    decrypt_ticket(): a ticket stamped up to CLOCK_SKEW_SECONDS in the future
    stays valid for TICKET_MAX_AGE + CLOCK_SKEW_SECONDS, so the claim must live
    at least that long or a replay slips in after the key expires.

    NOTE: this makes every reconnect need a fresh ticket. Salesforce LWCs
    re-render and reconnect on their own schedule, so confirm Apex mints on every
    connect attempt (not once per call) before turning this on.
    """
    if not TICKET_SINGLE_USE:
        return
    key = TICKET_CLAIM_KEY_TEMPLATE.format(fingerprint=fp)
    ttl = TICKET_MAX_AGE + CLOCK_SKEW_SECONDS + 1
    try:
        # SET NX is itself atomic — no Lua needed for a claim-once check.
        first_use = await redis_client.set(key, "1", ex=ttl, nx=True)
    except Exception as exc:
        # Fail OPEN, matching the raw-token replay guard above.
        log.warning(None, "Ticket replay guard skipped, Redis unavailable (allowing)", fp=fp, error=exc)
        first_use = True
    if not first_use:
        raise AuthFailure("ticket_replayed")


async def authenticate_connection(
    ticket: Optional[str],
    token: Optional[str],
    conversation_id_param: Optional[str],
) -> Tuple[Principal, str, dict]:
    """
    Resolve a connection to (Principal, conversation_id, auth_info).

    Ticket path: the ticket carries only conversation_id + timestamp. If it
    decrypts to valid JSON and is younger than TICKET_MAX_AGE, the
    connection is allowed for the conversation_id INSIDE the ticket. A
    conversation_id in the query string is optional and must match.

    auth_info is a small dict of log fields describing how the caller
    authenticated (method, ticket age).

    Raises AuthFailure on every rejection path.
    """
    use_ticket = bool(ticket and ticket.strip())

    if WS_AUTH_MODE == "ticket" and not use_ticket:
        raise AuthFailure("missing_ticket")
    if WS_AUTH_MODE == "token" and use_ticket:
        # Ignoring it silently would hide a half-finished cutover.
        raise AuthFailure("ticket_auth_disabled")
    if WS_AUTH_MODE == "both" and not use_ticket and not (token and token.strip()):
        raise AuthFailure("missing_credential")

    if not use_ticket:
        principal = await verify_salesforce_token(token)
        if not conversation_id_param or not conversation_id_param.strip():
            raise AuthFailure("missing_conversation_id")
        return principal, conversation_id_param.strip(), {"auth_method": "token"}

    fp = _token_fingerprint(ticket.strip())
    payload = decrypt_ticket(ticket)
    await burn_ticket(ticket.strip(), fp)

    # No Google identity behind a ticket: a valid ticket proves the caller got
    # it from Apex (which holds the key) within the last TICKET_MAX_AGE seconds.
    principal = Principal(
        email=f"ticket:{fp[:12]}",
        subject=f"ticket:{fp}",
        expires_at=int(time.time()) + TICKET_SESSION_TTL,
        fingerprint=fp,
    )

    ticket_conv = payload["conversation_id"]
    param_conv = (conversation_id_param or "").strip()

    if param_conv and param_conv != ticket_conv:
        raise AuthFailure(
            "conversation_mismatch",
            f"ticket={ticket_conv} query={param_conv}",
        )

    return principal, ticket_conv, {
        "auth_method": "ticket",
        "ticket_age_s": round(payload["age"], 3),
    }


async def authorize_conversation(principal: Principal, conversation_id: str) -> None:
    """
    Authentication proves the connection came from Salesforce. It does NOT prove
    this agent is entitled to THIS conversation's transcript. Without a check
    here, any authenticated client can subscribe to any live conversation_id.

    Tickets are encrypted but not MAC'd, so they are not tamper-evident. This
    check is the server-side backstop against a ticket that names a conversation
    it should not — enable WS_ENFORCE_CONV_AUTHZ once the meta key is reliable.

    WARN-ONLY unless WS_ENFORCE_CONV_AUTHZ=true, because the meta key may not
    exist yet for a conversation that has only just started — enforcing
    immediately would drop legitimate early connects. Run warn-only first, watch
    for the "would REJECT" lines, confirm the interpreter always writes meta
    before the LWC connects, then enforce.
    """
    key = META_KEY_TEMPLATE.format(conversation_id=conversation_id)
    try:
        exists = await redis_client.exists(key)
    except Exception as exc:
        log.warning(conversation_id, "Authz check skipped, Redis unavailable (allowing)", error=exc)
        return

    if exists:
        return

    if ENFORCE_CONV_AUTHZ:
        raise AuthFailure("conversation_not_authorized", f"missing key: {key}")

    log.warning(
        conversation_id,
        "Authz would REJECT (warn-only): meta key missing",
        caller=principal.email,
        missing_key=key,
    )


# ─── Cloud Run / GKE instance identity ───────────────────────────────────────────────
_cached_instance_id: str = None


async def get_server_id() -> str:
    """
    Returns a stable identifier for THIS running container instance.

    TEMPORARILY HARDCODED for isolation testing — bypasses the metadata
    server call entirely so we can confirm join/HISTORY_BATCH logic works
    independently of instance-id resolution. Re-enable the real lookup
    (commented below) once confirmed.
    """
    return "1"

    # ── Real implementation (re-enable once isolation test passes) ──────────
    # global _cached_instance_id
    # if _cached_instance_id:
    #     return _cached_instance_id
    #
    # try:
    #     async with httpx.AsyncClient(timeout=2.0) as client:
    #         resp = await client.get(
    #             "http://metadata.google.internal/computeMetadata/v1/instance/id",
    #             headers={"Metadata-Flavor": "Google"},
    #         )
    #         resp.raise_for_status()
    #         _cached_instance_id = resp.text.strip()
    #         log.info(None, "Resolved instance id", instance_id=_cached_instance_id)
    # except Exception as e:
    #     import uuid
    #     _cached_instance_id = f"local-{uuid.uuid4().hex[:8]}"
    #     log.warning(None, "Metadata server unreachable, using fallback instance id",
    #                 instance_id=_cached_instance_id, error=e)
    #
    # return _cached_instance_id


# ─── Error helper ─────────────────────────────────────────────────────────────
async def send_error(
    websocket: WebSocket,
    code: str,
    message: str,
    conversation_id: str = None,
    recoverable: bool = True,
):
    """
    Send a structured ERROR event to the client. Never raises — if the socket
    is already gone, we just log it. This lets callers report a failure
    without needing to guard every send site.
    """
    payload = {
        "type": EVENT_ERROR,
        "code": code,
        "message": message,
        "conversationId": conversation_id,
        "recoverable": recoverable,
        "timestamp": now_iso(),
    }
    try:
        await websocket.send_json(payload)
        log.debug(conversation_id, "Sent ERROR event to client", code=code, recoverable=recoverable)
    except Exception as e:
        log.debug(conversation_id, "ERROR event not delivered, socket gone", code=code, error=e)


async def reject_connection(
    websocket: WebSocket,
    reason: str,
    close_code: int = WS_CLOSE_POLICY_VIOLATION,
    conversation_id: str = None,
):
    """
    Close a connection that failed auth or authz.

    Accept-then-close is deliberate: it lets the client read event.code and
    event.reason in onclose. Closing before accept surfaces in the browser as a
    bare 1006 with an empty reason, which is very hard to debug with F5 XC in
    the path. No payload data is ever sent before this close, so the security
    posture is identical either way.
    """
    try:
        await websocket.accept()
        await websocket.close(code=close_code, reason=reason[:WS_CLOSE_REASON_MAX])
    except Exception as e:
        log.debug(conversation_id, "Could not cleanly reject connection", reason=reason, error=e)


async def redis_listener(conversation_id: str, websocket: WebSocket, stats: dict):
    """
    Listens on Redis channel for a conversation and forwards all messages to
    the connected WebSocket client. Channel format: {server_id}:{conversation_id}
    """
    server_id = await get_server_id()
    channel = f'{server_id}:{conversation_id}'

    MAX_RECONNECT_ATTEMPTS = 5
    RECONNECT_BACKOFF_SECONDS = 2
    attempt = 0

    while attempt <= MAX_RECONNECT_ATTEMPTS:
        pubsub = redis_client.pubsub()
        try:
            await pubsub.subscribe(channel)
            log.debug(conversation_id, "Subscribed to Redis channel", channel=channel, attempt=attempt)

            if attempt > 0:
                log.info(conversation_id, "Live stream resumed", channel=channel, after_attempts=attempt)
                await send_error(
                    websocket,
                    code="STREAM_RESUMED",
                    message="Live stream resumed.",
                    conversation_id=conversation_id,
                    recoverable=True,
                )

            attempt = 0  # reset once a successful subscribe holds

            async for message in pubsub.listen():
                if message.get('type') != 'message':
                    continue
                try:
                    data = json.loads(message['data'])
                except (json.JSONDecodeError, TypeError) as e:
                    stats["dropped"] += 1
                    log.warning(conversation_id, "Dropped malformed pub/sub message", channel=channel, error=e)
                    continue

                try:
                    await websocket.send_json(data)
                    stats["forwarded"] += 1
                    log.debug(conversation_id, "Forwarded Redis message to socket", channel=channel)
                except WebSocketDisconnect:
                    log.debug(conversation_id, "Client gone while forwarding")
                    return
                except Exception as e:
                    log.warning(conversation_id, "Failed to forward message to client", error=e)
                    return

        except (RedisConnectionError, RedisTimeoutError) as e:
            attempt += 1
            log.warning(
                conversation_id,
                "Redis connection lost, retrying",
                channel=channel,
                attempt=attempt,
                max_attempts=MAX_RECONNECT_ATTEMPTS,
                error=e,
            )
            await send_error(
                websocket,
                code="STREAM_PAUSED",
                message=(
                    "Live stream temporarily paused — reconnecting to backend."
                ),
                conversation_id=conversation_id,
                recoverable=True,
            )
            if attempt > MAX_RECONNECT_ATTEMPTS:
                log.error(conversation_id, "Live stream could not be restored", channel=channel)
                await send_error(
                    websocket,
                    code="STREAM_UNAVAILABLE",
                    message=(
                        "Live stream could not be restored. "
                        "Please refresh to reconnect."
                    ),
                    conversation_id=conversation_id,
                    recoverable=False,
                )
                return
            await asyncio.sleep(RECONNECT_BACKOFF_SECONDS * attempt)

        except asyncio.CancelledError:
            log.debug(conversation_id, "Redis listener cancelled")
            raise

        except Exception as e:
            log.exception(conversation_id, "Unexpected Redis listener error", e, channel=channel)
            await send_error(
                websocket,
                code="STREAM_ERROR",
                message="An unexpected error stopped the live stream.",
                conversation_id=conversation_id,
                recoverable=False,
            )
            return

        finally:
            try:
                await pubsub.unsubscribe(channel)
                await pubsub.close()
            except Exception as e:
                log.debug(conversation_id, "pub/sub cleanup failed", channel=channel, error=e)


async def close_at_token_expiry(
    websocket: WebSocket,
    principal: Principal,
    conversation_id: str,
):
    """
    Bind the socket's lifetime to the credential that opened it.

    Legacy ?token= path: expires_at is the Google token's exp (~3600s).
    Ticket path: expires_at is handshake time + TICKET_SESSION_TTL (3600s),
    since the ticket itself is consumed at the handshake.

    BackendConfig timeoutSec is 3600, so both paths line up with the LB. The
    client sees a 1008 with reason "token_expired" and should fetch a fresh
    ticket and reconnect.
    """
    delay = max(principal.expires_at - int(time.time()), 0)
    await asyncio.sleep(delay)
    log.info(conversation_id, "Closing socket on session expiry", caller=principal.email)
    try:
        await websocket.close(
            code=WS_CLOSE_POLICY_VIOLATION,
            reason="token_expired",
        )
    except Exception as e:
        log.debug(conversation_id, "Session-expiry close failed, socket already gone", error=e)


# ─── Helpers ──────────────────────────────────────────────────────────────────

def build_conversation_name(conversation_id: str) -> str:
    return f"projects/{PROJECT_ID}/locations/{LOCATION}/conversations/{conversation_id}"

def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


# ─── Join / Leave conversation (Redis bookkeeping) ────────────────────────────

class JoinError(Exception):
    def __init__(self, code: str, message: str, recoverable: bool = False):
        super().__init__(message)
        self.code = code
        self.message = message
        self.recoverable = recoverable


async def join_conversation(conversation_id: str) -> list:
    server_id = await get_server_id()

    try:
        await redis_client.set(conversation_id, server_id, ex=SERVER_ID_KEY_TTL)
        log.debug(conversation_id, "Registered server pointer", server_id=server_id, ttl_s=SERVER_ID_KEY_TTL)
    except (RedisConnectionError, RedisTimeoutError) as e:
        log.error(conversation_id, "Redis unreachable while registering server pointer", error=e)
        raise JoinError(
            code="REDIS_UNAVAILABLE",
            message="Cannot reach live stream backend. Please try again shortly.",
            recoverable=True,
        )
    except RedisError as e:
        log.error(conversation_id, "Redis error while registering server pointer", error=e)
        raise JoinError(
            code="REDIS_ERROR",
            message="Backend error while joining the conversation.",
            recoverable=True,
        )

    turns_key = TURNS_KEY_TEMPLATE.format(conversation_id=conversation_id)
    try:
        raw_turns = await redis_client.lrange(turns_key, 0, -1)
    except (RedisConnectionError, RedisTimeoutError) as e:
        log.error(conversation_id, "Redis unreachable while loading history", error=e)
        raise JoinError(
            code="HISTORY_UNAVAILABLE",
            message=(
                "Connected, but couldn't load prior transcript. "
                "Live turns will still stream."
            ),
            recoverable=True,
        )
    except RedisError as e:
        log.error(conversation_id, "Redis error while loading history", error=e)
        raise JoinError(
            code="HISTORY_ERROR",
            message="Backend error while loading prior transcript.",
            recoverable=True,
        )

    turns = []
    skipped = 0
    for raw in raw_turns:
        try:
            turns.append(json.loads(raw))
        except (json.JSONDecodeError, TypeError):
            skipped += 1

    if skipped:
        log.warning(conversation_id, "Skipped malformed buffered turns", skipped=skipped, loaded=len(turns))
    log.debug(conversation_id, "Loaded buffered history", turns=len(turns), key=turns_key)

    return turns


async def leave_conversation(conversation_id: str):
    try:
        await redis_client.delete(conversation_id)
        log.debug(conversation_id, "Cleared server pointer")
    except Exception as e:
        log.warning(conversation_id, "Could not clear server pointer (TTL will clean up)", error=e)


# ─── Connection Manager ────────────────────────────────────────────────────────

class ConnectionManager:
    def __init__(self):
        self.active: Dict[str, Set[WebSocket]] = {}

    async def connect(self, conversation_id: str, websocket: WebSocket):
        await websocket.accept()
        if conversation_id not in self.active:
            self.active[conversation_id] = set()
        self.active[conversation_id].add(websocket)

    def disconnect(self, conversation_id: str, websocket: WebSocket):
        if conversation_id in self.active:
            self.active[conversation_id].discard(websocket)
            if not self.active[conversation_id]:
                del self.active[conversation_id]

    def is_active(self, conversation_id: str) -> bool:
        return conversation_id in self.active and len(self.active[conversation_id]) > 0

    def client_count(self, conversation_id: str) -> int:
        return len(self.active.get(conversation_id, ()))


manager = ConnectionManager()


# ─── Health ────────────────────────────────────────────────────────────────────

@app.get("/")
async def health():
    """
    Health endpoint reports Redis reachability so upstream monitoring can
    distinguish 'service up but backend down' from 'service down'.
    """
    redis_status = "unknown"
    try:
        pong = await redis_client.ping()
        redis_status = "connected" if pong else "no-response"
    except (RedisConnectionError, RedisTimeoutError) as e:
        redis_status = f"unreachable: {e}"
        log.error(None, "Health check: Redis unreachable", error=e)
    except Exception as e:
        redis_status = f"error: {e}"
        log.error(None, "Health check: Redis error", error=e)

    return JSONResponse({
        "status": "ui-connector running",
        "redis": redis_status,
        "active_conversations": list(manager.active.keys()),
        "time": now_iso(),
    })


@app.get("/auth-health")
async def auth_health():
    """
    Reports whether the pod can actually reach Google's signing certs, and what
    auth config is live. Use this to separate 'token is bad' from 'pod has no
    egress' without reading logs.

    Deliberately reports config presence and a key FINGERPRINT, never config
    values. ticket_key_fp = first 12 hex of SHA-256(WS_TICKET_KEY); Salesforce
    computes the same value to confirm both sides hold the same key without
    sending it again.
    """
    certs_status = "unknown"
    cert_count = 0
    try:
        certs = await _fetch_google_certs()
        cert_count = len(certs)
        certs_status = "reachable"
    except Exception as e:
        certs_status = f"unreachable: {e}"

    return JSONResponse({
        "google_certs": certs_status,
        "cert_count": cert_count,
        "audience_configured": bool(EXPECTED_AUDIENCE),
        "allowed_sas_count": len(ALLOWED_SAS),
        "single_use_tokens": SINGLE_USE_TOKENS,
        "enforce_conv_authz": ENFORCE_CONV_AUTHZ,
        "clock_skew_seconds": CLOCK_SKEW_SECONDS,
        "auth_mode": WS_AUTH_MODE,
        "ticket_key_fp": _key_fp(TICKET_KEY),
        "ticket_single_use": TICKET_SINGLE_USE,
        "ticket_max_age": TICKET_MAX_AGE,
        "environment": ENVIRONMENT,
        "log_level": logging.getLevelName(LOG_LEVEL),
        "time": now_iso(),
    })


# ─── WebSocket ─────────────────────────────────────────────────────────────────

# Auth failures that mean OUR side is broken (config / outage), not the client.
# These log at ERROR so they still show at ENVIRONMENT=prod.
_SERVER_SIDE_AUTH_REASONS = {"verification_unavailable", "ticket_auth_unavailable"}


@app.websocket("/ws")
async def websocket_endpoint(
    websocket: WebSocket,
    conversation_id: str = Query(None, description="CCAI Conversation ID"),
    params: str = Query(None, description="Encrypted ticket minted by Salesforce Apex"),
    ticket: str = Query(None, description="DEPRECATED alias for `params`"),
    token: str = Query(None, description="Google ID token (legacy path)"),
):
    """
    Frontend connects here to receive live transcript events.

    Ticket:  wss://dev.agentassist.adt.com/ws?params=<urlencoded_ticket>
    Legacy:  wss://dev.agentassist.adt.com/ws?conversation_id=<id>&token=<id_token>

    In ticket mode conversation_id comes from inside the ticket; passing it in
    the query string as well is allowed but must match.

    `?ticket=` is still accepted so an Apex build that has not switched to
    `?params=` keeps working during the cutover. `params` wins if both are sent.
    """
    bind_trace(websocket.headers)
    peer = websocket.client.host if websocket.client else "unknown"
    # Behind Cloud Run / ILB the socket peer is the proxy; the real client is the
    # first hop in X-Forwarded-For.
    client_ip = (websocket.headers.get("x-forwarded-for") or peer).split(",")[0].strip()
    url_conv = (conversation_id or "").strip() or None

    if not (params and params.strip()) and ticket and ticket.strip():
        log.warning(url_conv, "Ticket received as deprecated ?ticket= — switch Apex to ?params=", client_ip=client_ip)
        params = ticket

    log.debug(
        url_conv,
        "WebSocket handshake received",
        client_ip=client_ip,
        has_params=bool(params and params.strip()),
        has_token=bool(token and token.strip()),
        origin=websocket.headers.get("origin"),
    )

    # ── 1. Authenticate BEFORE establishing any routing ──────────────────────
    #    This also resolves conversation_id, since in ticket mode it is part of
    #    the credential rather than the URL.
    auth_started = time.monotonic()
    try:
        principal, conversation_id, auth_info = await authenticate_connection(
            params, token, conversation_id
        )
    except AuthFailure as af:
        emit = log.error if af.reason in _SERVER_SIDE_AUTH_REASONS else log.warning
        emit(
            url_conv,
            f"Rejected: {af.reason}",
            stage="authentication",
            reason=af.reason,
            detail=af.detail,
            client_ip=client_ip,
        )
        await reject_connection(websocket, af.reason, conversation_id=url_conv)
        return

    conversation_id = conversation_id.strip()

    log.debug(
        conversation_id,
        "Authenticated",
        caller=principal.email,
        fp=principal.fingerprint,
        session_ttl_s=principal.expires_at - int(time.time()),
        **auth_info,
    )

    # ── 2. Authorize this caller for THIS conversation ───────────────────────
    try:
        await authorize_conversation(principal, conversation_id)
    except AuthFailure as af:
        log.warning(
            conversation_id,
            f"Rejected: {af.reason}",
            stage="authorization",
            reason=af.reason,
            detail=af.detail,
            caller=principal.email,
            client_ip=client_ip,
        )
        await reject_connection(websocket, af.reason, conversation_id=conversation_id)
        return

    # ── 3. Accept and establish connection ───────────────────────────────────
    await manager.connect(conversation_id, websocket)
    started = time.monotonic()
    stats = {"forwarded": 0, "dropped": 0, "received": 0, "history_turns": 0}
    end_reason = "client_closed"
    close_code = None
    stream_task: asyncio.Task = None
    expiry_task: asyncio.Task = None

    try:
        # ── join-conversation: register server_id + replay buffered history ──
        try:
            buffered_turns = await join_conversation(conversation_id)
        except JoinError as je:
            await send_error(
                websocket,
                code=je.code,
                message=je.message,
                conversation_id=conversation_id,
                recoverable=je.recoverable,
            )
            await websocket.close(
                code=WS_CLOSE_TRY_AGAIN_LATER,
                reason=je.code,
            )
            end_reason, close_code = "join_failed", WS_CLOSE_TRY_AGAIN_LATER
            return
        except Exception as e:
            log.exception(conversation_id, "Unexpected error during join", e)
            await send_error(
                websocket,
                code="INTERNAL_ERROR",
                message="Unexpected error while joining the conversation.",
                conversation_id=conversation_id,
                recoverable=False,
            )
            await websocket.close(
                code=WS_CLOSE_INTERNAL_ERROR,
                reason="Join failed",
            )
            end_reason, close_code = "join_failed", WS_CLOSE_INTERNAL_ERROR
            return

        # ── Send history batch ──
        try:
            await websocket.send_json({
                "type": EVENT_HISTORY_BATCH,
                "conversationId": conversation_id,
                "turns": buffered_turns,
                "totalTurns": len(buffered_turns),
                "timestamp": now_iso(),
            })
            stats["history_turns"] = len(buffered_turns)
        except WebSocketDisconnect:
            end_reason = "client_gone_before_history"
            return

        log.info(
            conversation_id,
            "Connected",
            caller=principal.email,
            fp=principal.fingerprint,
            client_ip=client_ip,
            clients=manager.client_count(conversation_id),
            history_turns=len(buffered_turns),
            auth_ms=round((time.monotonic() - auth_started) * 1000),
            **auth_info,
        )

        # ── live stream: forward future Redis-published turns over this socket ──
        stream_task = asyncio.create_task(redis_listener(conversation_id, websocket, stats))

        # ── close the socket when the credential that opened it expires ──
        expiry_task = asyncio.create_task(
            close_at_token_expiry(websocket, principal, conversation_id)
        )

        # ── main receive loop: keep the socket alive ─────────────────────────
        # Client frame CONTENT is never logged (it may carry customer data);
        # only its size, at debug.
        while True:
            try:
                data = await websocket.receive_text()
                stats["received"] += 1
                log.debug(conversation_id, "Client message received", size=len(data))
            except WebSocketDisconnect as wd:
                close_code = wd.code
                if expiry_task.done():
                    end_reason = "session_expired"
                break

    except Exception as e:
        log.exception(conversation_id, "Unhandled WS error", e)
        end_reason, close_code = "internal_error", WS_CLOSE_INTERNAL_ERROR
        await send_error(
            websocket,
            code="INTERNAL_ERROR",
            message="An unexpected error occurred.",
            conversation_id=conversation_id,
            recoverable=False,
        )
        try:
            await websocket.close(
                code=WS_CLOSE_INTERNAL_ERROR,
                reason="Internal error",
            )
        except Exception:
            pass

    finally:
        for task in (stream_task, expiry_task):
            if task and not task.done():
                task.cancel()
                try:
                    await task
                except (asyncio.CancelledError, Exception):
                    pass

        manager.disconnect(conversation_id, websocket)

        # One summary line per connection.
        log.info(
            conversation_id,
            "Session closed",
            caller=principal.email,
            end_reason=end_reason,
            close_code=close_code,
            duration_s=round(time.monotonic() - started, 1),
            forwarded=stats["forwarded"],
            dropped=stats["dropped"],
            received=stats["received"],
            history_turns=stats["history_turns"],
            clients_left=manager.client_count(conversation_id),
        )

        if not manager.is_active(conversation_id):
            await leave_conversation(conversation_id)


# ─── Conversation Status ───────────────────────────────────────────────────────

@app.get("/conversation-status")
async def conversation_status(conversation_id: str = Query(None)):
    """Check if a conversation has active WebSocket clients."""
    if not conversation_id or not conversation_id.strip():
        raise HTTPException(
            status_code=400,
            detail="Query parameter 'conversation_id' is required.",
        )

    return JSONResponse({
        "conversation_id": conversation_id,
        "full_conversation_name": build_conversation_name(conversation_id),
        "active": manager.is_active(conversation_id),
        "connected_clients": len(manager.active.get(conversation_id, set())),
        "timestamp": now_iso(),
    })
