# UI Connector: deploy to Cloud Run

## What's in this folder

| File | Purpose |
| --- | --- |
| `main.py` | The WebSocket gateway (ticket auth, Redis pub/sub, history replay) |
| `utils.py` | Structured JSON logging used by `main.py` |
| `requirements.txt` | Pinned Python dependencies |
| `Dockerfile` | Container build; Cloud Run builds it automatically with `--source .` |
| `.gcloudignore` / `.dockerignore` | Keep `mint_ticket.py`, caches and zips out of the upload |

## Deploy (PowerShell, from this folder)

Updating the existing service keeps its current env vars, VPC and IAM settings:

```powershell
gcloud run deploy encrypt-ui-connector --source . --region us-central1 --timeout 3600
```

`--timeout 3600` lets a WebSocket stay open for the full 1-hour session; without it Cloud Run closes it after 5 minutes.

## Environment variables (set once; they persist across deploys)

| Variable | Value | Notes |
| --- | --- | --- |
| `WS_TICKET_KEY` | base64 of 32 bytes | Required. Same value as Salesforce `Ticket_Key__c`. Prefer a secret (below). |
| `WS_AUTH_MODE` | `ticket` | Only `?params=` tickets are accepted. |
| `ENVIRONMENT` | `dev` / `sit` / `uat` / `prod` | Sets the log level: dev = debug, sit/uat = info, prod = errors only. |
| `REDISHOST` / `REDISPORT` | Memorystore IP / `6379` | Needs the service's VPC access to stay as it is today. |
| `WS_TICKET_MAX_AGE` | `10` | Seconds a ticket stays valid. Default 10. |
| `WS_TICKET_SINGLE_USE` | `true` (recommended) | Stops a ticket being reused. |
| `WS_ENFORCE_CONV_AUTHZ` | `false`, later `true` | Rejects conversations with no meta key in Redis once enabled. |

```powershell
gcloud run services update encrypt-ui-connector --region us-central1 `
  --update-env-vars "WS_AUTH_MODE=ticket,ENVIRONMENT=dev,WS_TICKET_SINGLE_USE=true"

# Key from Secret Manager (create the secret once):
"<key>" | gcloud secrets create ws-ticket-key --data-file=-
gcloud run services update encrypt-ui-connector --region us-central1 `
  --update-secrets "WS_TICKET_KEY=ws-ticket-key:latest"
```

The service's runtime service account needs **Secret Manager Secret Accessor** on `ws-ticket-key`.

## Check the deployment

1. `GET /auth-health` → `ticket_key_fp` must equal the fingerprint `mint_ticket.py` prints, and `log_level` must match `ENVIRONMENT`.
2. Logs Explorer → the first line of a new revision is `UI connector starting`, with auth mode, key fingerprint and Redis host.

## Finding logs (Logs Explorer)

```
resource.type="cloud_run_revision"
resource.labels.service_name="encrypt-ui-connector"
jsonPayload.conversation_id="conv-52e5bf76"
```

| Message | Level | Meaning |
| --- | --- | --- |
| `Connected` | INFO | Ticket accepted, history sent, live stream starting |
| `Session closed` | INFO | One per connection: `end_reason`, `close_code`, `duration_s`, `forwarded` |
| `Rejected: <reason>` | WARNING | Bad ticket; `detail` says why (e.g. `age=12.01s`, `decrypt: ValueError`) |
| `Rejected: ticket_auth_unavailable` | ERROR | `WS_TICKET_KEY` missing on this revision |
| `Redis unreachable …` / `Live stream could not be restored` | ERROR | Backend problem, not a client problem |

Lines from one connection share a Cloud Trace id, so **Show entries for this trace** on any line pulls up the whole session. Tickets in uvicorn's own request lines are logged as `params=REDACTED`.
