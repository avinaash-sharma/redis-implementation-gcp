"""
Shared utilities:
- Environment-based structured logging
"""

import logging
import json
import os
import sys
from contextvars import ContextVar

# Context variables to store the trace ID and full context for the current request
trace_id_var = ContextVar("trace_id", default="")
trace_context_var = ContextVar("trace_context", default="")

PROJECT_ID = os.environ.get("GOOGLE_CLOUD_PROJECT", os.environ.get("PROJECT_ID", "adtgcp-ent-dev-ccs-tlcm-fe10"))
ENVIRONMENT = os.getenv("ENVIRONMENT", "dev").lower()

ENV_LOG_LEVEL_MAP = {
    "dev": logging.DEBUG,
    "sit": logging.INFO,
    "uat": logging.INFO,
    "prod": logging.ERROR
}

LOG_LEVEL = ENV_LOG_LEVEL_MAP.get(ENVIRONMENT, logging.INFO)

SERVICE_NAME = os.getenv("K_SERVICE", "audio-sync-service")

def _log(level, message, **kwargs):
    """
    Outputs a structured JSON log to stdout.
    Includes Google Cloud Trace context if available.
    """
    trace_id = trace_id_var.get()
    
    payload = {
        "severity": level.upper(),
        "message": message,
        "environment": ENVIRONMENT,
        "service": SERVICE_NAME,
        **kwargs
    }
    
    if trace_id:
        payload["logging.googleapis.com/trace"] = f"projects/{PROJECT_ID}/traces/{trace_id}"

    # Output directly to stdout as a single line JSON
    print(json.dumps(payload), file=sys.stdout)
    sys.stdout.flush()

def log_debug(message, **kwargs):
    if LOG_LEVEL <= logging.DEBUG:
        _log("debug", message, **kwargs)

def log_info(message, **kwargs):
    if LOG_LEVEL <= logging.INFO:
        _log("info", message, **kwargs)

def log_warning(message, **kwargs):
    if LOG_LEVEL <= logging.WARNING:
        _log("warning", message, **kwargs)

def log_error(message, **kwargs):
    if LOG_LEVEL <= logging.ERROR:
        _log("error", message, **kwargs)
