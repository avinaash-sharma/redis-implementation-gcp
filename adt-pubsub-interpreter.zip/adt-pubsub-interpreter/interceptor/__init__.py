"""ADT Pub/Sub Interceptor: Dialogflow Pub/Sub push events → Redis buffer + live channel."""
