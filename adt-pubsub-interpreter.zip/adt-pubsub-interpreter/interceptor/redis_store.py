"""
Redis client and the operations the interceptor performs on it.

Every write goes through here so the rolling-TTL rule lives in one place:
each write to :turns or :meta resets that key's expiry.
"""

from typing import NamedTuple, Optional

import redis
from redis.backoff import ExponentialBackoff
from redis.retry import Retry

from . import config
from .contract import live_channel, meta_key, server_id_key, turns_key

client = redis.Redis(
    host=config.REDIS_HOST,
    port=config.REDIS_PORT,
    health_check_interval=10,
    socket_connect_timeout=15,
    retry_on_timeout=True,
    socket_keepalive=True,
    retry=Retry(ExponentialBackoff(cap=5, base=1), 5),
    retry_on_error=[
        redis.exceptions.ConnectionError,
        redis.exceptions.TimeoutError,
        redis.exceptions.ResponseError,
    ],
)


class LivePublish(NamedTuple):
    channel: str
    receivers: int


# ─── Conversation buffer ──────────────────────────────────────────────────────

def append_turn(conversation_id: str, encoded_message: str) -> str:
    """RPUSH to :turns and reset its TTL. Returns the key written."""
    key = turns_key(conversation_id)
    client.rpush(key, encoded_message)
    client.expire(key, config.CONVERSATION_DATA_TTL_SECONDS)
    return key


def update_meta(conversation_id: str, fields: dict) -> str:
    """HSET fields on :meta and reset its TTL. Returns the key written."""
    key = meta_key(conversation_id)
    client.hset(key, mapping=fields)
    client.expire(key, config.CONVERSATION_DATA_TTL_SECONDS)
    return key


def get_meta_field(conversation_id: str, field: str) -> Optional[str]:
    raw = client.hget(meta_key(conversation_id), field)
    return raw.decode("utf-8") if raw else None


# ─── Live channel ─────────────────────────────────────────────────────────────

def publish_live(conversation_id: str, encoded_message: str) -> Optional[LivePublish]:
    """
    Publishes to the connector instance currently serving this conversation.
    Returns None when no viewer is registered (no server_id key).
    """
    server_id = client.get(server_id_key(conversation_id))
    if server_id is None:
        return None
    channel = live_channel(server_id.decode("utf-8"), conversation_id)
    return LivePublish(channel, client.publish(channel, encoded_message))


# ─── Summary one-shot lock ────────────────────────────────────────────────────
# Pub/Sub redelivers; a duplicate "call ended" event would otherwise fire a
# second billable suggestConversationSummary call.

def _summary_lock_key(conversation_id: str) -> str:
    return f"summary:lock:{conversation_id}"


def acquire_summary_lock(conversation_id: str) -> bool:
    return bool(
        client.set(
            _summary_lock_key(conversation_id),
            "1",
            nx=True,
            ex=config.SUMMARY_LOCK_TTL_SECONDS,
        )
    )


def release_summary_lock(conversation_id: str) -> None:
    client.delete(_summary_lock_key(conversation_id))
