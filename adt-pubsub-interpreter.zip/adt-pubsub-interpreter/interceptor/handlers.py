"""
Per-data_type handling: what each event type writes to Redis BEFORE the live
publish. The publish itself is the same for every type (see processor.py).

  new-message               → always buffered to :turns
  intermediate-transcription→ only FINAL results buffered; interims are live-only
  agent-assist              → buffered only with BUFFER_AGENT_ASSIST
  conversation-lifecycle    → state in :meta (not a turn); may trigger summary
"""

import json
from dataclasses import dataclass

from utils import log_debug, log_error, log_info, log_warning

from . import config, redis_store
from .contract import DataType
from .conversation import extract_conversation_path
from .suggestions import has_summary, suggestion_errors
from .summary import trigger_summary_fetch


@dataclass(frozen=True)
class Event:
    conversation_id: str   # SHORT id; every Redis key is built from this
    data_type: str
    data: dict             # decoded Pub/Sub payload
    message: dict          # envelope sent to the connector (contract.build_event_message)
    encoded: str           # json.dumps(message): buffered and published byte-for-byte
    participant_role: str = ""


def handle_new_message(event: Event) -> None:
    # Every chat/text turn is part of the permanent record.
    key = redis_store.append_turn(event.conversation_id, event.encoded)
    log_info(
        "Buffered turn",
        conversation_id=event.conversation_id,
        key=key,
        ttl_seconds=config.CONVERSATION_DATA_TTL_SECONDS,
    )


def handle_intermediate_transcription(event: Event) -> None:
    # Interim STT results get revised as more audio arrives, so buffering them
    # would pollute history with stale text. Only the FINAL result for an
    # utterance is kept; interims are still live-published.
    if event.data.get("is_final") or event.data.get("isFinal"):
        key = redis_store.append_turn(event.conversation_id, event.encoded)
        log_info(
            "Buffered final recognition turn",
            conversation_id=event.conversation_id,
            key=key,
            ttl_seconds=config.CONVERSATION_DATA_TTL_SECONDS,
        )
    else:
        log_debug("Interim recognition result; live-only, not buffered", conversation_id=event.conversation_id)


def handle_agent_assist(event: Event) -> None:
    # Without buffering, agent-assist events are live-only: anything arriving
    # while no viewer is connected is acked and lost. OFF by default because
    # it puts a NEW entry shape into :turns (see config.BUFFER_AGENT_ASSIST).
    if not config.BUFFER_AGENT_ASSIST:
        return

    cid = event.conversation_id
    try:
        for error in suggestion_errors(event.data):
            log_warning("Suggestion error", conversation_id=cid, error=error)
    except Exception as err:
        log_warning("Suggestion error inspection failed", conversation_id=cid, error=str(err))

    key = redis_store.append_turn(cid, event.encoded)
    log_info("Buffered agent-assist event", conversation_id=cid, key=key)

    try:
        if has_summary(event.data):
            meta = redis_store.update_meta(cid, {
                "last_summary": json.dumps(event.data),
                "last_summary_at": event.message["ack_time"],
            })
            log_info("Buffered pushed summary", conversation_id=cid, key=meta)
    except Exception as err:
        log_warning("Summary detection failed", conversation_id=cid, error=str(err))


def handle_lifecycle(event: Event) -> None:
    cid = event.conversation_id

    # Real Dialogflow sends `type` (CONVERSATION_FINISHED); the mock publisher
    # sends `status` (ENDED). Reading only one means the other silently no-ops.
    status = event.data.get("type") or event.data.get("status") or ""

    fields = {
        "last_lifecycle_status": status,
        "last_lifecycle_update": event.message["ack_time"],
    }
    # Save the real resource path so the summary call doesn't have to guess
    # project/location. Only written when the payload actually carries it.
    if config.SUMMARY_ON_END:
        conversation_path = extract_conversation_path(event.data)
        if conversation_path:
            fields["conversation_path"] = conversation_path

    # Rolling TTL. The shortcut TTL for ended calls stays disabled; see config.py.
    key = redis_store.update_meta(cid, fields)
    log_info(
        "Updated meta",
        conversation_id=cid,
        key=key,
        lifecycle_status=status,
        ttl_seconds=config.CONVERSATION_DATA_TTL_SECONDS,
    )

    if config.SUMMARY_ON_END:
        _maybe_trigger_summary(event, status)


def _maybe_trigger_summary(event: Event, status) -> None:
    """Call ended → go GET the summary. Must never stop the live publish that follows."""
    cid = event.conversation_id
    if str(status).upper() not in config.SUMMARY_TRIGGER_STATUSES:
        # Logged so a payload-shape mismatch is visible instead of a silent no-op.
        log_info(
            "Lifecycle status not in summary trigger set; no summary fetch",
            conversation_id=cid,
            lifecycle_status=status,
            trigger_statuses=sorted(config.SUMMARY_TRIGGER_STATUSES),
            payload_keys=list(event.data.keys()),
        )
        return

    try:
        log_info("Lifecycle status triggers summary fetch", conversation_id=cid, lifecycle_status=status)
        trigger_summary_fetch(cid, event.data)
    except Exception as err:
        log_error("Summary trigger failed", conversation_id=cid, error=str(err))


HANDLERS = {
    DataType.NEW_MESSAGE: handle_new_message,
    DataType.INTERMEDIATE_TRANSCRIPTION: handle_intermediate_transcription,
    DataType.AGENT_ASSIST: handle_agent_assist,
    DataType.LIFECYCLE: handle_lifecycle,
}
