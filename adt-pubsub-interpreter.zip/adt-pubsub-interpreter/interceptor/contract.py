"""
The contract shared with the UI connector.

Everything in this file is READ by the connector as well as written here:
data_type names, Redis key and channel names, and the JSON envelope published
on the live channel. Changing anything in this file means changing the
connector too.

All keys use the SHORT conversation id (see conversation.py):
  server_id lookup   →  {short_id}
  live channel       →  {server_id}:{short_id}
  buffered turns     →  conversation:{short_id}:turns
  conversation meta  →  conversation:{short_id}:meta
"""

from datetime import datetime, timezone

from utils import format_timestamp


class DataType:
    """data_type strings; one per Pub/Sub topic / push route."""

    AGENT_ASSIST = "agent-assist-notifications-event"
    LIFECYCLE = "conversation-lifecycle-event"
    NEW_MESSAGE = "new-message-notification-event"
    INTERMEDIATE_TRANSCRIPTION = "intermediate-transcription-notification-event"


# ─── Redis keys / channels ────────────────────────────────────────────────────

def server_id_key(conversation_id: str) -> str:
    """Written by the connector when a viewer joins; holds its server_id."""
    return conversation_id


def live_channel(server_id: str, conversation_id: str) -> str:
    return f"{server_id}:{conversation_id}"


def turns_key(conversation_id: str) -> str:
    return f"conversation:{conversation_id}:turns"


def meta_key(conversation_id: str) -> str:
    return f"conversation:{conversation_id}:meta"


# ─── Message envelopes ────────────────────────────────────────────────────────

def utc_now() -> str:
    """Current time as YYYY-MM-DDTHH:MM:SSZ, the format used for ack_time and meta timestamps."""
    return format_timestamp(datetime.now(timezone.utc))


def build_event_message(
    *,
    conversation_id: str,
    conversation_name,
    data: dict,
    data_type: str,
    publish_time,
    message_id,
    participant_role: str = "",
    recognition_message_id: str = "",
) -> dict:
    """Envelope for an event received from Pub/Sub (buffered and live-published as-is)."""
    message = {
        "conversation_id": conversation_id,      # short id (canonical)
        "conversation_name": conversation_name,  # display name
        "data": data,
        "data_type": data_type,
        "ack_time": utc_now(),
        "publish_time": publish_time,
        "message_id": message_id,
    }
    if data_type == DataType.INTERMEDIATE_TRANSCRIPTION:
        message["participant_role"] = participant_role
        message["new_recognition_result_message_id"] = recognition_message_id
    return message


def build_summary_message(conversation_id: str, summary: dict) -> dict:
    """
    Envelope for a summary this service PULLED from Dialogflow.

    Shaped exactly like a pushed agent-assist event, so the connector needs no
    special-casing; `source` is the only field that tells them apart.
    """
    return {
        "conversation_id": conversation_id,
        "conversation_name": conversation_id,
        "data": {
            "conversation_id": conversation_id,
            "suggestionResults": [
                {"suggestConversationSummaryResponse": {"summary": summary}}
            ],
        },
        "data_type": DataType.AGENT_ASSIST,
        "ack_time": utc_now(),
        "publish_time": None,
        "message_id": f"summary-{conversation_id}",
        "source": "interceptor-pull",
    }
