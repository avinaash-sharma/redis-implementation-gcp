"""
Read-only introspection of agent-assist payloads.

Google emits camelCase (REST/JSON) or snake_case (proto) depending on
serialization, so every lookup checks both.

This profile runs BOTH suggestion systems side by side:
  - generators → generateSuggestionsResponse.{generatorSuggestionAnswers,
                 systemActionSuggestions}
  - legacy     → suggestConversationSummaryResponse, suggestFaqAnswersResponse
"""

_GENERATE_RESPONSE_KEYS = ("generateSuggestionsResponse", "generate_suggestions_response")
_LEGACY_SUMMARY_KEYS = ("suggestConversationSummaryResponse", "suggest_conversation_summary_response")


def _pick(d, *keys):
    for key in keys:
        if isinstance(d, dict) and key in d:
            return d[key]
    return None


def _as_list(value) -> list:
    if value is None:
        return []
    if isinstance(value, dict):
        return [value]
    return value if isinstance(value, list) else []


def suggestion_results(data: dict) -> list:
    return _as_list(_pick(data, "suggestionResults", "suggestion_results"))


def _generator_answers(result: dict) -> list:
    response = _pick(result, *_GENERATE_RESPONSE_KEYS)
    if not isinstance(response, dict):
        return []
    return _as_list(_pick(response, "generatorSuggestionAnswers", "generator_suggestion_answers"))


def _generator_suggestion(answer):
    suggestion = _pick(answer, "generatorSuggestion", "generator_suggestion")
    return suggestion if isinstance(suggestion, dict) else None


def has_summary(data: dict) -> bool:
    """True if this payload carries a summary, in either legacy or generator shape."""
    for result in suggestion_results(data):
        if not isinstance(result, dict):
            continue
        if any(key in result for key in _LEGACY_SUMMARY_KEYS):
            return True
        for answer in _generator_answers(result):
            suggestion = _generator_suggestion(answer)
            if suggestion and _pick(suggestion, "summarySuggestion", "summary_suggestion"):
                return True
    return False


def suggestion_types(data: dict) -> list:
    """
    Names what actually arrived, drilling INTO generateSuggestionsResponse.
    Without this you only see ['generateSuggestionsResponse'] and can't tell a
    summary from a coaching tip from a system action.
    """
    types = []
    for result in suggestion_results(data):
        if not isinstance(result, dict):
            continue
        types.extend(
            key for key in result
            if key not in ("error", *_GENERATE_RESPONSE_KEYS)
        )

        response = _pick(result, *_GENERATE_RESPONSE_KEYS)
        if not isinstance(response, dict):
            continue
        for answer in _generator_answers(result):
            suggestion = _generator_suggestion(answer)
            if suggestion:
                types.extend(
                    f"generator:{key}" for key in suggestion
                    if key not in ("toolCallInfo", "tool_call_info")
                )
        system_actions = _pick(response, "systemActionSuggestions", "system_action_suggestions")
        if system_actions:
            types.append(f"systemActions[{len(_as_list(system_actions))}]")
    return types


def suggestion_errors(data: dict) -> list:
    """The `error` entries of any suggestion results that failed."""
    return [
        result["error"]
        for result in suggestion_results(data)
        if isinstance(result, dict) and result.get("error")
    ]
