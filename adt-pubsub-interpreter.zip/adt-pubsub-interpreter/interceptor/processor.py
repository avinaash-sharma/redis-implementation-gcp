"""
Pub/Sub push envelope → Event → Redis buffer → live publish.

Always returns True (ack). A non-2xx response makes Pub/Sub redeliver, and a
message this service can't process now won't be processable on retry either,
so bad input is logged and dropped.

Each stage is guarded separately so that neither logging nor buffering can
ever stop the live publish.
"""

import base64
import json
import traceback
from typing import Optional

from utils import log_debug, log_error, log_info, log_warning

from . import config, redis_store
from .contract import DataType, build_event_message
from .conversation import display_name, extract_short_conversation_id
from .handlers import HANDLERS, Event
from .suggestions import has_summary, suggestion_types

_PUBSUB_MESSAGE_DOCS = "https://cloud.google.com/pubsub/docs/reference/rest/v1/PubsubMessage"


def process_envelope(envelope, data_type: str) -> bool:
    try:
        pubsub_message = _unwrap_envelope(envelope)
        if pubsub_message is None:
            return True

        data = _decode_data(pubsub_message)
        if data is None:
            return True

        conversation_id = extract_short_conversation_id(data)
        if not conversation_id:
            log_warning(
                "Cannot extract conversation id from Pub/Sub payload",
                data_type=data_type,
                payload_keys=list(data.keys()),
            )
            return True

        event = _build_event(conversation_id, data_type, data, pubsub_message)
        _log_event(event)
        _persist(event)
        _publish(event)
    except Exception as err:
        log_error(
            "Unhandled error while processing Pub/Sub envelope",
            data_type=data_type,
            error=str(err),
            traceback=traceback.format_exc(),
        )
    return True


# ─── Stages ───────────────────────────────────────────────────────────────────

def _unwrap_envelope(envelope) -> Optional[dict]:
    """Returns the inner PubsubMessage, or None (logged) if the envelope is unusable."""
    if not envelope:
        log_warning("No Pub/Sub message received")
        return None
    if not isinstance(envelope, dict) or "message" not in envelope:
        log_warning("Invalid Pub/Sub envelope; missing 'message'")
        return None

    message = envelope["message"]
    if not isinstance(message, dict):
        log_warning("Invalid Pub/Sub message; 'message' must be a JSON object", docs=_PUBSUB_MESSAGE_DOCS)
        return None
    if "data" not in message:
        log_warning("Pub/Sub message has no 'data' field", message_id=message.get("messageId"))
        return None
    return message


def _decode_data(pubsub_message: dict) -> Optional[dict]:
    """base64 → UTF-8 → JSON object, or None (logged) if any step fails."""
    try:
        data = json.loads(base64.b64decode(pubsub_message["data"]).decode("utf-8"))
    except Exception as err:
        log_error(
            "Failed to decode/parse Pub/Sub message data",
            message_id=pubsub_message.get("messageId"),
            error=str(err),
        )
        return None

    if not isinstance(data, dict):
        log_warning(
            "Pub/Sub message data is not a JSON object",
            message_id=pubsub_message.get("messageId"),
            data_kind=type(data).__name__,
        )
        return None
    return data


def _build_event(conversation_id: str, data_type: str, data: dict, pubsub_message: dict) -> Event:
    attributes = pubsub_message.get("attributes")
    if not isinstance(attributes, dict):
        attributes = {}
    participant_role = attributes.get("participant_role", "")

    message = build_event_message(
        conversation_id=conversation_id,
        conversation_name=display_name(data, conversation_id),
        data=data,
        data_type=data_type,
        publish_time=pubsub_message.get("publishTime"),
        message_id=pubsub_message.get("messageId"),
        participant_role=participant_role,
        recognition_message_id=attributes.get("message_id", ""),
    )
    return Event(
        conversation_id=conversation_id,
        data_type=data_type,
        data=data,
        message=message,
        encoded=json.dumps(message),
        participant_role=participant_role,
    )


def _log_event(event: Event) -> None:
    """One summary line at INFO, the full payload at DEBUG. Never raises."""
    try:
        fields = {
            "conversation_id": event.conversation_id,
            "conversation_name": event.message["conversation_name"],
            "data_type": event.data_type,
            "message_id": event.message["message_id"],
            "publish_time": event.message["publish_time"],
            "payload_keys": list(event.data.keys()),
        }
        if event.participant_role:
            fields["participant_role"] = event.participant_role
        if config.LOG_SUGGESTION_TYPES and event.data_type == DataType.AGENT_ASSIST:
            try:
                fields["suggestion_types"] = suggestion_types(event.data)
                fields["has_summary"] = has_summary(event.data)
            except Exception as err:
                fields["suggestion_introspection_error"] = str(err)

        log_info("Pub/Sub event received", **fields)
        log_debug(
            "Pub/Sub event payload",
            conversation_id=event.conversation_id,
            message_id=event.message["message_id"],
            payload=event.data,
        )
    except Exception as err:
        log_warning("Event logging failed", conversation_id=event.conversation_id, error=str(err))


def _persist(event: Event) -> None:
    """Buffers to Redis regardless of whether a viewer is connected."""
    handler = HANDLERS.get(event.data_type)
    if handler is None:
        return
    try:
        handler(event)
    except Exception as err:
        log_error(
            "Redis persistence (turns/meta) failed",
            conversation_id=event.conversation_id,
            data_type=event.data_type,
            error=str(err),
        )


def _publish(event: Event) -> None:
    """Live-publishes to the connector instance serving this conversation, if any."""
    cid = event.conversation_id
    try:
        published = redis_store.publish_live(cid, event.encoded)
    except Exception as err:
        log_error("Live publish failed", conversation_id=cid, data_type=event.data_type, error=str(err))
        return

    if published is None:
        log_info(
            "No active viewer (server_id) for conversation; not live-published. "
            "Buffered turns are sent as HISTORY_BATCH on join.",
            conversation_id=cid,
            data_type=event.data_type,
        )
        return

    log_info(
        "Published to live channel",
        conversation_id=cid,
        channel=published.channel,
        message_id=event.message["message_id"],
        data_type=event.data_type,
        subscribers=published.receivers,
    )
    if published.receivers == 0:
        log_warning(
            "Published but ZERO subscribers received it; server_id key exists "
            "but no live subscription on that instance",
            conversation_id=cid,
            channel=published.channel,
        )
