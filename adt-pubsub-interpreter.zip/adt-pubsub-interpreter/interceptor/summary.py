"""
End-of-call summarization via suggestConversationSummary (PULL, not push).

Summarization is NOT event-based: Agent Assist never pushes it to the
agent-assist topic, it has to be asked for. This module is the only place that
happens, and everything here is inert unless SUMMARY_ON_END=true.

Verified against a real 200 OK from:
  POST https://global-dialogflow.googleapis.com/v2/projects/{project}
       /locations/global/conversations/{id}/suggestions:suggestConversationSummary

Response shape:
  {
    "summary": {
      "text": "situation_concise\n...\naction_concise\n...",
      "answerRecord": "projects/{p}/locations/global/answerRecords/{id}",
      "textSections": {
        "situation_concise": "...", "action_concise": "...",
        "resolution": "N", "customer_satisfaction": "N", "Call Summary": "..."
      }
    }
  }
`textSections` is the useful field (a flat map the UI renders section by
section); `text` is the same content concatenated into one blob.

The Dialogflow SDK is imported INSIDE functions, not at module scope: an import
that drags in a conflicting protobuf can fail container startup, which would
take down live streaming along with everything else.
"""

import json
import threading
import time
import traceback
from concurrent.futures import ThreadPoolExecutor

from utils import log_error, log_info, log_metric, log_warning

from . import config, redis_store
from .contract import build_summary_message, utc_now
from .conversation import extract_conversation_path

_executor = None
_executor_lock = threading.Lock()
_dialogflow_client = None
_dialogflow_client_lock = threading.Lock()


# ─── Lazily-built resources ───────────────────────────────────────────────────

def _get_executor() -> ThreadPoolExecutor:
    """Created lazily so the pool doesn't exist unless summarization is used."""
    global _executor
    if _executor is None:
        with _executor_lock:
            if _executor is None:
                _executor = ThreadPoolExecutor(
                    max_workers=config.SUMMARY_WORKERS,
                    thread_name_prefix="summary",
                )
    return _executor


def _get_dialogflow_client():
    """
    Builds (once) a Conversations client.

    Location is 'global', so the DEFAULT endpoint is correct. A regional
    api_endpoint is only used if DIALOGFLOW_LOCATION is changed to a region;
    mismatching the two yields NOT_FOUND.
    """
    global _dialogflow_client
    if _dialogflow_client is not None:
        return _dialogflow_client

    from google.api_core.client_options import ClientOptions
    from google.cloud import dialogflow_v2 as dialogflow

    with _dialogflow_client_lock:
        if _dialogflow_client is None:
            location = config.DIALOGFLOW_LOCATION
            if location and location != "global":
                endpoint = f"{location}-dialogflow.googleapis.com"
                _dialogflow_client = dialogflow.ConversationsClient(
                    client_options=ClientOptions(api_endpoint=endpoint)
                )
            else:
                endpoint = "global (default)"
                _dialogflow_client = dialogflow.ConversationsClient()
            log_info("Dialogflow client built", endpoint=endpoint)
    return _dialogflow_client


# ─── Response → Redis ─────────────────────────────────────────────────────────

def _summary_to_dict(response) -> dict:
    """
    Flattens SuggestConversationSummaryResponse into plain JSON, using the same
    field names as the REST API so what lands in Redis matches Postman.
    """
    summary = getattr(response, "summary", None)
    if summary is None:
        return {}

    text_sections = {}
    raw_sections = getattr(summary, "text_sections", None)
    if raw_sections:
        try:
            text_sections = dict(raw_sections)
        except Exception:
            text_sections = {}

    return {
        "text": getattr(summary, "text", "") or "",
        "textSections": text_sections,
        # Handle for AnswerRecords.UpdateAnswerRecord (thumbs up/down on the summary).
        "answerRecord": getattr(summary, "answer_record", "") or "",
        "latestMessage": getattr(response, "latest_message", "") or "",
        "contextSize": getattr(response, "context_size", 0),
    }


def store_and_publish_summary(conversation_id: str, summary: dict) -> None:
    """
    Stores the summary in :meta and publishes it straight to the live Redis channel.

    Deliberately NOT republished to the Pub/Sub topic: we're already inside the
    interceptor, so a round trip through Google just to receive our own message
    back would add latency, need a publisher grant, and risk a loop.
    """
    message = build_summary_message(conversation_id, summary)
    encoded = json.dumps(message)
    sections = list(summary.get("textSections", {}).keys())

    try:
        meta = redis_store.update_meta(conversation_id, {
            "last_summary": json.dumps(message["data"]),
            "last_summary_sections": json.dumps(summary.get("textSections", {})),
            "last_summary_text": summary.get("text", ""),
            "last_summary_answer_record": summary.get("answerRecord", ""),
            "last_summary_at": message["ack_time"],
        })
        # Only append to :turns when agent-assist buffering is on, so the
        # connector's replay never sees an entry shape it wasn't built for.
        if config.BUFFER_AGENT_ASSIST:
            redis_store.append_turn(conversation_id, encoded)
        log_info("Stored summary", conversation_id=conversation_id, key=meta, sections=sections)
    except Exception as err:
        log_error("Failed to store summary", conversation_id=conversation_id, error=str(err))

    try:
        published = redis_store.publish_live(conversation_id, encoded)
        if published is None:
            log_info(
                "Summary stored but no active viewer; readable from :meta on next join",
                conversation_id=conversation_id,
            )
            return
        log_info(
            "Summary published to live channel",
            conversation_id=conversation_id,
            channel=published.channel,
            subscribers=published.receivers,
        )
    except Exception as err:
        log_error("Failed to live-publish summary", conversation_id=conversation_id, error=str(err))


def _record_failure(conversation_id: str, error: str) -> None:
    """So the UI can show "summary unavailable" instead of waiting forever."""
    try:
        redis_store.update_meta(conversation_id, {
            "summary_error": error[:500],
            "summary_error_at": utc_now(),
        })
    except Exception as err:
        log_warning("Could not record summary failure", conversation_id=conversation_id, error=str(err))


# ─── Fetch ────────────────────────────────────────────────────────────────────

def _fetch_summary(conversation_id: str, conversation_path: str) -> None:
    """
    Calls suggestConversationSummary with retries.

    `latest_message` is deliberately omitted: the API defaults to the latest
    message of the conversation, which is exactly what we want at end of call,
    so there's no need to track message resource paths during the call.
    """
    from google.cloud import dialogflow_v2 as dialogflow

    started = time.monotonic()
    if config.SUMMARY_INITIAL_DELAY_SECONDS > 0:
        time.sleep(config.SUMMARY_INITIAL_DELAY_SECONDS)

    max_attempts = config.SUMMARY_MAX_ATTEMPTS
    last_error = None
    for attempt in range(1, max_attempts + 1):
        try:
            request = dialogflow.SuggestConversationSummaryRequest(
                conversation=conversation_path,
                context_size=config.SUMMARY_CONTEXT_SIZE,
            )
            log_info(
                "Requesting summary",
                conversation_id=conversation_id,
                conversation_path=conversation_path,
                attempt=attempt,
                max_attempts=max_attempts,
                context_size=config.SUMMARY_CONTEXT_SIZE,
            )
            response = _get_dialogflow_client().suggest_conversation_summary(request=request)
            summary = _summary_to_dict(response)

            if summary.get("text") or summary.get("textSections"):
                log_info("Summary received", conversation_id=conversation_id, attempt=attempt)
                store_and_publish_summary(conversation_id, summary)
                log_metric(
                    "summary_fetch",
                    status="success",
                    conversation_id=conversation_id,
                    attempts=attempt,
                    duration_ms=int((time.monotonic() - started) * 1000),
                )
                return

            last_error = "empty summary returned"
            log_warning(
                "Summary came back empty; retrying",
                conversation_id=conversation_id,
                attempt=attempt,
                max_attempts=max_attempts,
            )
        except Exception as err:
            last_error = str(err)
            log_warning(
                "suggestConversationSummary failed",
                conversation_id=conversation_id,
                attempt=attempt,
                max_attempts=max_attempts,
                error=last_error,
            )

        if attempt < max_attempts:
            time.sleep(config.SUMMARY_RETRY_BACKOFF_SECONDS * attempt)

    log_error(
        "Gave up fetching summary",
        conversation_id=conversation_id,
        attempts=max_attempts,
        error=str(last_error),
    )
    log_metric(
        "summary_fetch",
        status="failed",
        conversation_id=conversation_id,
        attempts=max_attempts,
        duration_ms=int((time.monotonic() - started) * 1000),
        error=str(last_error),
    )
    _record_failure(conversation_id, str(last_error))


def _fetch_summary_safely(conversation_id: str, conversation_path: str) -> None:
    """
    An exception escaping a ThreadPoolExecutor task is stored on its Future and
    never printed, so the background path needs its own last-resort log.
    """
    try:
        _fetch_summary(conversation_id, conversation_path)
    except Exception as err:
        log_error(
            "Summary worker crashed",
            conversation_id=conversation_id,
            error=str(err),
            traceback=traceback.format_exc(),
        )


def _resolve_conversation_path(conversation_id: str, data: dict) -> str:
    """Prefer the path Dialogflow itself sent; then the one saved in :meta; then rebuild it."""
    path = extract_conversation_path(data)
    if path:
        return path

    try:
        path = redis_store.get_meta_field(conversation_id, "conversation_path")
    except Exception as err:
        log_warning("Could not read stored conversation_path", conversation_id=conversation_id, error=str(err))
    if path:
        return path

    path = (
        f"projects/{config.GCP_PROJECT_ID}/locations/{config.DIALOGFLOW_LOCATION}"
        f"/conversations/{conversation_id}"
    )
    log_info("Reconstructed conversation path", conversation_id=conversation_id, conversation_path=path)
    return path


def trigger_summary_fetch(conversation_id: str, data: dict) -> None:
    """Resolves the conversation path, takes the one-shot lock, runs the fetch."""
    if not config.SUMMARY_ON_END:
        return

    conversation_path = _resolve_conversation_path(conversation_id, data)

    try:
        if not redis_store.acquire_summary_lock(conversation_id):
            log_info("Summary already requested; skipping", conversation_id=conversation_id)
            return
    except Exception as err:
        # Fail open: a missed lock risks a duplicate call, not a missing summary.
        log_warning("Could not take summary lock", conversation_id=conversation_id, error=str(err))

    if config.SUMMARY_INLINE:
        log_info("Running inline summary fetch", conversation_id=conversation_id)
        _fetch_summary_safely(conversation_id, conversation_path)
    else:
        log_info("Dispatching background summary fetch", conversation_id=conversation_id)
        _get_executor().submit(_fetch_summary_safely, conversation_id, conversation_path)


def force_summary_fetch(conversation_id: str) -> None:
    """Clears the one-shot lock and re-triggers (debug endpoint only)."""
    try:
        redis_store.release_summary_lock(conversation_id)
    except Exception as err:
        log_warning("Could not clear summary lock", conversation_id=conversation_id, error=str(err))
    trigger_summary_fetch(conversation_id, {"conversation_id": conversation_id})
