"""
Conversation id / resource-path extraction from Dialogflow payloads.

The SHORT id (e.g. '119D884h-wcQNGy0qy4QyS-9w') is the canonical key shared
with the UI connector; contract.py builds every Redis key from it.
"""

from typing import Optional


def extract_short_conversation_id(data: dict) -> Optional[str]:
    """
    Returns the SHORT conversation id regardless of:
      - whether the payload carries it under 'conversation_id' or 'conversation'
      - whether the value is a bare id or a full resource path
      - whether the payload carries ONLY a participant path

    The participant fallback only fires when both primary fields are absent,
    so it cannot change the id for any payload that already resolved.
    """
    raw = data.get("conversation_id") or data.get("conversation")

    if not isinstance(raw, str) or not raw:
        participant = data.get("participant") or data.get("participant_id")
        if isinstance(participant, str) and "/conversations/" in participant:
            raw = participant.split("/conversations/")[1].split("/")[0]

    if not isinstance(raw, str) or not raw:
        return None

    return raw.rstrip("/").split("/")[-1]


def extract_conversation_path(data: dict) -> Optional[str]:
    """Full `projects/.../conversations/{id}` path if the payload carries one."""
    candidates = (
        data.get("conversation"),
        data.get("conversation_id"),
        data.get("participant"),
        data.get("participant_id"),
    )
    for raw in candidates:
        if isinstance(raw, str) and "/conversations/" in raw:
            head, _, tail = raw.rstrip("/").partition("/conversations/")
            return f"{head}/conversations/{tail.split('/')[0]}"
    return None


def display_name(data: dict, conversation_id: str):
    """
    Conversation name with its location segment removed, for logs and the
    `conversation_name` field only. NEVER use this for Redis keys/channels.
    """
    raw = data.get("conversation_id") or data.get("conversation") or conversation_id
    if "/locations/" in raw:
        parts = raw.split("/")
        return "/".join(parts[i] for i in (0, 1, -2, -1))
    return raw
