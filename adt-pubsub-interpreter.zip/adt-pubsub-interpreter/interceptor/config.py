"""
Runtime configuration: every environment variable the service reads, in one place.

SAFE MODE
---------
With none of the feature flags set, the service behaves exactly like the
original single-file interceptor: same Redis writes, same live publish, same
payload shapes. Every addition is behind a flag that defaults to OFF.

Turn features on ONE AT A TIME and verify live streaming still works after each:

  1. LOG_SUGGESTION_TYPES=true   Adds suggestion_types / has_summary to the
                                 per-event log line. Zero behaviour change.
  2. BUFFER_AGENT_ASSIST=true    Write agent-assist events to :turns so they
                                 survive when no viewer is connected.
                                 REQUIRES the connector's normalizer to skip
                                 data_type == agent-assist-notifications-event.
  3. SUMMARY_ON_END=true         Pull the summary via suggestConversationSummary
                                 when the call ends and push it to the live
                                 Redis channel.

Kill switch: unset a flag and redeploy. No code changes needed.

Log verbosity is NOT set here. utils.py derives it from ENVIRONMENT
(dev=DEBUG, sit/uat=INFO, prod=ERROR).
"""

import os


def _flag(name: str, default: str = "false") -> bool:
    return os.environ.get(name, default).lower() == "true"


def _upper_set(name: str, default: str) -> frozenset:
    """Comma-separated env var → set of trimmed, upper-cased, non-empty values."""
    return frozenset(
        value.strip().upper()
        for value in os.environ.get(name, default).split(",")
        if value.strip()
    )


# ─── Feature flags (all default OFF) ──────────────────────────────────────────

LOG_SUGGESTION_TYPES = _flag("LOG_SUGGESTION_TYPES")
BUFFER_AGENT_ASSIST = _flag("BUFFER_AGENT_ASSIST")
SUMMARY_ON_END = _flag("SUMMARY_ON_END")

# Cloud Run throttles CPU to near-zero after the response is sent, so a
# background thread can stall until the next request. Either deploy with
# --no-cpu-throttling, or set SUMMARY_INLINE=true (which holds the Pub/Sub
# ack open, so raise the subscription's ack deadline accordingly).
SUMMARY_INLINE = _flag("SUMMARY_INLINE")


# ─── Redis ────────────────────────────────────────────────────────────────────

REDIS_HOST = os.environ.get("REDISHOST", "100.72.86.38")
REDIS_PORT = int(os.environ.get("REDISPORT", 6379))

# Rolling TTL for buffered conversation data (:turns and :meta). Reset on
# every write, so keys expire after this long of INACTIVITY, not from when
# the conversation started. Change this single value to tune retention.
CONVERSATION_DATA_TTL_SECONDS = 2 * 60 * 60  # 2 hours

# Shortcut TTL (currently DISABLED). Once a lifecycle event reports the call
# is over, a short grace period (enough for a final reconnect/QA check) would
# do instead of the full rolling window.
# WARNING: with SUMMARY_ON_END on, the summary is fetched AFTER that event, so
# this must exceed worst-case summary latency or the keys expire under it.
# ENDED_CONVERSATION_TTL_SECONDS = 15 * 60  # 15 minutes
# ENDED_LIFECYCLE_STATUSES = {"ENDED"}


# ─── Summarization (only used when SUMMARY_ON_END=true) ───────────────────────

GCP_PROJECT_ID = os.environ.get("GCP_PROJECT_ID", "adtgcp-ent-dev-ccs-tlcm-fe10")

# 'global', NOT the GKE region. The conversation resource lives at
# projects/{p}/locations/global/conversations/{id}, confirmed against a
# working request. Using a region here yields NOT_FOUND.
DIALOGFLOW_LOCATION = os.environ.get("DIALOGFLOW_LOCATION", "global")

# Lifecycle values that mean "call is over". TWO SHAPES EXIST, accept both:
#   real Dialogflow  →  {"conversation": "...", "type": "CONVERSATION_FINISHED"}
#   mock publisher   →  {"conversation_id": "...", "status": "ENDED"}
SUMMARY_TRIGGER_STATUSES = _upper_set(
    "SUMMARY_TRIGGER_STATUSES", "CONVERSATION_FINISHED,ENDED,COMPLETED"
)

# Max messages of context. API default is 500, hard max 1000.
SUMMARY_CONTEXT_SIZE = int(os.environ.get("SUMMARY_CONTEXT_SIZE", "500"))

SUMMARY_MAX_ATTEMPTS = int(os.environ.get("SUMMARY_MAX_ATTEMPTS", "4"))
SUMMARY_RETRY_BACKOFF_SECONDS = int(os.environ.get("SUMMARY_RETRY_BACKOFF_SECONDS", "5"))
SUMMARY_INITIAL_DELAY_SECONDS = int(os.environ.get("SUMMARY_INITIAL_DELAY_SECONDS", "3"))
SUMMARY_LOCK_TTL_SECONDS = int(os.environ.get("SUMMARY_LOCK_TTL_SECONDS", "3600"))
SUMMARY_WORKERS = int(os.environ.get("SUMMARY_WORKERS", "4"))
