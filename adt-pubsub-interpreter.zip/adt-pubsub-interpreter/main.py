"""
ADT Pub/Sub Interceptor: Cloud Run entrypoint (`uvicorn main:app`).

Dialogflow publishes conversation events to Pub/Sub; push subscriptions POST
them here. Each event is buffered in Redis (keyed by the SHORT conversation
id) and live-published to the UI-connector instance serving that conversation.

  utils.py                     shared structured logging (level from ENVIRONMENT)
  interceptor/
    config.py                  every env var + feature flag (SAFE MODE notes)
    contract.py                data types, Redis keys, message shapes shared with the connector
    redis_store.py             Redis client + buffer / meta / publish / lock operations
    conversation.py            conversation id and resource-path extraction
    suggestions.py             agent-assist payload introspection
    summary.py                 end-of-call summary pull (SUMMARY_ON_END)
    handlers.py                per-data_type buffering rules
    processor.py               envelope → event → persist → publish
    routes.py                  HTTP endpoints
"""

from fastapi import FastAPI

from interceptor.routes import admin_router, health_router, intercept_router

app = FastAPI(title="Pub/Sub Interceptor")
app.include_router(health_router)
app.include_router(intercept_router)
app.include_router(admin_router)  # debug only; drop this line before TST
