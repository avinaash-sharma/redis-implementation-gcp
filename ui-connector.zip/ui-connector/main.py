"""
Entrypoint — same import path as before, so existing run commands keep working:

    uvicorn main:app --host 0.0.0.0 --port 8080
"""

from connector.app import create_app

app = create_app()
