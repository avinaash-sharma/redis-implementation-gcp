from types import SimpleNamespace

import pytest
from starlette.datastructures import Headers, QueryParams

from connector.auth import AuthFailure, extract_bearer_token


def conn(headers=None, query=""):
    return SimpleNamespace(headers=Headers(headers or {}), query_params=QueryParams(query))


def test_reads_bearer_token():
    assert extract_bearer_token(conn({"Authorization": "Bearer a.b.c"})) == "a.b.c"


def test_scheme_and_header_name_are_case_insensitive():
    assert extract_bearer_token(conn({"authorization": "bearer   a.b.c  "})) == "a.b.c"


@pytest.mark.parametrize(
    "headers, query, reason, detail_part",
    [
        ({}, "", "missing_token", "no Authorization header"),
        ({}, "conversation_id=c1&token=a.b.c", "missing_token", "no longer accepted"),
        ({"Authorization": "Bearer "}, "", "missing_token", "empty"),
        ({"Authorization": "Basic dXNlcjpwYXNz"}, "", "invalid_auth_scheme", "unsupported"),
        ({"Authorization": "a.b.c"}, "", "invalid_auth_scheme", "missing 'Bearer '"),
    ],
)
def test_rejections(headers, query, reason, detail_part):
    with pytest.raises(AuthFailure) as err:
        extract_bearer_token(conn(headers, query))
    assert err.value.reason == reason
    assert detail_part in err.value.detail


def test_never_echoes_a_prefixless_token():
    token = "eyJhbGciOiJSUzI1NiJ9.eyJzdWIiOiIxIn0.c2ln"
    with pytest.raises(AuthFailure) as err:
        extract_bearer_token(conn({"Authorization": token}))
    assert token not in str(err.value)
