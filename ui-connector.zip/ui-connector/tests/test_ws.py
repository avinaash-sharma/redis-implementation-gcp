import json
import logging
import time

import pytest
from starlette.websockets import WebSocketDisconnect

from conftest import bearer, mint, parsed
from connector.log_scrub import SecretScrubbingFilter
from connector.redis_client import RedisConnectionError
from connector.ws import stream

CONV = "conv-52e5bf76"
CHANNEL = f"1:{CONV}"


def ws_url(conv=CONV, extra=""):
    return f"/ws?conversation_id={conv}{extra}"


def receive_until_close(ws):
    events = []
    with pytest.raises(WebSocketDisconnect) as err:
        while True:
            events.append(ws.receive_json())
    return events, err.value.code, err.value.reason


def wait_until(predicate, timeout=5.0):
    deadline = time.time() + timeout
    while time.time() < deadline:
        if predicate():
            return
        time.sleep(0.02)
    raise AssertionError("condition not met in time")


def subscribers(sync_redis, channel):
    return dict(sync_redis.pubsub_numsub(channel)).get(channel.encode(), 0)


def close_and_wait_for_summary(ws, app_logs):
    """
    TestClient cancels the app right after sending the close frame on context
    exit, racing the app's own cleanup. Close first and wait for the summary
    line so assertions see a normal client disconnect, as under uvicorn.
    """
    ws.close(1000)
    wait_until(lambda: any(line["message"].endswith("Session closed") for line in parsed(app_logs)))


# ─── Happy path ───────────────────────────────────────────────────────────────

def test_header_auth_replays_history_then_streams_live(client, sync_redis):
    sync_redis.rpush(f"conversation:{CONV}:turns", json.dumps({"n": 1}), json.dumps({"n": 2}), b"not-json")

    with client.websocket_connect(ws_url(), headers=bearer(mint())) as ws:
        batch = ws.receive_json()
        assert batch["type"] == "HISTORY_BATCH"
        assert batch["turns"] == [{"n": 1}, {"n": 2}]   # malformed turn skipped
        assert batch["totalTurns"] == 2
        assert sync_redis.get(CONV) == b"1"             # server pointer registered

        wait_until(lambda: subscribers(sync_redis, CHANNEL) == 1)
        sync_redis.publish(CHANNEL, json.dumps({"type": "TURN", "text": "hello"}))
        assert ws.receive_json() == {"type": "TURN", "text": "hello"}

    wait_until(lambda: sync_redis.get(CONV) is None)    # cleared when last client left


def test_pointer_kept_while_another_local_client_is_connected(client, sync_redis):
    with client.websocket_connect(ws_url(), headers=bearer(mint())) as first:
        first.receive_json()
        with client.websocket_connect(ws_url(), headers=bearer(mint())) as second:
            second.receive_json()
        assert sync_redis.get(CONV) == b"1"
    wait_until(lambda: sync_redis.get(CONV) is None)


# ─── Authentication ───────────────────────────────────────────────────────────

def _tampered():
    header, _, sig = mint().split(".")
    _, forged_payload, _ = mint(email="attacker@evil.test").split(".")
    return f"{header}.{forged_payload}.{sig}"


@pytest.mark.parametrize(
    "headers, extra, reason",
    [
        ({}, "", "missing_token"),
        ({}, "&token=LEGACY", "missing_token"),
        ({"Authorization": "Basic dXNlcjpwYXNz"}, "", "invalid_auth_scheme"),
        (lambda: bearer("not-a-jwt"), "", "malformed_token"),
        (lambda: bearer(mint(iat=int(time.time()) - 7200, exp=int(time.time()) - 3600)), "", "token_expired"),
        (lambda: bearer(mint(aud="https://some-other-service")), "", "bad_audience"),
        (lambda: bearer(mint(email="someone@else.iam.gserviceaccount.com")), "", "caller_not_allowed"),
        (lambda: bearer(mint(email_verified=False)), "", "email_unverified"),
        (lambda: bearer(mint(iss="https://evil.test")), "", "invalid_issuer"),
        (lambda: bearer(_tampered()), "", "invalid_token"),
    ],
)
def test_rejected_handshakes_close_1008_with_reason(client, sync_redis, headers, extra, reason):
    headers = headers() if callable(headers) else headers
    extra = extra.replace("LEGACY", mint())
    with client.websocket_connect(ws_url(extra=extra), headers=headers) as ws:
        events, code, close_reason = receive_until_close(ws)
    assert (code, close_reason) == (1008, reason)
    assert events == []                   # nothing sent before the close
    assert sync_redis.get(CONV) is None   # never joined


def test_single_use_token_cannot_be_replayed(client):
    token = mint()
    with client.websocket_connect(ws_url(), headers=bearer(token)) as ws:
        assert ws.receive_json()["type"] == "HISTORY_BATCH"
    with client.websocket_connect(ws_url(), headers=bearer(token)) as ws:
        _, code, reason = receive_until_close(ws)
    assert (code, reason) == (1008, "token_replayed")


def test_socket_closes_when_token_expires(client):
    with client.websocket_connect(ws_url(), headers=bearer(mint(exp=int(time.time()) + 2))) as ws:
        assert ws.receive_json()["type"] == "HISTORY_BATCH"
        _, code, reason = receive_until_close(ws)
    assert (code, reason) == (1008, "token_expired")


# ─── conversation_id ─────────────────────────────────────────────────────────

def test_missing_conversation_id(client):
    with client.websocket_connect("/ws", headers=bearer(mint())) as ws:
        events, code, reason = receive_until_close(ws)
    assert events[0]["code"] == "MISSING_CONVERSATION_ID"
    assert (code, reason) == (1008, "Missing conversation_id")


@pytest.mark.parametrize("bad_id", ["conversation:victim:turns", "projects/p/locations/l/conversations/c1"])
def test_conversation_id_cannot_address_other_redis_keys(client, sync_redis, bad_id):
    sync_redis.rpush("conversation:victim:turns", "turn")
    with client.websocket_connect(ws_url(conv=bad_id), headers=bearer(mint())) as ws:
        events, code, reason = receive_until_close(ws)
    assert events[0]["code"] == "INVALID_CONVERSATION_ID"
    assert (code, reason) == (1008, "Invalid conversation_id")
    assert sync_redis.llen("conversation:victim:turns") == 1       # not overwritten or deleted
    assert sync_redis.type(bad_id) in (b"none", b"list")           # no pointer written under it


# ─── Backend failures ─────────────────────────────────────────────────────────

def test_redis_down_on_join_closes_1013(client, redis_server):
    redis_server.connected = False
    with client.websocket_connect(ws_url(), headers=bearer(mint())) as ws:
        events, code, reason = receive_until_close(ws)
    assert events[0]["code"] == "REDIS_UNAVAILABLE"
    assert (code, reason) == (1013, "REDIS_UNAVAILABLE")


def test_unrecoverable_stream_closes_socket(client, monkeypatch):
    class BrokenPubSub:
        async def subscribe(self, *_):
            raise RedisConnectionError("boom")

        async def aclose(self):
            pass

    class BrokenRedis:
        def pubsub(self):
            return BrokenPubSub()

    monkeypatch.setattr(stream, "get_redis", lambda: BrokenRedis())
    monkeypatch.setattr(stream, "RECONNECT_BACKOFF_SECONDS", 0)
    monkeypatch.setattr(stream, "MAX_RECONNECT_ATTEMPTS", 2)

    with client.websocket_connect(ws_url(), headers=bearer(mint())) as ws:
        assert ws.receive_json()["type"] == "HISTORY_BATCH"
        events, code, reason = receive_until_close(ws)
    assert [e["code"] for e in events] == ["STREAM_PAUSED"] * 3 + ["STREAM_UNAVAILABLE"]
    assert (code, reason) == (1013, "stream_unavailable")


# ─── Logging ──────────────────────────────────────────────────────────────────

def test_logs_are_conversation_prefixed_and_never_contain_tokens(client, app_logs):
    good, legacy = mint(), mint()
    with client.websocket_connect(ws_url(), headers=bearer(good)) as ws:
        ws.receive_json()
        close_and_wait_for_summary(ws, app_logs)
    with client.websocket_connect(ws_url(extra=f"&token={legacy}")) as ws:
        receive_until_close(ws)

    lines = parsed(app_logs)
    assert lines
    for line in lines:
        assert line["message"].startswith(f"{line['conversation_id']} | ui-connector | ")

    by_message = {line["message"]: line for line in lines}
    connected = by_message[f"{CONV} | ui-connector | Connected"]
    assert connected["module"] == "ws.endpoint"

    closed = by_message[f"{CONV} | ui-connector | Session closed"]
    assert closed["log_type"] == "METRIC"
    assert closed["end_reason"] == "client_disconnected"

    rejected = by_message[f"{CONV} | ui-connector | Rejected: missing_token"]
    assert "no longer accepted" in rejected["detail"]

    everything = "\n".join(r.getMessage() for r in app_logs.records)
    assert good not in everything and legacy not in everything


def test_one_session_is_a_handful_of_lines_not_one_per_message(client, sync_redis, app_logs):
    with client.websocket_connect(ws_url(), headers=bearer(mint())) as ws:
        ws.receive_json()
        wait_until(lambda: subscribers(sync_redis, CHANNEL) == 1)
        for i in range(20):
            sync_redis.publish(CHANNEL, json.dumps({"i": i}))
        for _ in range(20):
            ws.receive_json()
        ws.send_text("ping")
        close_and_wait_for_summary(ws, app_logs)

    conv_lines = [line for line in parsed(app_logs) if line["conversation_id"] == CONV]
    assert len(conv_lines) <= 3, [line["message"] for line in conv_lines]
    closed = conv_lines[-1]
    assert closed["forwarded"] == 20 and closed["received"] == 1


def test_uvicorn_handshake_line_is_scrubbed():
    token = mint()
    record = logging.LogRecord(
        "uvicorn.error", logging.INFO, __file__, 0, '%s - "WebSocket %s" [accepted]',
        ("10.0.0.1:5000", f"/ws?conversation_id={CONV}&token={token}"), None,
    )
    SecretScrubbingFilter().filter(record)
    assert token not in record.getMessage()
    assert "token=REDACTED" in record.getMessage()


# ─── HTTP ─────────────────────────────────────────────────────────────────────

def test_health_and_status(client):
    health = client.get("/").json()
    assert health["redis"] == "connected"

    auth = client.get("/auth-health").json()
    assert auth["google_certs"] == "reachable" and auth["audience_configured"] is True

    with client.websocket_connect(ws_url(), headers=bearer(mint())) as ws:
        ws.receive_json()
        status = client.get(f"/conversation-status?conversation_id={CONV}").json()
        assert status["active"] is True and status["connected_clients"] == 1
        assert client.get("/").json()["active_conversations"] == [CONV]

    assert client.get("/conversation-status").status_code == 400
