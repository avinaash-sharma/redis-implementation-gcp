"""
Test harness: fakeredis in place of Memorystore, and a local RSA key standing in
for Google's signing key, so tokens are real signed JWTs verified by the real
google-auth code path. Only the cert download is stubbed.
"""

import json
import logging
import os
import sys
import time
import uuid

import pytest

# Settings are read at import, so the environment must be set first.
os.environ.update({
    "ENVIRONMENT": "dev",
    "WS_TOKEN_AUDIENCE": "https://ui-connector.test",
    "ALLOWED_SAS": "sf-apex@proj.iam.gserviceaccount.com",
    "WS_TOKEN_SINGLE_USE": "true",
    "SERVER_ID": "1",
})
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import fakeredis  # noqa: E402
from cryptography.hazmat.primitives import serialization  # noqa: E402
from cryptography.hazmat.primitives.asymmetric import rsa  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402
from google.auth import crypt, jwt  # noqa: E402

from connector import redis_client  # noqa: E402
from connector.auth import cert_cache  # noqa: E402
from main import app  # noqa: E402

KEY_ID = "test-kid"
AUDIENCE = os.environ["WS_TOKEN_AUDIENCE"]
ALLOWED_SA = os.environ["ALLOWED_SAS"]

_private_key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
_PRIVATE_PEM = _private_key.private_bytes(
    serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8, serialization.NoEncryption()
)
PUBLIC_PEM = _private_key.public_key().public_bytes(
    serialization.Encoding.PEM, serialization.PublicFormat.SubjectPublicKeyInfo
).decode()
_signer = crypt.RSASigner.from_string(_PRIVATE_PEM, key_id=KEY_ID)


def mint(**overrides) -> str:
    """A Google-style ID token. Pass a claim as None to drop it."""
    now = int(time.time())
    claims = {
        "iss": "https://accounts.google.com",
        "aud": AUDIENCE,
        "email": ALLOWED_SA,
        "email_verified": True,
        "sub": "1234567890",
        "iat": now,
        "exp": now + 3600,
        "jti": uuid.uuid4().hex,   # unique per mint, so single-use doesn't trip
    }
    claims.update(overrides)
    claims = {k: v for k, v in claims.items() if v is not None}
    return jwt.encode(_signer, claims).decode()


def bearer(token: str) -> dict:
    return {"Authorization": f"Bearer {token}"}


@pytest.fixture
def redis_server():
    return fakeredis.FakeServer()


@pytest.fixture
def sync_redis(redis_server):
    """Test-side view of the same fake Redis the app uses."""
    return fakeredis.FakeRedis(server=redis_server)


@pytest.fixture
def client(redis_server, monkeypatch):
    redis_client.set_redis(fakeredis.aioredis.FakeRedis(server=redis_server))

    async def fake_certs(force=False):
        return {KEY_ID: PUBLIC_PEM}

    monkeypatch.setattr(cert_cache, "get", fake_certs)
    with TestClient(app) as test_client:
        yield test_client
    redis_client.set_redis(None)


class _Collector(logging.Handler):
    def __init__(self):
        super().__init__(level=logging.DEBUG)
        self.records = []

    def emit(self, record):
        self.records.append(record)


@pytest.fixture
def app_logs():
    """Every JSON line the app writes through utils.py (root + metric logger)."""
    collector = _Collector()
    loggers = [logging.getLogger(), logging.getLogger("metric_logger")]
    for lg in loggers:
        lg.addHandler(collector)
    yield collector
    for lg in loggers:
        lg.removeHandler(collector)


def parsed(collector) -> list:
    out = []
    for record in collector.records:
        try:
            payload = json.loads(record.getMessage())
        except (ValueError, TypeError):
            continue
        if isinstance(payload, dict) and "module" in payload:
            out.append(payload)
    return out
