# ui-connector

WebSocket gateway that streams CCAI transcript events from Redis pub/sub to the Salesforce LWC.

## Connecting

```
GET wss://<host>/ws?conversation_id=<short-id>
Authorization: Bearer <google-id-token>
```

- The token is the Google ID token minted by Apex (`GcpTokenService.getIdToken`). The old `?token=` query parameter is **no longer accepted**; a request that still sends it is closed with `missing_token`.
- `conversation_id` is the short id (`conv-52e5bf76`), not the `projects/.../conversations/<id>` path. Letters, digits, `-`, `_`, max 128.
- Browsers cannot set headers on `new WebSocket(...)`. Only clients that control their handshake headers (server-side callers, Node, Postman, a proxy that injects the header) can use this as-is.

On success the first frame is `HISTORY_BATCH` (buffered turns), followed by live turns as the interpreter publishes them.

### Close codes

| Code | Reason | When |
|---|---|---|
| 1008 | `missing_token`, `invalid_auth_scheme`, `malformed_token`, `invalid_token`, `token_expired`, `bad_audience`, `invalid_issuer`, `no_email_claim`, `email_unverified`, `caller_not_allowed`, `token_replayed`, `verification_unavailable` | Handshake auth failed. Nothing is sent before the close. |
| 1008 | `conversation_not_authorized` | Authz enforced (`WS_ENFORCE_CONV_AUTHZ=true`) and the conversation's meta key is missing. |
| 1008 | `Missing conversation_id` / `Invalid conversation_id` | Preceded by an `ERROR` event with the matching code. |
| 1008 | `token_expired` | Mid-session: the token that opened the socket expired. Mint a new one and reconnect. |
| 1013 | `REDIS_UNAVAILABLE`, `REDIS_ERROR`, `HISTORY_UNAVAILABLE`, `HISTORY_ERROR` | Join failed. Preceded by an `ERROR` event. |
| 1013 | `stream_unavailable` | Redis pub/sub could not be restored after ~30s of retries. |
| 1011 | `stream_error`, `Internal error` | Unexpected server failure. |

`ERROR` events: `{"type": "ERROR", "code", "message", "conversationId", "recoverable", "timestamp"}`. Codes are listed in `connector/constants.py` (`ErrorCode`). `STREAM_PAUSED` / `STREAM_RESUMED` travel as `ERROR` events, as before.

## Layout

```
main.py                     entrypoint (uvicorn main:app), unchanged import path
utils.py                    shared logging utils (unchanged)
connector/
  app.py                    app factory: CORS, routes, startup checks, Redis shutdown
  config.py                 every environment variable, read once
  constants.py              close codes, event/error codes, Redis key layout
  log.py                    "<conversation_id> | ui-connector | ..." on top of utils.py
  log_scrub.py              redacts tokens from uvicorn's own log lines
  redis_client.py           shared async Redis client
  conversations.py          join/leave: server pointer + buffered turns
  auth/
    bearer.py               Authorization: Bearer parsing
    google_certs.py         Google signing-cert cache
    verifier.py             ID-token verification + single-use guard
    authz.py                per-conversation authorization
    models.py               AuthFailure, Principal
  ws/
    endpoint.py             /ws handler: auth -> validate -> authz -> join -> stream
    stream.py               Redis pub/sub -> socket relay with reconnect
    manager.py              sockets held by this pod, per conversation
    messaging.py            send_error / safe_close / reject (never raise)
  routes/health.py          /, /auth-health, /conversation-status
tests/                      pytest suite (fakeredis + locally signed ID tokens)
```

## Logging

All app logs go through `utils.py` and start with the conversation id:

```
conv-52e5bf76 | ui-connector | Connected
conv-52e5bf76 | ui-connector | Rejected: token_expired
-             | ui-connector | Started            (no conversation)
```

`conversation_id` and `module` (e.g. `ws.endpoint`) are also structured fields on each line.

Per connection, expect at most: one `Connected` (info), any warnings/errors, and one `Session closed` line written via `log_metric`, so it appears even at `ENVIRONMENT=prod`. It carries `end_reason`, `duration_s`, `forwarded`, `dropped`, `received` and `client_close_code`. Individual messages are counted, not logged.

## Environment

| Variable | Default | |
|---|---|---|
| `REDISHOST` / `REDISPORT` | `100.72.86.38` / `6379` | Memorystore |
| `GCP_PROJECT_ID` / `LOCATION` | `adtgcp-ent-dev-ccs-tlcm-fe10` / `us-central1` | Only for `/conversation-status` |
| `SERVER_ID` | `1` | Pointer value and channel prefix `<server_id>:<conversation_id>` |
| `SERVER_ID_KEY_TTL` | `3600` | Seconds |
| `WS_TOKEN_AUDIENCE` | *(unset: audience not checked)* | Set before leaving DEV |
| `ALLOWED_SAS` | *(unset: any verified Google identity)* | Comma-separated SA emails |
| `WS_TOKEN_CLOCK_SKEW` | `10` | Seconds |
| `WS_TOKEN_SINGLE_USE` | `false` | Needs Apex to mint a fresh token per connection |
| `WS_ENFORCE_CONV_AUTHZ` | `false` | Warn-only until true |
| `CORS_ALLOW_ORIGINS` | `*` | HTTP endpoints only |
| `ENVIRONMENT` | `dev` | Log level via `utils.py` (prod = errors + metrics only) |

## Run and test

```
pip install -r requirements-dev.txt
pytest
uvicorn main:app --host 0.0.0.0 --port 8080
```
