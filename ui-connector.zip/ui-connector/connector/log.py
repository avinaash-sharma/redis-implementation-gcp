"""
Conversation-scoped logging on top of the shared utils.py.

Every line reads "<conversation_id> | ui-connector | <message>". The same
conversation_id, plus the module that logged it, also ride along as structured
fields. Lines that belong to no conversation (startup, cert refresh) use "-".

    log = get_logger(__name__)
    log.info(conversation_id, "Connected", caller=email, clients=2)
"""

import traceback

import utils

COMPONENT = "ui-connector"
NO_CONVERSATION = "-"

_JSON_SAFE = (str, int, float, bool, type(None))


def describe_error(exc: BaseException) -> str:
    return f"{type(exc).__name__}: {exc}"


class ConversationLogger:
    """
    Prefixes each message and keeps the extra fields JSON-safe: utils._log
    json.dumps them, so an exception or a set passed as a field would otherwise
    make the logging call itself raise.
    """

    __slots__ = ("_module",)

    def __init__(self, module: str):
        self._module = module.removeprefix("connector.")

    def _emit(self, log_fn, conversation_id, message, fields):
        conv = conversation_id or NO_CONVERSATION
        safe = {k: v if isinstance(v, _JSON_SAFE) else str(v) for k, v in fields.items()}
        log_fn(
            f"{conv} | {COMPONENT} | {message}",
            conversation_id=conv,
            module=self._module,
            **safe,
        )

    def debug(self, conversation_id, message, **fields):
        self._emit(utils.log_debug, conversation_id, message, fields)

    def info(self, conversation_id, message, **fields):
        self._emit(utils.log_info, conversation_id, message, fields)

    def warning(self, conversation_id, message, **fields):
        self._emit(utils.log_warning, conversation_id, message, fields)

    def error(self, conversation_id, message, **fields):
        self._emit(utils.log_error, conversation_id, message, fields)

    def exception(self, conversation_id, message, exc: BaseException, **fields):
        """Error line carrying the exception and its traceback as fields."""
        fields["error"] = describe_error(exc)
        fields["traceback"] = "".join(
            traceback.format_exception(type(exc), exc, exc.__traceback__)
        )
        self._emit(utils.log_error, conversation_id, message, fields)

    def metric(self, conversation_id, message, **fields):
        """Always written, whatever the environment's log level (utils.log_metric)."""
        self._emit(utils.log_metric, conversation_id, message, fields)


def get_logger(module: str) -> ConversationLogger:
    return ConversationLogger(module)
