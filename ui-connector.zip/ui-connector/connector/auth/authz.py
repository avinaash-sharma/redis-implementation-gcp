"""Per-conversation authorization."""

from connector.auth.models import AuthFailure, Principal
from connector.config import settings
from connector.constants import META_KEY
from connector.log import describe_error, get_logger
from connector.redis_client import get_redis

log = get_logger(__name__)


async def authorize_conversation(principal: Principal, conversation_id: str) -> None:
    """
    Authentication proves the connection came from Salesforce. It does NOT prove
    this agent is entitled to THIS conversation's transcript. Interim check: the
    interpreter has written the conversation's meta key, i.e. it is a real,
    live conversation.

    Warn-only unless WS_ENFORCE_CONV_AUTHZ=true, because meta may not exist yet
    when the LWC connects very early. Run warn-only, watch for "would reject"
    lines, confirm the interpreter always writes meta first, then enforce.
    Raises AuthFailure when enforcing.
    """
    key = META_KEY.format(conversation_id=conversation_id)
    try:
        exists = await get_redis().exists(key)
    except Exception as exc:
        log.warning(
            conversation_id,
            "Authz check skipped, Redis unavailable (allowing)",
            error=describe_error(exc),
        )
        return

    if exists:
        return
    if settings.enforce_conv_authz:
        raise AuthFailure("conversation_not_authorized", f"missing {key}")

    log.warning(
        conversation_id,
        "Authz would reject (warn-only): meta key missing",
        caller=principal.email,
    )
