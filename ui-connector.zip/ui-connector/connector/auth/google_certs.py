"""
Google's ID-token signing certs, cached in-process.

Fetching per handshake would add a Google round trip to every connection, so
certs are cached for the endpoint's own Cache-Control max-age. Needs egress to
www.googleapis.com: without it EVERY token fails with verification_unavailable,
which looks like a token problem but is a networking one (/auth-health shows it).
"""

import asyncio
import re
import time

import httpx

from connector.log import get_logger

log = get_logger(__name__)

GOOGLE_CERTS_URL = "https://www.googleapis.com/oauth2/v1/certs"
FETCH_TIMEOUT_SECONDS = 5.0
DEFAULT_TTL_SECONDS = 3600
MIN_TTL_SECONDS = 60

# A token signed with a key id we don't hold forces a refetch, because Google
# rotates keys. Anyone can put a random kid in a junk token, so forced
# refetches are capped to one per interval.
MIN_FORCED_REFRESH_SECONDS = 60

_MAX_AGE_RE = re.compile(r"max-age=(\d+)")


class GoogleCertCache:
    def __init__(self, url: str = GOOGLE_CERTS_URL):
        self._url = url
        self._certs: dict = {}
        self._fetched_at = 0.0
        self._expires_at = 0.0
        self._lock = asyncio.Lock()

    async def get(self, force: bool = False) -> dict:
        """kid -> PEM cert. `force` refetches unless we fetched very recently."""
        if self._is_fresh(force):
            return self._certs
        async with self._lock:
            if self._is_fresh(force):  # refreshed while we waited for the lock
                return self._certs
            await self._refresh()
            return self._certs

    def _is_fresh(self, force: bool) -> bool:
        if not self._certs:
            return False
        now = time.time()
        if force:
            return now - self._fetched_at < MIN_FORCED_REFRESH_SECONDS
        return now < self._expires_at

    async def _refresh(self) -> None:
        async with httpx.AsyncClient(timeout=FETCH_TIMEOUT_SECONDS) as client:
            resp = await client.get(self._url)
            resp.raise_for_status()
            certs = resp.json()

        match = _MAX_AGE_RE.search(resp.headers.get("cache-control", ""))
        ttl = max(int(match.group(1)), MIN_TTL_SECONDS) if match else DEFAULT_TTL_SECONDS

        now = time.time()
        self._certs, self._fetched_at, self._expires_at = certs, now, now + ttl
        log.debug(None, "Refreshed Google signing certs", cert_count=len(certs), ttl_s=ttl)


cert_cache = GoogleCertCache()
