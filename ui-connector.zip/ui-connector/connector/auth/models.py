import hashlib
from dataclasses import dataclass


class AuthFailure(Exception):
    """
    A rejected handshake. `reason` is short, stable and safe to send to the
    client — it becomes the WebSocket close reason. `detail` is for logs only
    and never contains the token.
    """

    def __init__(self, reason: str, detail: str = ""):
        self.reason = reason
        self.detail = detail
        super().__init__(f"{reason}: {detail}" if detail else reason)


@dataclass(frozen=True)
class Principal:
    """The verified caller behind a WebSocket connection."""

    email: str
    subject: str
    expires_at: int     # epoch seconds, from the token's `exp`
    fingerprint: str    # see token_fingerprint()


def token_fingerprint(token: str) -> str:
    """Short, non-reversible handle for a token. Safe to log; the token is not."""
    return hashlib.sha256(token.encode("utf-8")).hexdigest()[:32]
