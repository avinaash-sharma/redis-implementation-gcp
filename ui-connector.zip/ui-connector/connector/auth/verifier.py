"""
Verify the Google-issued ID token presented on the WebSocket handshake.

Minted by Salesforce Apex (GcpTokenService.getIdToken) for audience
WS_TOKEN_AUDIENCE. Checks signature, issuer, audience, expiry, email_verified
and the ALLOWED_SAS allowlist, then optionally burns the token so it can't be
replayed.
"""

import asyncio
import time
from typing import Optional

from google.auth import jwt as google_jwt

from connector.auth.google_certs import cert_cache
from connector.auth.models import AuthFailure, Principal, token_fingerprint
from connector.config import settings
from connector.constants import REPLAY_KEY
from connector.log import describe_error, get_logger
from connector.redis_client import get_redis

log = get_logger(__name__)

VALID_ISSUERS = ("https://accounts.google.com", "accounts.google.com")

# Google ID tokens are ~1 KB. The structural gate below runs before any RSA
# work, so junk is turned away cheaply.
MAX_TOKEN_LENGTH = 8192


async def verify_id_token(token: str, conversation_id: Optional[str] = None) -> Principal:
    """
    Return the verified Principal, or RAISE AuthFailure.

    It never returns a falsy value: `if not await verify_id_token(...)` would
    accept everything, because a Principal is always truthy.
    `conversation_id` is only used to tag log lines.
    """
    if token.count(".") != 2 or len(token) > MAX_TOKEN_LENGTH:
        raise AuthFailure("malformed_token", f"len={len(token)}")

    claims = await _decode_and_verify(token)
    email = _check_identity(claims)
    expires_at = int(claims.get("exp", 0))
    fingerprint = token_fingerprint(token)

    if settings.single_use_tokens:
        await _burn_token(fingerprint, expires_at, email, conversation_id)

    return Principal(
        email=email,
        subject=claims.get("sub", ""),
        expires_at=expires_at,
        fingerprint=fingerprint,
    )


async def _decode_and_verify(token: str) -> dict:
    try:
        certs = await cert_cache.get()
        key_id = _unverified_key_id(token)
        if key_id and key_id not in certs:
            # Signed with a key we don't hold yet: Google may have rotated.
            certs = await cert_cache.get(force=True)
    except Exception as exc:
        raise AuthFailure("verification_unavailable", describe_error(exc)) from exc

    try:
        # RSA verification is CPU-bound; keep it off the event loop.
        return await asyncio.to_thread(
            google_jwt.decode,
            token,
            certs=certs,
            audience=settings.token_audience or None,
            clock_skew_in_seconds=settings.clock_skew_seconds,
        )
    except ValueError as exc:
        message = str(exc).lower()
        if "expired" in message:
            reason = "token_expired"
        elif "audience" in message:
            reason = "bad_audience"
        else:
            reason = "invalid_token"
        raise AuthFailure(reason, str(exc)) from exc
    except Exception as exc:
        raise AuthFailure("verification_unavailable", describe_error(exc)) from exc


def _unverified_key_id(token: str) -> Optional[str]:
    try:
        return google_jwt.decode_header(token).get("kid")
    except Exception:
        return None  # decode() will reject it properly


def _check_identity(claims: dict) -> str:
    if claims.get("iss") not in VALID_ISSUERS:
        raise AuthFailure("invalid_issuer", str(claims.get("iss")))

    email = str(claims.get("email") or "").lower()
    if not email:
        raise AuthFailure("no_email_claim")
    if not claims.get("email_verified", False):
        raise AuthFailure("email_unverified", email)
    if settings.allowed_sas and email not in settings.allowed_sas:
        raise AuthFailure("caller_not_allowed", email)
    return email


async def _burn_token(
    fingerprint: str, expires_at: int, email: str, conversation_id: Optional[str]
) -> None:
    """
    Single-use guard (WS_TOKEN_SINGLE_USE=true). Google ID tokens live ~1h and
    are reusable by nature; recording the fingerprint on first use closes the
    replay window for a leaked token.

    PREREQUISITE: Apex must mint a fresh token per connection attempt. If
    GcpTokenService caches the token for the hour, every reconnect after the
    first fails with token_replayed.

    Fails OPEN on Redis errors so a Memorystore blip doesn't black out the agent
    desktop. Raise instead if policy requires fail-closed.
    """
    key = REPLAY_KEY.format(fingerprint=fingerprint)
    ttl = max(expires_at - int(time.time()), 1)
    try:
        first_use = await get_redis().set(key, "1", ex=ttl, nx=True)
    except Exception as exc:
        log.warning(
            conversation_id,
            "Replay guard skipped, Redis unavailable (failing open)",
            fp=fingerprint,
            error=describe_error(exc),
        )
        return
    if not first_use:
        raise AuthFailure("token_replayed", email)
