"""
Read the bearer token from the WebSocket handshake.

    Authorization: Bearer <google-id-token>

The old ?token=<id_token> query parameter is no longer accepted. A request that
still sends it is rejected as missing_token, with a log detail that says why.
"""

from starlette.requests import HTTPConnection

from connector.auth.models import AuthFailure

_SCHEME = "bearer"


def extract_bearer_token(conn: HTTPConnection) -> str:
    """Return the raw token, or raise AuthFailure. Works for WebSocket and Request."""
    header = (conn.headers.get("authorization") or "").strip()

    if not header:
        detail = (
            "token sent as ?token= query param, which is no longer accepted"
            if "token" in conn.query_params
            else "no Authorization header"
        )
        raise AuthFailure("missing_token", detail)

    scheme, _, credentials = header.partition(" ")
    if scheme.lower() != _SCHEME:
        # Never echo the header back: without a scheme, `scheme` IS the token.
        detail = "missing 'Bearer ' prefix" if not credentials else "unsupported auth scheme"
        raise AuthFailure("invalid_auth_scheme", detail)

    token = credentials.strip()
    if not token:
        raise AuthFailure("missing_token", "empty Bearer credentials")
    return token
