"""Handshake authentication (Authorization: Bearer <Google ID token>) and authorization."""

from connector.auth.authz import authorize_conversation
from connector.auth.bearer import extract_bearer_token
from connector.auth.google_certs import cert_cache
from connector.auth.models import AuthFailure, Principal
from connector.auth.verifier import verify_id_token

__all__ = [
    "AuthFailure",
    "Principal",
    "authorize_conversation",
    "cert_cache",
    "extract_bearer_token",
    "verify_id_token",
]
