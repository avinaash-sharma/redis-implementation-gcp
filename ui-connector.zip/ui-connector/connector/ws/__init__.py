"""WebSocket gateway: /ws endpoint, per-pod connection registry, live stream relay."""
