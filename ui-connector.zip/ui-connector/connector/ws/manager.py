from fastapi import WebSocket


class ConnectionManager:
    """
    Sockets open on THIS pod, per conversation. Decides when to leave(): the
    Redis server pointer is cleared only when the last local socket for a
    conversation closes.
    """

    def __init__(self):
        self._active: dict = {}

    def add(self, conversation_id: str, websocket: WebSocket) -> int:
        """Register a socket; returns the conversation's local client count."""
        sockets = self._active.setdefault(conversation_id, set())
        sockets.add(websocket)
        return len(sockets)

    def remove(self, conversation_id: str, websocket: WebSocket) -> int:
        """Unregister a socket; returns how many remain for the conversation."""
        sockets = self._active.get(conversation_id)
        if not sockets:
            return 0
        sockets.discard(websocket)
        if not sockets:
            del self._active[conversation_id]
            return 0
        return len(sockets)

    def client_count(self, conversation_id: str) -> int:
        return len(self._active.get(conversation_id, ()))

    def conversation_ids(self) -> list:
        return list(self._active)

    @property
    def connection_count(self) -> int:
        return sum(len(sockets) for sockets in self._active.values())


manager = ConnectionManager()
