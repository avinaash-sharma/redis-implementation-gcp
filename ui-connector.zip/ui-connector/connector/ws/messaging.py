"""Socket helpers that never raise, so callers don't guard every send or close."""

from datetime import datetime, timezone
from typing import Optional

from fastapi import WebSocket
from starlette.websockets import WebSocketState

from connector.constants import EVENT_ERROR, WS_CLOSE_POLICY_VIOLATION, WS_CLOSE_REASON_MAX


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


async def send_error(
    websocket: WebSocket,
    code: str,
    message: str,
    conversation_id: Optional[str] = None,
    recoverable: bool = True,
) -> None:
    """Send a structured ERROR event. A socket that is already gone is ignored."""
    try:
        await websocket.send_json({
            "type": EVENT_ERROR,
            "code": code,
            "message": message,
            "conversationId": conversation_id,
            "recoverable": recoverable,
            "timestamp": now_iso(),
        })
    except Exception:
        pass


async def safe_close(websocket: WebSocket, code: int, reason: str) -> None:
    """Close the socket if both sides still have it open."""
    if (
        websocket.client_state != WebSocketState.CONNECTED
        or websocket.application_state != WebSocketState.CONNECTED
    ):
        return
    try:
        await websocket.close(code=code, reason=reason[:WS_CLOSE_REASON_MAX])
    except Exception:
        pass


async def reject(websocket: WebSocket, reason: str, code: int = WS_CLOSE_POLICY_VIOLATION) -> None:
    """
    Turn away a handshake that failed auth, authz or validation.

    Accept-then-close is deliberate: the browser only exposes event.code and
    event.reason in onclose after a completed handshake. Closing before accept
    surfaces as a bare 1006 with no reason, which is very hard to debug with
    F5 XC in the path. Nothing is sent before the close, so the security
    posture is the same either way.
    """
    try:
        await websocket.accept()
    except Exception:
        return
    await safe_close(websocket, code, reason)
