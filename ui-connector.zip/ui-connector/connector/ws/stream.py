"""Relay a conversation's Redis pub/sub channel to its WebSocket."""

import asyncio
import json
from dataclasses import dataclass
from typing import Optional

from fastapi import WebSocket

from connector.config import settings
from connector.constants import CHANNEL, ErrorCode
from connector.log import describe_error, get_logger
from connector.redis_client import REDIS_UNREACHABLE, RedisConnectionError, get_redis
from connector.ws.messaging import send_error

log = get_logger(__name__)

MAX_RECONNECT_ATTEMPTS = 5
RECONNECT_BACKOFF_SECONDS = 2   # linear: 2, 4, 6, 8, 10s -> ~30s before giving up

# Why forward_live_turns() stopped.
CLIENT_GONE = "client_gone"
STREAM_UNAVAILABLE = "stream_unavailable"   # Redis could not be recovered
STREAM_ERROR = "stream_error"               # unexpected failure


@dataclass
class SessionStats:
    """Per-connection counters, reported once in the "Session closed" line."""

    forwarded: int = 0                        # live turns sent to the client
    dropped: int = 0                          # malformed pub/sub payloads skipped
    received: int = 0                         # inbound client frames (keep-alives)
    client_close_code: Optional[int] = None


async def forward_live_turns(conversation_id: str, websocket: WebSocket, stats: SessionStats) -> str:
    """
    Forward every message on "<server_id>:<conversation_id>" until the client
    goes away or Redis can't be recovered, and return why it stopped. Sends
    STREAM_PAUSED / RESUMED / UNAVAILABLE / ERROR events but never closes the
    socket; the caller owns its lifetime.
    """
    channel = CHANNEL.format(server_id=settings.server_id, conversation_id=conversation_id)
    attempt = 0

    while True:
        pubsub = get_redis().pubsub()
        try:
            await pubsub.subscribe(channel)
            if attempt:
                log.info(conversation_id, "Live stream resumed", after_attempts=attempt)
                await send_error(
                    websocket, ErrorCode.STREAM_RESUMED, "Live stream resumed.",
                    conversation_id, recoverable=True,
                )
                attempt = 0

            async for message in pubsub.listen():
                if message.get("type") != "message":
                    continue
                try:
                    payload = json.loads(message["data"])
                except (json.JSONDecodeError, TypeError, UnicodeDecodeError):
                    stats.dropped += 1
                    continue
                try:
                    await websocket.send_json(payload)
                except Exception:
                    return CLIENT_GONE
                stats.forwarded += 1

            # listen() only returns once unsubscribed, which we never do; treat
            # it as a dropped connection rather than spinning on resubscribe.
            raise RedisConnectionError("pub/sub listener ended unexpectedly")

        except REDIS_UNREACHABLE as exc:
            attempt += 1
            log.warning(
                conversation_id, "Redis connection lost, retrying",
                attempt=attempt, max_attempts=MAX_RECONNECT_ATTEMPTS, error=describe_error(exc),
            )
            await send_error(
                websocket, ErrorCode.STREAM_PAUSED,
                "Live stream temporarily paused — reconnecting to backend.",
                conversation_id, recoverable=True,
            )
            if attempt > MAX_RECONNECT_ATTEMPTS:
                log.error(conversation_id, "Live stream could not be restored", attempts=MAX_RECONNECT_ATTEMPTS)
                await send_error(
                    websocket, ErrorCode.STREAM_UNAVAILABLE,
                    "Live stream could not be restored. Please refresh to reconnect.",
                    conversation_id, recoverable=False,
                )
                return STREAM_UNAVAILABLE
            await asyncio.sleep(RECONNECT_BACKOFF_SECONDS * attempt)

        except asyncio.CancelledError:
            raise

        except Exception as exc:
            log.exception(conversation_id, "Live stream failed unexpectedly", exc)
            await send_error(
                websocket, ErrorCode.STREAM_ERROR,
                "An unexpected error stopped the live stream.",
                conversation_id, recoverable=False,
            )
            return STREAM_ERROR

        finally:
            try:
                await pubsub.aclose()   # drops the subscription with the connection
            except Exception:
                pass
