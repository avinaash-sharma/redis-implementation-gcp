"""
/ws — live transcript stream for one conversation.

    URL:     wss://<host>/ws?conversation_id=<short-id>
    Header:  Authorization: Bearer <google-id-token>

Flow: authenticate -> validate conversation_id -> authorize -> accept ->
join (Redis pointer + buffered turns) -> HISTORY_BATCH -> live stream, until
the client leaves, the token expires, or the stream can't be recovered.
"""

import asyncio
import re
import time
from typing import Optional

from fastapi import APIRouter, Query, WebSocket, WebSocketDisconnect

from connector import conversations
from connector.auth import (
    AuthFailure,
    Principal,
    authorize_conversation,
    extract_bearer_token,
    verify_id_token,
)
from connector.constants import (
    CONVERSATION_ID_PATTERN,
    EVENT_HISTORY_BATCH,
    WS_CLOSE_INTERNAL_ERROR,
    WS_CLOSE_POLICY_VIOLATION,
    WS_CLOSE_TRY_AGAIN_LATER,
    ErrorCode,
)
from connector.log import get_logger
from connector.ws import stream
from connector.ws.manager import manager
from connector.ws.messaging import now_iso, reject, safe_close, send_error

log = get_logger(__name__)
router = APIRouter()

_CONVERSATION_ID_RE = re.compile(CONVERSATION_ID_PATTERN)

# Why a session ended; reported in the "Session closed" metric line.
END_CLIENT_DISCONNECTED = "client_disconnected"
END_TOKEN_EXPIRED = "token_expired"
END_INTERNAL_ERROR = "internal_error"
END_SERVER_SHUTDOWN = "server_shutdown"


@router.websocket("/ws")
async def websocket_endpoint(
    websocket: WebSocket,
    conversation_id: Optional[str] = Query(None, description="CCAI conversation id (short form)"),
):
    conv_id = (conversation_id or "").strip()
    is_valid_id = bool(_CONVERSATION_ID_RE.fullmatch(conv_id))
    log_id = conv_id if is_valid_id else None   # never put unvalidated input in the prefix

    # 1. Authenticate before anything else, so unauthenticated callers learn nothing.
    principal = await _authenticate(websocket, log_id)
    if principal is None:
        return

    # 2. Validate the id. It is used verbatim as a Redis key.
    if not is_valid_id:
        await _reject_conversation_id(websocket, conv_id, principal)
        return

    # 3. Authorize this caller for this conversation.
    try:
        await authorize_conversation(principal, conv_id)
    except AuthFailure as af:
        log.warning(conv_id, f"Rejected: {af.reason}", caller=principal.email, detail=af.detail)
        await reject(websocket, af.reason)
        return

    await websocket.accept()
    await _serve(websocket, conv_id, principal)


async def _authenticate(websocket: WebSocket, log_id: Optional[str]) -> Optional[Principal]:
    try:
        token = extract_bearer_token(websocket)
        return await verify_id_token(token, conversation_id=log_id)
    except AuthFailure as af:
        # verification_unavailable is our outage (cert fetch / egress), not a bad
        # client, so it is logged as an error and survives ENVIRONMENT=prod.
        emit = log.error if af.reason == "verification_unavailable" else log.warning
        emit(log_id, f"Rejected: {af.reason}", peer=_peer(websocket), detail=af.detail)
        await reject(websocket, af.reason)
        return None


async def _reject_conversation_id(websocket: WebSocket, conv_id: str, principal: Principal) -> None:
    if conv_id:
        code, reason = ErrorCode.INVALID_CONVERSATION_ID, "Invalid conversation_id"
        message = "Query parameter 'conversation_id' must be the short id: letters, digits, '-' or '_' (max 128)."
    else:
        code, reason = ErrorCode.MISSING_CONVERSATION_ID, "Missing conversation_id"
        message = "Query parameter 'conversation_id' is required."

    log.warning(None, f"Rejected: {code.lower()}", caller=principal.email, received=conv_id[:64])
    await websocket.accept()
    await send_error(websocket, code, message, conversation_id=None, recoverable=False)
    await safe_close(websocket, WS_CLOSE_POLICY_VIOLATION, reason)


async def _serve(websocket: WebSocket, conv_id: str, principal: Principal) -> None:
    clients = manager.add(conv_id, websocket)
    started = time.monotonic()
    stats = stream.SessionStats()
    end_reason = END_INTERNAL_ERROR

    try:
        try:
            turns = await conversations.join(conv_id)
        except conversations.JoinError as je:
            log.error(conv_id, f"Join failed: {je.code}", detail=je.detail)
            await send_error(websocket, je.code, je.message, conv_id, je.recoverable)
            await safe_close(websocket, WS_CLOSE_TRY_AGAIN_LATER, je.code)
            end_reason = je.code.lower()
            return

        await websocket.send_json({
            "type": EVENT_HISTORY_BATCH,
            "conversationId": conv_id,
            "turns": turns,
            "totalTurns": len(turns),
            "timestamp": now_iso(),
        })
        log.info(
            conv_id, "Connected",
            caller=principal.email, fp=principal.fingerprint, clients=clients,
            history_turns=len(turns), token_ttl_s=principal.expires_at - int(time.time()),
        )
        end_reason = await _run_until_closed(websocket, conv_id, principal, stats)

    except WebSocketDisconnect:
        end_reason = END_CLIENT_DISCONNECTED

    except asyncio.CancelledError:
        end_reason = END_SERVER_SHUTDOWN
        raise

    except Exception as exc:
        log.exception(conv_id, "Unhandled session error", exc)
        await send_error(
            websocket, ErrorCode.INTERNAL_ERROR, "An unexpected error occurred.",
            conv_id, recoverable=False,
        )
        await safe_close(websocket, WS_CLOSE_INTERNAL_ERROR, "Internal error")
        end_reason = END_INTERNAL_ERROR

    finally:
        remaining = manager.remove(conv_id, websocket)
        log.metric(
            conv_id, "Session closed",
            caller=principal.email, end_reason=end_reason,
            duration_s=round(time.monotonic() - started, 1),
            forwarded=stats.forwarded, dropped=stats.dropped, received=stats.received,
            client_close_code=stats.client_close_code, clients_left=remaining,
        )
        if remaining == 0:
            # Shielded so the pointer is still cleared if we're cancelled mid-cleanup.
            await asyncio.shield(conversations.leave(conv_id))


async def _run_until_closed(
    websocket: WebSocket, conv_id: str, principal: Principal, stats: stream.SessionStats
) -> str:
    """
    Run the inbound reader, the live stream and the token-expiry timer together.
    Whichever finishes first decides how the socket ends; the others are cancelled.
    """
    reader = asyncio.create_task(_drain_inbound(websocket, stats))
    relay = asyncio.create_task(stream.forward_live_turns(conv_id, websocket, stats))
    # Bind the socket's lifetime to the token that opened it. BackendConfig
    # timeoutSec and the ID token lifetime are both ~3600s, so without this a
    # connection can outlive its credential.
    expiry = asyncio.create_task(asyncio.sleep(max(principal.expires_at - time.time(), 0)))
    tasks = (reader, relay, expiry)

    try:
        done, _ = await asyncio.wait(tasks, return_when=asyncio.FIRST_COMPLETED)
    finally:
        await _cancel_and_wait(tasks)

    if reader in done:
        reader.result()   # re-raise anything unexpected
        return END_CLIENT_DISCONNECTED

    if relay in done:
        outcome = relay.result()
        if outcome == stream.CLIENT_GONE:
            return END_CLIENT_DISCONNECTED
        # Don't leave a socket open with a dead stream behind it: the UI would
        # look connected but never update. Closing lets the client reconnect.
        close_code = (
            WS_CLOSE_TRY_AGAIN_LATER if outcome == stream.STREAM_UNAVAILABLE else WS_CLOSE_INTERNAL_ERROR
        )
        await safe_close(websocket, close_code, outcome)
        return outcome

    # The client should mint a fresh token and reconnect.
    await safe_close(websocket, WS_CLOSE_POLICY_VIOLATION, "token_expired")
    return END_TOKEN_EXPIRED


async def _cancel_and_wait(tasks) -> None:
    """
    Cancel the helpers and wait for them to unwind. asyncio.wait, not gather:
    if this coroutine is itself cancelled meanwhile (server shutdown), gather
    would raise the CHILD's CancelledError in place of ours, and the server
    would no longer recognise the cancellation as its own.
    """
    for task in tasks:
        task.cancel()
    await asyncio.wait(tasks)
    for task in tasks:
        if not task.cancelled():
            task.exception()   # mark retrieved; real errors are re-raised by the caller


async def _drain_inbound(websocket: WebSocket, stats: stream.SessionStats) -> None:
    """Consume client frames (keep-alives) until the client closes. Content is never logged."""
    while True:
        message = await websocket.receive()
        if message["type"] == "websocket.disconnect":
            stats.client_close_code = message.get("code")
            return
        stats.received += 1


def _peer(websocket: WebSocket) -> str:
    return websocket.client.host if websocket.client else "unknown"
