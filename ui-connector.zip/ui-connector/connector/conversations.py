"""
Redis bookkeeping for a conversation: the server pointer the interpreter uses
to route live turns, and the buffered turns replayed on connect.
"""

import json

from connector.config import settings
from connector.constants import SERVER_ID_KEY, TURNS_KEY, ErrorCode
from connector.log import describe_error, get_logger
from connector.redis_client import REDIS_UNREACHABLE, RedisError, get_redis

log = get_logger(__name__)


class JoinError(Exception):
    """Joining failed. `code`/`message` go to the client; `detail` to logs."""

    def __init__(self, code: str, message: str, detail: str = "", recoverable: bool = True):
        super().__init__(message)
        self.code = code
        self.message = message
        self.detail = detail
        self.recoverable = recoverable


async def join(conversation_id: str) -> list:
    """Point the conversation at this server and return its buffered turns."""
    redis = get_redis()

    try:
        await redis.set(
            SERVER_ID_KEY.format(conversation_id=conversation_id),
            settings.server_id,
            ex=settings.server_id_key_ttl,
        )
    except REDIS_UNREACHABLE as exc:
        raise JoinError(
            ErrorCode.REDIS_UNAVAILABLE,
            "Cannot reach live stream backend. Please try again shortly.",
            describe_error(exc),
        ) from exc
    except RedisError as exc:
        raise JoinError(
            ErrorCode.REDIS_ERROR,
            "Backend error while joining the conversation.",
            describe_error(exc),
        ) from exc

    try:
        raw_turns = await redis.lrange(TURNS_KEY.format(conversation_id=conversation_id), 0, -1)
    except REDIS_UNREACHABLE as exc:
        raise JoinError(
            ErrorCode.HISTORY_UNAVAILABLE,
            "Connected, but couldn't load prior transcript. Live turns will still stream.",
            describe_error(exc),
        ) from exc
    except RedisError as exc:
        raise JoinError(
            ErrorCode.HISTORY_ERROR,
            "Backend error while loading prior transcript.",
            describe_error(exc),
        ) from exc

    turns, skipped = [], 0
    for raw in raw_turns:
        try:
            turns.append(json.loads(raw))
        except (json.JSONDecodeError, TypeError, UnicodeDecodeError):
            skipped += 1
    if skipped:
        log.warning(conversation_id, "Skipped malformed buffered turns", skipped=skipped, loaded=len(turns))
    return turns


async def leave(conversation_id: str) -> None:
    """Clear the server pointer. Best effort: the key's TTL cleans up if this fails."""
    try:
        await get_redis().delete(SERVER_ID_KEY.format(conversation_id=conversation_id))
    except Exception as exc:
        log.warning(
            conversation_id,
            "Could not clear server pointer, TTL will expire it",
            error=describe_error(exc),
        )
