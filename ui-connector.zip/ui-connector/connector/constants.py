"""
Wire-level constants: WebSocket close codes, the events and error codes the
frontend switches on, and the Redis layout shared with adt-pubsub-interpreter.
"""

# ─── WebSocket close codes (RFC 6455) ─────────────────────────────────────────
WS_CLOSE_NORMAL = 1000
WS_CLOSE_POLICY_VIOLATION = 1008   # auth/authz failure, bad request, token expiry
WS_CLOSE_INTERNAL_ERROR = 1011     # unexpected server failure
WS_CLOSE_TRY_AGAIN_LATER = 1013    # Redis / backend unavailable

# RFC 6455 caps the close reason at 123 bytes; some stacks raise rather than
# truncate, so every close reason is sliced to this.
WS_CLOSE_REASON_MAX = 123


# ─── Events sent to the client ────────────────────────────────────────────────
EVENT_HISTORY_BATCH = "HISTORY_BATCH"
EVENT_ERROR = "ERROR"


class ErrorCode:
    """`code` values carried by ERROR events."""

    MISSING_CONVERSATION_ID = "MISSING_CONVERSATION_ID"
    INVALID_CONVERSATION_ID = "INVALID_CONVERSATION_ID"
    REDIS_UNAVAILABLE = "REDIS_UNAVAILABLE"
    REDIS_ERROR = "REDIS_ERROR"
    HISTORY_UNAVAILABLE = "HISTORY_UNAVAILABLE"
    HISTORY_ERROR = "HISTORY_ERROR"
    STREAM_PAUSED = "STREAM_PAUSED"
    STREAM_RESUMED = "STREAM_RESUMED"
    STREAM_UNAVAILABLE = "STREAM_UNAVAILABLE"
    STREAM_ERROR = "STREAM_ERROR"
    INTERNAL_ERROR = "INTERNAL_ERROR"


# ─── Redis layout (must match adt-pubsub-interpreter exactly) ────────────────
# conversation_id is the SHORT id (e.g. "conv-52e5bf76"), never the full
# projects/.../conversations/<id> resource path.
SERVER_ID_KEY = "{conversation_id}"                   # -> server_id holding the socket
TURNS_KEY = "conversation:{conversation_id}:turns"    # buffered turns (list)
META_KEY = "conversation:{conversation_id}:meta"      # written by the interpreter
CHANNEL = "{server_id}:{conversation_id}"             # live pub/sub channel
REPLAY_KEY = "ws:tok:{fingerprint}"                   # single-use token guard

# The id is used verbatim as a Redis key, so ':' (the namespace separator) must
# never get through. Otherwise a caller could pass "conversation:<other>:turns"
# and have the disconnect cleanup DELETE another call's buffered history.
CONVERSATION_ID_PATTERN = r"[A-Za-z0-9_-]{1,128}"
