"""Application factory: middleware, routes, startup checks, shutdown cleanup."""

import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from connector.config import settings
from connector.log import get_logger
from connector.log_scrub import install_uvicorn_scrubbing
from connector.redis_client import close_redis
from connector.routes import health
from connector.ws import endpoint

log = get_logger(__name__)

# Per-request INFO lines from the HTTP client used for cert fetches.
_QUIET_LOGGERS = ("httpx", "httpcore")


def _warn_on_unsafe_config() -> None:
    if not settings.token_audience:
        log.warning(
            None,
            "WS_TOKEN_AUDIENCE unset: audience check SKIPPED. An ID token minted by an "
            "allowlisted SA for ANY other endpoint would be accepted. Set before leaving DEV.",
        )
    if not settings.allowed_sas:
        log.warning(None, "ALLOWED_SAS empty: any verified Google identity is accepted.")


@asynccontextmanager
async def lifespan(_app: FastAPI):
    _warn_on_unsafe_config()
    log.info(
        None, "Started",
        server_id=settings.server_id,
        single_use_tokens=settings.single_use_tokens,
        enforce_conv_authz=settings.enforce_conv_authz,
    )
    try:
        yield
    finally:
        await close_redis()


def create_app() -> FastAPI:
    install_uvicorn_scrubbing()
    for name in _QUIET_LOGGERS:
        logging.getLogger(name).setLevel(logging.WARNING)

    app = FastAPI(title="UI Connector — WebSocket Gateway", lifespan=lifespan)
    # Applies to the HTTP endpoints only; CORS does not govern WebSocket handshakes.
    app.add_middleware(
        CORSMiddleware,
        allow_origins=list(settings.cors_allow_origins),
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )
    app.include_router(health.router)
    app.include_router(endpoint.router)
    return app
