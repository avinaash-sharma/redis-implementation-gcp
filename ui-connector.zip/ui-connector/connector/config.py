"""
Runtime configuration, read once from the environment at import.

Every environment variable the service reads is here, so the whole deployment
surface is visible in one file (and mirrored in the README table).
"""

import os
from dataclasses import dataclass


def _env_str(name: str, default: str = "") -> str:
    # Set-but-empty falls back to the default, same as unset.
    return os.environ.get(name, "").strip() or default


def _env_int(name: str, default: int) -> int:
    raw = os.environ.get(name, "").strip()
    return int(raw) if raw else default


def _env_bool(name: str, default: bool = False) -> bool:
    raw = os.environ.get(name, "").strip().lower()
    return raw in ("1", "true", "yes") if raw else default


def _env_list(name: str, default: str = "") -> tuple[str, ...]:
    raw = os.environ.get(name, "").strip() or default
    return tuple(item.strip() for item in raw.split(",") if item.strip())


@dataclass(frozen=True)
class Settings:
    # ── GCP / CCAI ────────────────────────────────────────────────────────────
    project_id: str
    location: str

    # ── Redis (Memorystore) ───────────────────────────────────────────────────
    redis_host: str
    redis_port: int

    # ── Routing ───────────────────────────────────────────────────────────────
    # Written to Redis as "<conversation_id> -> server_id" and used as the
    # channel prefix "<server_id>:<conversation_id>". Every pod currently uses
    # "1", so every pod holding a socket for a conversation receives its turns.
    # If this ever becomes per-pod, inject the pod name via the downward API;
    # the metadata server's instance/id is the NODE, shared by all its pods.
    server_id: str
    server_id_key_ttl: int

    # ── Auth ──────────────────────────────────────────────────────────────────
    token_audience: str
    allowed_sas: frozenset
    clock_skew_seconds: int
    single_use_tokens: bool
    enforce_conv_authz: bool

    # ── HTTP ──────────────────────────────────────────────────────────────────
    cors_allow_origins: tuple


def load_settings() -> Settings:
    return Settings(
        project_id=_env_str("GCP_PROJECT_ID", "adtgcp-ent-dev-ccs-tlcm-fe10"),
        location=_env_str("LOCATION", "us-central1"),
        redis_host=_env_str("REDISHOST", "100.72.86.38"),
        redis_port=_env_int("REDISPORT", 6379),
        server_id=_env_str("SERVER_ID", "1"),
        server_id_key_ttl=_env_int("SERVER_ID_KEY_TTL", 3600),
        token_audience=_env_str("WS_TOKEN_AUDIENCE"),
        allowed_sas=frozenset(sa.lower() for sa in _env_list("ALLOWED_SAS")),
        clock_skew_seconds=_env_int("WS_TOKEN_CLOCK_SKEW", 10),
        single_use_tokens=_env_bool("WS_TOKEN_SINGLE_USE"),
        enforce_conv_authz=_env_bool("WS_ENFORCE_CONV_AUTHZ"),
        cors_allow_origins=_env_list("CORS_ALLOW_ORIGINS", "*"),
    )


settings = load_settings()
