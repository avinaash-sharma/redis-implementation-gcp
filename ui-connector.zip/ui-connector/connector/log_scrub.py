"""
Redact tokens from uvicorn's own log lines.

Two ways a token reaches uvicorn's logs even though the app never logs it:
  - `--log-level debug`: the websockets backends log every handshake header,
    so "authorization: Bearer eyJ..." is written verbatim.
  - A client still on the old ?token= URL: the token is in the handshake line
    ('"WebSocket /ws?...&token=eyJ..." [accepted]') and the access log.
Both go through uvicorn.error / uvicorn.access, which this filters. It covers
this process only: GCP ILB and F5 XC request logs are written upstream.
"""

import logging
import re

_SECRET_PARAM_RE = re.compile(
    r"([?&](?:token|ticket|access_token|id_token)=)([^&\s\"']+)", re.IGNORECASE
)
_BARE_JWT_RE = re.compile(r"\beyJ[A-Za-z0-9_\-]{8,}\.[A-Za-z0-9_\-]{8,}\.[A-Za-z0-9_\-]+")


def scrub_secrets(text: str) -> str:
    return _BARE_JWT_RE.sub("REDACTED_JWT", _SECRET_PARAM_RE.sub(r"\1REDACTED", text))


class SecretScrubbingFilter(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:
        if isinstance(record.msg, str):
            record.msg = scrub_secrets(record.msg)
        if isinstance(record.args, tuple):
            record.args = tuple(scrub_secrets(a) if isinstance(a, str) else a for a in record.args)
        elif isinstance(record.args, dict):
            record.args = {k: scrub_secrets(v) if isinstance(v, str) else v for k, v in record.args.items()}
        return True


def install_uvicorn_scrubbing() -> None:
    scrubber = SecretScrubbingFilter()
    for name in ("uvicorn.access", "uvicorn.error"):
        logger = logging.getLogger(name)
        if not any(isinstance(f, SecretScrubbingFilter) for f in logger.filters):
            logger.addFilter(scrubber)
