"""Shared async Redis (Memorystore) client — one connection pool per process."""

from typing import Optional

import redis.asyncio as aioredis
from redis.exceptions import ConnectionError as RedisConnectionError
from redis.exceptions import RedisError
from redis.exceptions import TimeoutError as RedisTimeoutError

from connector.config import settings

__all__ = [
    "REDIS_UNREACHABLE",
    "RedisConnectionError",
    "RedisError",
    "RedisTimeoutError",
    "close_redis",
    "get_redis",
    "set_redis",
]

# "Redis is unreachable right now" (retryable), as opposed to RedisError in
# general, which also covers "Redis rejected this command".
REDIS_UNREACHABLE = (RedisConnectionError, RedisTimeoutError)

_client: Optional[aioredis.Redis] = None


def get_redis() -> aioredis.Redis:
    """The process-wide client, created on first use (connections are lazy)."""
    global _client
    if _client is None:
        _client = aioredis.Redis(
            host=settings.redis_host,
            port=settings.redis_port,
            health_check_interval=10,
            socket_connect_timeout=15,
            retry_on_timeout=True,
            socket_keepalive=True,
        )
    return _client


def set_redis(client: Optional[aioredis.Redis]) -> None:
    """Swap the client (tests)."""
    global _client
    _client = client


async def close_redis() -> None:
    global _client
    if _client is not None:
        await _client.aclose()
        _client = None
