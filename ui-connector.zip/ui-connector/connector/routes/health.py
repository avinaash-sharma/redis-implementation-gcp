"""HTTP endpoints: liveness, auth readiness, per-conversation status."""

import asyncio

from fastapi import APIRouter, HTTPException, Query

from connector.auth import cert_cache
from connector.config import settings
from connector.log import describe_error
from connector.redis_client import get_redis
from connector.ws.manager import manager
from connector.ws.messaging import now_iso

router = APIRouter()

# Keep probes fast: the Redis client's own connect timeout (15s) is longer
# than a typical load-balancer health-check timeout.
PROBE_TIMEOUT_SECONDS = 2.0


@router.get("/")
async def health():
    """
    Always 200. Reports Redis reachability so monitoring can tell
    "service up, backend down" from "service down".
    """
    try:
        pong = await asyncio.wait_for(get_redis().ping(), PROBE_TIMEOUT_SECONDS)
        redis_status = "connected" if pong else "no-response"
    except Exception as exc:
        redis_status = f"unreachable: {describe_error(exc)}"

    return {
        "status": "ui-connector running",
        "redis": redis_status,
        "active_conversations": manager.conversation_ids(),
        "time": now_iso(),
    }


@router.get("/auth-health")
async def auth_health():
    """
    Can this pod reach Google's signing certs, and which auth settings are live?
    Separates "token is bad" from "pod has no egress" without reading logs.
    Reports whether config is set, never its values.
    """
    try:
        certs = await asyncio.wait_for(cert_cache.get(), PROBE_TIMEOUT_SECONDS * 3)
        certs_status, cert_count = "reachable", len(certs)
    except Exception as exc:
        certs_status, cert_count = f"unreachable: {describe_error(exc)}", 0

    return {
        "google_certs": certs_status,
        "cert_count": cert_count,
        "audience_configured": bool(settings.token_audience),
        "allowed_sas_count": len(settings.allowed_sas),
        "single_use_tokens": settings.single_use_tokens,
        "enforce_conv_authz": settings.enforce_conv_authz,
        "clock_skew_seconds": settings.clock_skew_seconds,
        "time": now_iso(),
    }


@router.get("/conversation-status")
async def conversation_status(conversation_id: str = Query(None)):
    """Does this pod hold any WebSocket clients for the conversation?"""
    if not conversation_id or not conversation_id.strip():
        raise HTTPException(status_code=400, detail="Query parameter 'conversation_id' is required.")
    conversation_id = conversation_id.strip()

    clients = manager.client_count(conversation_id)
    return {
        "conversation_id": conversation_id,
        "full_conversation_name": (
            f"projects/{settings.project_id}/locations/{settings.location}"
            f"/conversations/{conversation_id}"
        ),
        "active": clients > 0,
        "connected_clients": clients,
        "timestamp": now_iso(),
    }
