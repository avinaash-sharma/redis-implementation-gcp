"""UI Connector: WebSocket gateway streaming CCAI transcript events from Redis to the Salesforce LWC."""
