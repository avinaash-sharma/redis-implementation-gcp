import asyncio
import hashlib
import json
import logging
import os
import re
import time
import traceback
from datetime import datetime, timezone
from typing import Dict, Optional, Set

import httpx
from fastapi import FastAPI, WebSocket, WebSocketDisconnect, Query, HTTPException
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from google.auth import jwt as google_jwt

# utils.py configures the root logger (level from ENVIRONMENT) on import, so it
# must be imported before anything below logs.
from utils import log_debug, log_info, log_warning, log_error, log_metric


# ─── Logging ──────────────────────────────────────────────────────────────────
# Every line reads "<conversation_id> | ui-connector | <message>"; lines with no
# conversation use "-". The conversation_id also rides along as a structured
# field. ENVIRONMENT=dev shows debug lines (per-message forwarding, channel
# subscribes); sit/uat show info and up; prod shows errors plus the one
# "Session closed" metric line per connection.

SERVICE_TAG = "ui-connector"
_JSON_SAFE = (str, int, float, bool, type(None))


class ConversationLog:
    """Thin wrapper over utils.py that adds the prefix and keeps fields JSON-safe."""

    @staticmethod
    def _emit(fn, conversation_id, message, fields):
        conv = conversation_id or "-"
        # utils json.dumps the fields; anything non-primitive is stringified so
        # a logging call can never raise.
        safe = {k: v if isinstance(v, _JSON_SAFE) else str(v) for k, v in fields.items()}
        fn(f"{conv} | {SERVICE_TAG} | {message}", conversation_id=conv, **safe)

    def debug(self, conversation_id, message, **fields):
        self._emit(log_debug, conversation_id, message, fields)

    def info(self, conversation_id, message, **fields):
        self._emit(log_info, conversation_id, message, fields)

    def warning(self, conversation_id, message, **fields):
        self._emit(log_warning, conversation_id, message, fields)

    def error(self, conversation_id, message, **fields):
        self._emit(log_error, conversation_id, message, fields)

    def exception(self, conversation_id, message, exc, **fields):
        """Error line with the exception and traceback as fields (utils has no exc_info)."""
        fields["error"] = f"{type(exc).__name__}: {exc}"
        fields["traceback"] = "".join(traceback.format_exception(type(exc), exc, exc.__traceback__))
        self._emit(log_error, conversation_id, message, fields)

    def metric(self, conversation_id, message, **fields):
        """Always written, whatever the log level (utils.log_metric)."""
        self._emit(log_metric, conversation_id, message, fields)


log = ConversationLog()


# ─── Log scrubbing ────────────────────────────────────────────────────────────
# The app never logs the token. uvicorn can, though: at --log-level debug its
# websocket layer logs every handshake header ("authorization: Bearer eyJ..."),
# and a client still on the old ?token= URL puts the token in the handshake
# line. This covers ONLY what this process logs, not GCP ILB or F5 XC logs.

_SECRET_PARAM_RE = re.compile(
    r"([?&](?:token|ticket|access_token|id_token)=)([^&\s\"']+)",
    re.IGNORECASE,
)
_BARE_JWT_RE = re.compile(
    r"\beyJ[A-Za-z0-9_\-]{8,}\.[A-Za-z0-9_\-]{8,}\.[A-Za-z0-9_\-]+"
)


def scrub_secrets(text: str) -> str:
    text = _SECRET_PARAM_RE.sub(r"\1REDACTED", text)
    text = _BARE_JWT_RE.sub("REDACTED_JWT", text)
    return text


class SecretScrubbingFilter(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:
        if isinstance(record.msg, str):
            record.msg = scrub_secrets(record.msg)
        if record.args:
            if isinstance(record.args, dict):
                record.args = {
                    k: scrub_secrets(v) if isinstance(v, str) else v
                    for k, v in record.args.items()
                }
            else:
                record.args = tuple(
                    scrub_secrets(a) if isinstance(a, str) else a
                    for a in record.args
                )
        return True


def _install_log_scrubbing() -> None:
    scrubber = SecretScrubbingFilter()
    for name in ("uvicorn.access", "uvicorn.error", "uvicorn", ""):
        logging.getLogger(name).addFilter(scrubber)
    # Logger filters only see records logged directly to that logger; handler
    # filters also catch records propagating up from child loggers.
    for handler in logging.getLogger().handlers:
        handler.addFilter(scrubber)


_install_log_scrubbing()

# utils.py puts the root logger at DEBUG in dev, which also lets through the
# HTTP client's per-request lines and asyncio's internals. Keep those at WARNING.
for _noisy in ("httpx", "httpcore", "asyncio"):
    logging.getLogger(_noisy).setLevel(logging.WARNING)


app = FastAPI(title="UI Connector — WebSocket Gateway")

# CORS — lock down to frontend domain in production
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ─── Config ───────────────────────────────────────────────────────────────────
PROJECT_ID  = os.environ.get("GCP_PROJECT_ID", "adtgcp-ent-dev-ccs-tlcm-fe10")
LOCATION    = os.environ.get("LOCATION", "us-central1")

# Key for the buffered-turns list written by the interpreter.
# Must match conversation_id EXACTLY as the interpreter writes it
# (the short id, e.g. "conv-52e5bf76" — NOT the full resource path).
TURNS_KEY_TEMPLATE = "conversation:{conversation_id}:turns"
META_KEY_TEMPLATE = "conversation:{conversation_id}:meta"

# TTL (seconds) for the server_id lookup key, so a crashed instance doesn't
# leave a stale pointer forever. Refreshed on every connect; cleared on disconnect.
SERVER_ID_KEY_TTL = 3600


# ─── Auth config ──────────────────────────────────────────────────────────────

ALLOWED_SAS = {
    s.strip().lower()
    for s in os.environ.get("ALLOWED_SAS", "").split(",")
    if s.strip()
}
EXPECTED_AUDIENCE = os.environ.get("WS_TOKEN_AUDIENCE", "").strip()
CLOCK_SKEW_SECONDS = int(os.environ.get("WS_TOKEN_CLOCK_SKEW", "10"))
SINGLE_USE_TOKENS = os.environ.get("WS_TOKEN_SINGLE_USE", "false").lower() == "true"
ENFORCE_CONV_AUTHZ = os.environ.get("WS_ENFORCE_CONV_AUTHZ", "false").lower() == "true"

VALID_ISSUERS = ("https://accounts.google.com", "accounts.google.com")
GOOGLE_CERTS_URL = "https://www.googleapis.com/oauth2/v1/certs"

# Namespaced so it cannot collide with join_conversation(), which uses the bare
# conversation_id as a Redis key.
REPLAY_KEY_TEMPLATE = "ws:tok:{fingerprint}"

if not EXPECTED_AUDIENCE:
    log.warning(
        None,
        "WS_TOKEN_AUDIENCE unset: audience validation SKIPPED. An ID token minted by "
        "an allowlisted SA for ANY other GCP endpoint would be accepted. Set this "
        "before this leaves DEV.",
    )
if not ALLOWED_SAS:
    log.warning(None, "ALLOWED_SAS empty: any verified Google identity is accepted.")


# ─── WebSocket Close Codes ────────────────────────────────────────────────────
# Standard RFC 6455 codes used by this service:
#   1000 → Normal closure (client left cleanly)
#   1008 → Policy violation (auth failure)
#   1011 → Internal server error (unexpected failure)
#   1013 → Try again later (Redis/backend unavailable)
WS_CLOSE_NORMAL          = 1000
WS_CLOSE_POLICY_VIOLATION = 1008
WS_CLOSE_INTERNAL_ERROR  = 1011
WS_CLOSE_TRY_AGAIN_LATER = 1013

# RFC 6455 caps the close reason at 123 bytes. Longer strings raise on some
# websocket stacks rather than truncating, so every close reason is sliced.
WS_CLOSE_REASON_MAX = 123


# ─── Server-side Event Types (sent to client) ─────────────────────────────────
# Kept as constants so the frontend contract stays discoverable in one place.
EVENT_HISTORY_BATCH  = "HISTORY_BATCH"
EVENT_ERROR          = "ERROR"
EVENT_STREAM_PAUSED  = "STREAM_PAUSED"
EVENT_STREAM_RESUMED = "STREAM_RESUMED"


# ─── Redis ──────────────────────────────────────────────────────────────────────
import redis.asyncio as aioredis
from redis.exceptions import (
    ConnectionError as RedisConnectionError,
    TimeoutError as RedisTimeoutError,
    RedisError,
)

redis_host = os.environ.get('REDISHOST', '100.72.86.38')
redis_port = int(os.environ.get('REDISPORT', 6379))
redis_client = aioredis.StrictRedis(
    host=redis_host,
    port=redis_port,
    health_check_interval=10,
    socket_connect_timeout=15,
    retry_on_timeout=True,
    socket_keepalive=True,
)


# ─── Google signing certs (cached) ────────────────────────────────────────────
# Fetching these on every handshake would add a Google round trip per
# connection. Cached in-process and honouring the endpoint's own Cache-Control
# max-age. Requires egress to www.googleapis.com — if the pod has no route out,
# EVERY token fails with verification_unavailable, which reads like a token
# problem but is a networking one.

_certs_cache: Dict[str, object] = {"certs": None, "expires_at": 0.0}
_certs_lock = asyncio.Lock()


async def _fetch_google_certs(force: bool = False) -> dict:
    now = time.time()
    if not force and _certs_cache["certs"] and now < _certs_cache["expires_at"]:
        return _certs_cache["certs"]

    async with _certs_lock:
        # Re-check inside the lock — another coroutine may have refreshed while
        # we waited.
        now = time.time()
        if not force and _certs_cache["certs"] and now < _certs_cache["expires_at"]:
            return _certs_cache["certs"]

        async with httpx.AsyncClient(timeout=5.0) as client:
            resp = await client.get(GOOGLE_CERTS_URL)
            resp.raise_for_status()
            certs = resp.json()

        ttl = 3600
        match = re.search(r"max-age=(\d+)", resp.headers.get("cache-control", ""))
        if match:
            ttl = max(int(match.group(1)), 60)

        _certs_cache["certs"] = certs
        _certs_cache["expires_at"] = time.time() + ttl
        log.debug(None, "Fetched Google signing certs", cert_count=len(certs), ttl_s=ttl)
        return certs


# ─── Auth types ───────────────────────────────────────────────────────────────

class AuthFailure(Exception):
    """`reason` is a short, stable string that is safe to send to the client."""

    def __init__(self, reason: str, detail: str = ""):
        self.reason = reason
        self.detail = detail
        super().__init__(f"{reason}: {detail}" if detail else reason)


class Principal:
    """The verified caller behind a websocket connection."""

    __slots__ = ("email", "subject", "expires_at", "fingerprint")

    def __init__(self, email: str, subject: str, expires_at: int, fingerprint: str):
        self.email = email
        self.subject = subject
        self.expires_at = expires_at
        self.fingerprint = fingerprint


def _token_fingerprint(token: str) -> str:
    """Short, non-reversible handle for a token. Safe to log."""
    return hashlib.sha256(token.encode("utf-8")).hexdigest()[:32]


def extract_bearer_token(websocket: WebSocket) -> str:
    """
    Read the token from the handshake's `Authorization: Bearer <token>` header.

    The old ?token= query parameter is no longer accepted; a request that still
    sends it is rejected as missing_token, with a log detail saying why.
    Never echoes the header value into the detail: without a scheme, the whole
    header IS the token.
    """
    header = (websocket.headers.get("authorization") or "").strip()
    if not header:
        detail = (
            "token sent as ?token= query param, which is no longer accepted"
            if "token" in websocket.query_params
            else "no Authorization header"
        )
        raise AuthFailure("missing_token", detail)

    scheme, _, credentials = header.partition(" ")
    if scheme.lower() != "bearer":
        detail = "missing 'Bearer ' prefix" if not credentials else "unsupported auth scheme"
        raise AuthFailure("invalid_auth_scheme", detail)

    token = credentials.strip()
    if not token:
        raise AuthFailure("missing_token", "empty Bearer credentials")
    return token


async def verify_salesforce_token(token: Optional[str]) -> Principal:
    """
    Verify the Google-issued ID token from the Authorization: Bearer header.

    Minted by Apex (GcpTokenService.getIdToken) with audience
    WS_TOKEN_AUDIENCE. Checks signature, issuer, audience, expiry, and the
    ALLOWED_SAS allowlist.

    Returns a Principal. RAISES AuthFailure on every rejection path — it does
    NOT return a bool. A Principal is always truthy, so a caller written as
    `if not await verify_salesforce_token(...)` would silently accept
    everything.
    """
    if not token or not token.strip():
        raise AuthFailure("missing_token")

    token = token.strip()

    # Cheap structural gate before spending CPU on RSA verification.
    if token.count(".") != 2 or len(token) > 8192:
        raise AuthFailure("malformed_token", f"len={len(token)}")

    fp = _token_fingerprint(token)

    try:
        certs = await _fetch_google_certs()
    except Exception as exc:
        raise AuthFailure("verification_unavailable", f"cert fetch failed: {exc}") from exc

    def _decode(c):
        return google_jwt.decode(
            token,
            certs=c,
            audience=EXPECTED_AUDIENCE or None,
            clock_skew_in_seconds=CLOCK_SKEW_SECONDS,
        )

    try:
        claims = await asyncio.get_event_loop().run_in_executor(None, _decode, certs)
    except ValueError as exc:
        msg = str(exc).lower()
        if "expired" in msg:
            raise AuthFailure("token_expired", str(exc)) from exc
        if "audience" in msg:
            raise AuthFailure("bad_audience", str(exc)) from exc
        # Could be genuine tampering, or Google rotated its signing keys and our
        # cache is stale. Refetch once and retry before rejecting.
        try:
            certs = await _fetch_google_certs(force=True)
            claims = await asyncio.get_event_loop().run_in_executor(
                None, _decode, certs
            )
        except ValueError as exc2:
            raise AuthFailure("invalid_token", str(exc2)) from exc2
        except Exception as exc2:
            raise AuthFailure("verification_unavailable", f"cert refresh failed: {exc2}") from exc2
    except Exception as exc:
        log.exception(None, "Unexpected token verification failure", exc, fp=fp)
        raise AuthFailure("verification_unavailable", str(exc)) from exc

    if claims.get("iss") not in VALID_ISSUERS:
        raise AuthFailure("invalid_issuer", str(claims.get("iss")))

    email = (claims.get("email") or "").lower()
    if not email:
        raise AuthFailure("no_email_claim")
    if not claims.get("email_verified", False):
        raise AuthFailure("email_unverified", email)
    if ALLOWED_SAS and email not in ALLOWED_SAS:
        raise AuthFailure("caller_not_allowed", email)

    exp = int(claims.get("exp", 0))

    # ─── Replay guard ─────────────────────────────────────────────────────────
    # Google ID tokens live ~1h and are not single-use by nature. Burning the
    # hash on first use collapses a leaked token's replay window to zero.
    #
    # HARD PREREQUISITE: Apex must mint a fresh token per connection attempt. If
    # GcpTokenService caches for the hour, the first connect works and every
    # reconnect dies with token_replayed. Confirm before enabling.
    if SINGLE_USE_TOKENS:
        ttl = max(exp - int(time.time()), 1)
        key = REPLAY_KEY_TEMPLATE.format(fingerprint=fp)
        try:
            first_use = await redis_client.set(key, "1", ex=ttl, nx=True)
        except Exception as exc:
            # Fail OPEN — a Memorystore blip should not black out the agent
            # desktop. Change to `raise` if policy requires fail-closed.
            log.warning(None, "Replay guard skipped, Redis unavailable (allowing)", fp=fp, error=exc)
            first_use = True
        if not first_use:
            raise AuthFailure("token_replayed", email)

    return Principal(
        email=email,
        subject=claims.get("sub", ""),
        expires_at=exp,
        fingerprint=fp,
    )


async def authorize_conversation(principal: Principal, conversation_id: str) -> None:
    """
    Authentication proves the connection came from Salesforce. It does NOT prove
    this agent is entitled to THIS conversation's transcript. Without a check
    here, any authenticated client can subscribe to any live conversation_id.

    WARN-ONLY unless WS_ENFORCE_CONV_AUTHZ=true, because the meta key may not
    exist yet for a conversation that has only just started — enforcing
    immediately would drop legitimate early connects. Run warn-only first, watch
    for the "would REJECT" lines, confirm the interpreter always writes meta
    before the LWC connects, then enforce.
    """
    key = META_KEY_TEMPLATE.format(conversation_id=conversation_id)
    try:
        exists = await redis_client.exists(key)
    except Exception as exc:
        log.warning(conversation_id, "Authz check skipped, Redis unavailable (allowing)", error=exc)
        return

    if exists:
        return

    if ENFORCE_CONV_AUTHZ:
        raise AuthFailure("conversation_not_authorized", conversation_id)

    log.warning(
        conversation_id,
        "Authz would REJECT (warn-only): meta key missing",
        caller=principal.email,
        missing_key=key,
    )


# ─── Cloud Run / GKE instance identity ───────────────────────────────────────────────
METADATA_INSTANCE_ID_URL = (
    "http://metadata.google.internal/computeMetadata/v1/instance/id"
)
_cached_instance_id: str = None


async def get_server_id() -> str:
    """
    Returns a stable identifier for THIS running container instance.

    TEMPORARILY HARDCODED for isolation testing — bypasses the metadata
    server call entirely so we can confirm join/HISTORY_BATCH logic works
    independently of instance-id resolution. Re-enable the real lookup
    (commented below) once confirmed.
    """
    return "1"

    # ── Real implementation (re-enable once isolation test passes) ──────────
    # global _cached_instance_id
    # if _cached_instance_id:
    #     return _cached_instance_id
    #
    # try:
    #     async with httpx.AsyncClient(timeout=2.0) as client:
    #         resp = await client.get(
    #             METADATA_INSTANCE_ID_URL,
    #             headers={"Metadata-Flavor": "Google"},
    #         )
    #         resp.raise_for_status()
    #         _cached_instance_id = resp.text.strip()
    #         log.info(None, "Resolved instance id", instance_id=_cached_instance_id)
    # except Exception as e:
    #     import uuid
    #     _cached_instance_id = f"local-{uuid.uuid4().hex[:8]}"
    #     log.warning(None, "Metadata server unreachable, using fallback instance id",
    #                 instance_id=_cached_instance_id, error=e)
    #
    # return _cached_instance_id


# ─── Error helper ─────────────────────────────────────────────────────────────
async def send_error(
    websocket: WebSocket,
    code: str,
    message: str,
    conversation_id: str = None,
    recoverable: bool = True,
):
    """
    Send a structured ERROR event to the client. Never raises — if the socket
    is already gone, we just log it. This lets callers report a failure
    without needing to guard every send site.
    """
    payload = {
        "type": EVENT_ERROR,
        "code": code,
        "message": message,
        "conversationId": conversation_id,
        "recoverable": recoverable,
        "timestamp": now_iso(),
    }
    try:
        await websocket.send_json(payload)
    except Exception as e:
        log.debug(conversation_id, "ERROR event not delivered, socket gone", code=code, error=e)


async def reject_connection(
    websocket: WebSocket,
    reason: str,
    close_code: int = WS_CLOSE_POLICY_VIOLATION,
):
    """
    Close a connection that failed auth or authz.

    Accept-then-close is deliberate: it lets the client read event.code and
    event.reason in onclose. Closing before accept surfaces in the browser as a
    bare 1006 with an empty reason, which is very hard to debug with F5 XC in
    the path. No payload data is ever sent before this close, so the security
    posture is identical either way.
    """
    try:
        await websocket.accept()
        await websocket.close(code=close_code, reason=reason[:WS_CLOSE_REASON_MAX])
    except Exception as e:
        log.debug(None, "Could not cleanly reject connection", reason=reason, error=e)


async def redis_listener(conversation_id: str, websocket: WebSocket, stats: dict):
    """
    Listens on Redis channel for a conversation and forwards all messages to
    the connected WebSocket client. Channel format: {server_id}:{conversation_id}
    """
    server_id = await get_server_id()
    channel = f'{server_id}:{conversation_id}'

    MAX_RECONNECT_ATTEMPTS = 5
    RECONNECT_BACKOFF_SECONDS = 2
    attempt = 0

    while attempt <= MAX_RECONNECT_ATTEMPTS:
        pubsub = redis_client.pubsub()
        try:
            await pubsub.subscribe(channel)
            log.debug(conversation_id, "Subscribed to Redis channel", channel=channel, attempt=attempt)

            if attempt > 0:
                log.info(conversation_id, "Live stream resumed", after_attempts=attempt)
                await send_error(
                    websocket,
                    code="STREAM_RESUMED",
                    message="Live stream resumed.",
                    conversation_id=conversation_id,
                    recoverable=True,
                )

            attempt = 0  # reset once a successful subscribe holds

            async for message in pubsub.listen():
                if message.get('type') != 'message':
                    continue
                try:
                    data = json.loads(message['data'])
                except (json.JSONDecodeError, TypeError) as e:
                    stats["dropped"] += 1
                    log.warning(conversation_id, "Dropped malformed pub/sub message", channel=channel, error=e)
                    continue

                try:
                    await websocket.send_json(data)
                    stats["forwarded"] += 1
                    log.debug(conversation_id, "Forwarded Redis message to socket", channel=channel)
                except WebSocketDisconnect:
                    log.debug(conversation_id, "Client gone while forwarding")
                    return
                except Exception as e:
                    log.warning(conversation_id, "Failed to forward message to client", error=e)
                    return

        except (RedisConnectionError, RedisTimeoutError) as e:
            attempt += 1
            log.warning(
                conversation_id, "Redis connection lost, retrying",
                channel=channel, attempt=attempt, max_attempts=MAX_RECONNECT_ATTEMPTS, error=e,
            )
            await send_error(
                websocket,
                code="STREAM_PAUSED",
                message=(
                    "Live stream temporarily paused — reconnecting to backend."
                ),
                conversation_id=conversation_id,
                recoverable=True,
            )
            if attempt > MAX_RECONNECT_ATTEMPTS:
                log.error(conversation_id, "Live stream could not be restored", channel=channel)
                await send_error(
                    websocket,
                    code="STREAM_UNAVAILABLE",
                    message=(
                        "Live stream could not be restored. "
                        "Please refresh to reconnect."
                    ),
                    conversation_id=conversation_id,
                    recoverable=False,
                )
                return
            await asyncio.sleep(RECONNECT_BACKOFF_SECONDS * attempt)

        except asyncio.CancelledError:
            raise

        except Exception as e:
            log.exception(conversation_id, "Unexpected Redis listener error", e, channel=channel)
            await send_error(
                websocket,
                code="STREAM_ERROR",
                message="An unexpected error stopped the live stream.",
                conversation_id=conversation_id,
                recoverable=False,
            )
            return

        finally:
            try:
                await pubsub.unsubscribe(channel)
                await pubsub.close()
            except Exception as e:
                log.debug(conversation_id, "pub/sub cleanup failed", channel=channel, error=e)


async def close_at_token_expiry(
    websocket: WebSocket,
    principal: Principal,
    conversation_id: str,
):
    """
    Bind the socket's lifetime to the credential that opened it.

    BackendConfig timeoutSec is 3600 and a Google ID token also lives ~3600s,
    so without this a connection can outlive its token. The client sees a 1008
    with reason "token_expired" and should mint a fresh token and reconnect.
    """
    delay = max(principal.expires_at - int(time.time()), 0)
    await asyncio.sleep(delay)
    try:
        await websocket.close(
            code=WS_CLOSE_POLICY_VIOLATION,
            reason="token_expired",
        )
        log.info(conversation_id, "Closed socket on token expiry", caller=principal.email)
    except Exception as e:
        log.debug(conversation_id, "Token-expiry close failed", error=e)


# ─── Helpers ──────────────────────────────────────────────────────────────────

def build_conversation_name(conversation_id: str) -> str:
    return f"projects/{PROJECT_ID}/locations/{LOCATION}/conversations/{conversation_id}"

def build_participant_name(conversation_id: str, participant_id: str) -> str:
    return f"projects/{PROJECT_ID}/locations/{LOCATION}/conversations/{conversation_id}/participants/{participant_id}"

def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


# ─── Join / Leave conversation (Redis bookkeeping) ────────────────────────────

class JoinError(Exception):
    def __init__(self, code: str, message: str, recoverable: bool = False):
        super().__init__(message)
        self.code = code
        self.message = message
        self.recoverable = recoverable


async def join_conversation(conversation_id: str) -> list:
    server_id = await get_server_id()

    try:
        await redis_client.set(conversation_id, server_id, ex=SERVER_ID_KEY_TTL)
        log.debug(conversation_id, "Registered server pointer", server_id=server_id)
    except (RedisConnectionError, RedisTimeoutError) as e:
        log.error(conversation_id, "Redis unreachable while registering server pointer", error=e)
        raise JoinError(
            code="REDIS_UNAVAILABLE",
            message="Cannot reach live stream backend. Please try again shortly.",
            recoverable=True,
        )
    except RedisError as e:
        log.error(conversation_id, "Redis error while registering server pointer", error=e)
        raise JoinError(
            code="REDIS_ERROR",
            message="Backend error while joining the conversation.",
            recoverable=True,
        )

    turns_key = TURNS_KEY_TEMPLATE.format(conversation_id=conversation_id)
    try:
        raw_turns = await redis_client.lrange(turns_key, 0, -1)
    except (RedisConnectionError, RedisTimeoutError) as e:
        log.error(conversation_id, "Redis unreachable while loading history", error=e)
        raise JoinError(
            code="HISTORY_UNAVAILABLE",
            message=(
                "Connected, but couldn't load prior transcript. "
                "Live turns will still stream."
            ),
            recoverable=True,
        )
    except RedisError as e:
        log.error(conversation_id, "Redis error while loading history", error=e)
        raise JoinError(
            code="HISTORY_ERROR",
            message="Backend error while loading prior transcript.",
            recoverable=True,
        )

    turns = []
    skipped = 0
    for raw in raw_turns:
        try:
            turns.append(json.loads(raw))
        except (json.JSONDecodeError, TypeError):
            skipped += 1

    if skipped:
        log.warning(conversation_id, "Skipped malformed buffered turns", skipped=skipped, loaded=len(turns))

    return turns


async def leave_conversation(conversation_id: str):
    try:
        await redis_client.delete(conversation_id)
        log.debug(conversation_id, "Cleared server pointer")
    except Exception as e:
        log.warning(conversation_id, "Could not clear server pointer (TTL will clean up)", error=e)


# ─── CCAI Production Payload Builders ─────────────────────────────────────────

def build_conversation_lifecycle_payload(conversation_id: str, event_type: str) -> dict:
    return {
        "conversation": build_conversation_name(conversation_id),
        "type": event_type,
    }


def build_new_recognition_result_payload(
    conversation_id: str,
    participant_id: str,
    participant_role: str,
    transcript: str,
    is_final: bool,
    confidence: float,
    message_id: str,
) -> dict:
    return {
        "conversation": build_conversation_name(conversation_id),
        "participant": build_participant_name(conversation_id, participant_id),
        "participantRole": participant_role,
        "newRecognitionResult": {
            "messageId": message_id,
            "transcript": transcript,
            "isFinal": is_final,
            "confidence": confidence,
            "languageCode": "en-US",
            "speechWordInfo": [],
        },
    }


def build_new_message_payload(
    conversation_id: str,
    participant_id: str,
    participant_role: str,
    message_id: str,
    content: str,
) -> dict:
    return {
        "conversation": build_conversation_name(conversation_id),
        "newMessagePayload": {
            "name": f"projects/{PROJECT_ID}/locations/{LOCATION}/conversations/{conversation_id}/messages/{message_id}",
            "content": content,
            "languageCode": "en-US",
            "participant": build_participant_name(conversation_id, participant_id),
            "participantRole": participant_role,
            "createTime": now_iso(),
        },
    }


def build_agent_assist_payload(
    conversation_id: str,
    participant_id: str,
    suggestions: list,
) -> dict:
    return {
        "conversation": build_conversation_name(conversation_id),
        "participant": build_participant_name(conversation_id, participant_id),
        "humanAgentAssistantEvent": {
            "suggestionResults": [
                {
                    "suggestArticlesResponse": {
                        "articleAnswers": [
                            {
                                "title": s["title"],
                                "uri": s["uri"],
                                "snippets": [s["snippet"]],
                                "confidence": s["confidence"],
                            }
                            for s in suggestions
                        ]
                    }
                }
            ]
        },
    }


# ─── Connection Manager ────────────────────────────────────────────────────────

class ConnectionManager:
    def __init__(self):
        self.active: Dict[str, Set[WebSocket]] = {}

    async def connect(self, conversation_id: str, websocket: WebSocket):
        await websocket.accept()
        if conversation_id not in self.active:
            self.active[conversation_id] = set()
        self.active[conversation_id].add(websocket)

    def disconnect(self, conversation_id: str, websocket: WebSocket):
        if conversation_id in self.active:
            self.active[conversation_id].discard(websocket)
            if not self.active[conversation_id]:
                del self.active[conversation_id]

    async def broadcast(self, conversation_id: str, message: dict):
        if conversation_id not in self.active:
            return
        dead = set()
        for ws in self.active[conversation_id]:
            try:
                await ws.send_json(message)
            except WebSocketDisconnect:
                dead.add(ws)
            except Exception as e:
                log.warning(conversation_id, "Broadcast send failed", error=e)
                dead.add(ws)
        for ws in dead:
            self.active[conversation_id].discard(ws)

    def is_active(self, conversation_id: str) -> bool:
        return conversation_id in self.active and len(self.active[conversation_id]) > 0

    def client_count(self, conversation_id: str) -> int:
        return len(self.active.get(conversation_id, ()))


manager = ConnectionManager()


# ─── Health ────────────────────────────────────────────────────────────────────

@app.get("/")
async def health():
    """
    Health endpoint reports Redis reachability so upstream monitoring can
    distinguish 'service up but backend down' from 'service down'.
    """
    redis_status = "unknown"
    try:
        pong = await redis_client.ping()
        redis_status = "connected" if pong else "no-response"
    except (RedisConnectionError, RedisTimeoutError) as e:
        redis_status = f"unreachable: {e}"
    except Exception as e:
        redis_status = f"error: {e}"

    return JSONResponse({
        "status": "ui-connector running",
        "redis": redis_status,
        "active_conversations": list(manager.active.keys()),
        "time": now_iso(),
    })


@app.get("/auth-health")
async def auth_health():
    """
    Reports whether the pod can actually reach Google's signing certs, and what
    auth config is live. Use this to separate 'token is bad' from 'pod has no
    egress' without reading logs.

    Deliberately reports config presence, never config values.
    """
    certs_status = "unknown"
    cert_count = 0
    try:
        certs = await _fetch_google_certs()
        cert_count = len(certs)
        certs_status = "reachable"
    except Exception as e:
        certs_status = f"unreachable: {e}"

    return JSONResponse({
        "google_certs": certs_status,
        "cert_count": cert_count,
        "audience_configured": bool(EXPECTED_AUDIENCE),
        "allowed_sas_count": len(ALLOWED_SAS),
        "single_use_tokens": SINGLE_USE_TOKENS,
        "enforce_conv_authz": ENFORCE_CONV_AUTHZ,
        "clock_skew_seconds": CLOCK_SKEW_SECONDS,
        "time": now_iso(),
    })


# ─── WebSocket ─────────────────────────────────────────────────────────────────

@app.websocket("/ws")
async def websocket_endpoint(
    websocket: WebSocket,
    conversation_id: str = Query(None, description="CCAI Conversation ID"),
):
    """
    Frontend connects here to receive live transcript events.
    URL:    wss://dev.agentassist.adt.com/ws?conversation_id=<id>
    Header: Authorization: Bearer <google-id-token>
    """
    peer = websocket.client.host if websocket.client else "unknown"
    conv_for_log = (conversation_id or "").strip() or None

    # ── 1. Authenticate BEFORE establishing any routing ──────────────────────
    try:
        token = extract_bearer_token(websocket)
        principal = await verify_salesforce_token(token)
    except AuthFailure as af:
        # verification_unavailable is our outage (cert fetch / egress), not a
        # bad client, so it is an error and still shows at ENVIRONMENT=prod.
        emit = log.error if af.reason == "verification_unavailable" else log.warning
        emit(conv_for_log, f"Rejected: {af.reason}", peer=peer, detail=af.detail)
        await reject_connection(websocket, af.reason)
        return

    # ── 2. Validate Conversation ID ──────────────────────────────────────────
    if not conversation_id or not conversation_id.strip():
        log.warning(None, "Rejected: missing conversation_id", caller=principal.email, peer=peer)
        await websocket.accept()
        await send_error(
            websocket,
            code="MISSING_CONVERSATION_ID",
            message="Query parameter 'conversation_id' is required.",
            conversation_id=None,
            recoverable=False,
        )
        await websocket.close(
            code=WS_CLOSE_POLICY_VIOLATION,
            reason="Missing conversation_id",
        )
        return

    conversation_id = conversation_id.strip()

    # ── 2b. Authorize this caller for THIS conversation ──────────────────────
    try:
        await authorize_conversation(principal, conversation_id)
    except AuthFailure as af:
        log.warning(conversation_id, f"Rejected: {af.reason}", caller=principal.email)
        await reject_connection(websocket, af.reason)
        return

    # ── 3. Accept and establish connection ───────────────────────────────────
    await manager.connect(conversation_id, websocket)
    stream_task: asyncio.Task = None
    expiry_task: asyncio.Task = None
    started = time.monotonic()
    stats = {"forwarded": 0, "dropped": 0, "received": 0}
    close_code = None

    try:
        # ── join-conversation: register server_id + replay buffered history ──
        try:
            buffered_turns = await join_conversation(conversation_id)
        except JoinError as je:
            await send_error(
                websocket,
                code=je.code,
                message=je.message,
                conversation_id=conversation_id,
                recoverable=je.recoverable,
            )
            await websocket.close(
                code=WS_CLOSE_TRY_AGAIN_LATER,
                reason=je.code,
            )
            return
        except Exception as e:
            log.exception(conversation_id, "Unexpected error during join", e)
            await send_error(
                websocket,
                code="INTERNAL_ERROR",
                message="Unexpected error while joining the conversation.",
                conversation_id=conversation_id,
                recoverable=False,
            )
            await websocket.close(
                code=WS_CLOSE_INTERNAL_ERROR,
                reason="Join failed",
            )
            return

        # ── Send history batch ──
        try:
            await websocket.send_json({
                "type": EVENT_HISTORY_BATCH,
                "conversationId": conversation_id,
                "turns": buffered_turns,
                "totalTurns": len(buffered_turns),
                "timestamp": now_iso(),
            })
        except WebSocketDisconnect:
            log.debug(conversation_id, "Client disconnected before HISTORY_BATCH")
            return

        log.info(
            conversation_id, "Connected",
            caller=principal.email,
            fp=principal.fingerprint,
            clients=manager.client_count(conversation_id),
            history_turns=len(buffered_turns),
            token_ttl_s=principal.expires_at - int(time.time()),
        )

        # ── live stream: forward future Redis-published turns over this socket ──
        stream_task = asyncio.create_task(redis_listener(conversation_id, websocket, stats))

        # ── close the socket when the token that opened it expires ──
        expiry_task = asyncio.create_task(
            close_at_token_expiry(websocket, principal, conversation_id)
        )

        # ── main receive loop: keep the socket alive; content is never logged ─
        while True:
            try:
                data = await websocket.receive_text()
                stats["received"] += 1
                log.debug(conversation_id, "Client message received", size=len(data))
            except WebSocketDisconnect as wd:
                close_code = wd.code
                break

    except Exception as e:
        log.exception(conversation_id, "Unhandled WS error", e)
        await send_error(
            websocket,
            code="INTERNAL_ERROR",
            message="An unexpected error occurred.",
            conversation_id=conversation_id,
            recoverable=False,
        )
        try:
            await websocket.close(
                code=WS_CLOSE_INTERNAL_ERROR,
                reason="Internal error",
            )
        except Exception:
            pass

    finally:
        for task in (stream_task, expiry_task):
            if task and not task.done():
                task.cancel()
                try:
                    await task
                except (asyncio.CancelledError, Exception):
                    pass

        manager.disconnect(conversation_id, websocket)

        # One line per connection, written at every log level (incl. prod).
        log.metric(
            conversation_id, "Session closed",
            caller=principal.email,
            duration_s=round(time.monotonic() - started, 1),
            forwarded=stats["forwarded"],
            dropped=stats["dropped"],
            received=stats["received"],
            close_code=close_code,
        )

        if not manager.is_active(conversation_id):
            await leave_conversation(conversation_id)


# ─── Conversation Status ───────────────────────────────────────────────────────

@app.get("/conversation-status")
async def conversation_status(conversation_id: str = Query(None)):
    """Check if a conversation has active WebSocket clients."""
    if not conversation_id or not conversation_id.strip():
        raise HTTPException(
            status_code=400,
            detail="Query parameter 'conversation_id' is required.",
        )

    return JSONResponse({
        "conversation_id": conversation_id,
        "full_conversation_name": build_conversation_name(conversation_id),
        "active": manager.is_active(conversation_id),
        "connected_clients": len(manager.active.get(conversation_id, set())),
        "timestamp": now_iso(),
    })
