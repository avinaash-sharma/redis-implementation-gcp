import asyncio
import json
import logging
import os
from datetime import datetime, timezone
from typing import Dict, Set

import httpx
from fastapi import FastAPI, WebSocket, WebSocketDisconnect, Query, HTTPException
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware

# ─── Logging ──────────────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s",
)
logger = logging.getLogger("adt-ui-connector")

app = FastAPI(title="UI Connector — WebSocket Gateway")

# CORS — lock down to frontend domain in production
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ─── Config ───────────────────────────────────────────────────────────────────
PROJECT_ID  = os.environ.get("GCP_PROJECT_ID", "adtgcp-ent-dev-ccs-tlcm-fe10")
LOCATION    = os.environ.get("LOCATION", "us-central1")

# Auth toggle. When "true", every WS connection must carry a valid
# access_token query param. When "false", token is ignored entirely
# (dev / isolation testing). Surfaced in / health so the deployed
# state is always verifiable.
AUTH_ENABLED = os.environ.get("AUTH_ENABLED", "true").lower() == "true"

# Optional: pin the expected audience ('aud' claim) of incoming tokens.
# Unset → signature + expiry + issuer are checked, audience is NOT.
# NOTE: once set, plain `gcloud auth print-identity-token` output will be
# rejected (audience mismatch) — mint test tokens with
# `gcloud auth print-identity-token --audiences=<value>` instead.
# Name must match the env var in deployment.yaml: WS_TOKEN_AUDIENCE.
WS_TOKEN_AUDIENCE = os.environ.get("WS_TOKEN_AUDIENCE") or None

# Key for the buffered-turns list written by the interpreter.
# Must match conversation_id EXACTLY as the interpreter writes it
# (the short id, e.g. "conv-52e5bf76" — NOT the full resource path).
TURNS_KEY_TEMPLATE = "conversation:{conversation_id}:turns"
META_KEY_TEMPLATE = "conversation:{conversation_id}:meta"

# TTL (seconds) for the server_id lookup key, so a crashed instance doesn't
# leave a stale pointer forever. Refreshed on every connect; cleared on disconnect.
SERVER_ID_KEY_TTL = 3600


# ─── WebSocket Close Codes ────────────────────────────────────────────────────
# Standard RFC 6455 codes used by this service:
#   1000 → Normal closure (client left cleanly)
#   1008 → Policy violation (auth failure)
#   1011 → Internal server error (unexpected failure)
#   1013 → Try again later (Redis/backend unavailable)
WS_CLOSE_NORMAL          = 1000
WS_CLOSE_POLICY_VIOLATION = 1008
WS_CLOSE_INTERNAL_ERROR  = 1011
WS_CLOSE_TRY_AGAIN_LATER = 1013


# ─── Server-side Event Types (sent to client) ─────────────────────────────────
# Kept as constants so the frontend contract stays discoverable in one place.
EVENT_HISTORY_BATCH  = "HISTORY_BATCH"
EVENT_ERROR          = "ERROR"
EVENT_STREAM_PAUSED  = "STREAM_PAUSED"
EVENT_STREAM_RESUMED = "STREAM_RESUMED"


# ─── Redis ──────────────────────────────────────────────────────────────────────
import redis.asyncio as aioredis
from redis.exceptions import (
    ConnectionError as RedisConnectionError,
    TimeoutError as RedisTimeoutError,
    RedisError,
)

redis_host = os.environ.get('REDISHOST', '100.72.86.38')
redis_port = int(os.environ.get('REDISPORT', 6379))
redis_client = aioredis.StrictRedis(
    host=redis_host,
    port=redis_port,
    health_check_interval=10,
    socket_connect_timeout=15,
    retry_on_timeout=True,
    socket_keepalive=True,
)


# ─── Instance identity (GKE pod / Cloud Run instance / local) ─────────────────
METADATA_INSTANCE_ID_URL = (
    "http://metadata.google.internal/computeMetadata/v1/instance/id"
)
_cached_instance_id: str = None


async def get_server_id() -> str:
    """
    Returns a unique identifier for this instance, used for Redis pub/sub
    routing. Resolution order:
      1. POD_NAME env var  → GKE (injected via downward API in deployment.yaml)
      2. Metadata server   → Cloud Run fallback (instance id)
      3. Static fallback   → local / standalone runs
    The interpreter reads this value from the conversation_id key and
    publishes to '{server_id}:{conversation_id}', so the format only needs
    to be stable per instance, not predictable.
    """
    global _cached_instance_id
    if _cached_instance_id:
        return _cached_instance_id

    # 1. GKE: POD_NAME via downward API
    _cached_instance_id = os.environ.get("POD_NAME")
    if _cached_instance_id:
        logger.info(f"Using POD_NAME as server_id: {_cached_instance_id}")
        return _cached_instance_id

    # 2. Cloud Run: metadata server instance id
    try:
        async with httpx.AsyncClient(timeout=1.0) as client:
            resp = await client.get(
                METADATA_INSTANCE_ID_URL,
                headers={"Metadata-Flavor": "Google"},
            )
            resp.raise_for_status()
            _cached_instance_id = resp.text.strip()
            logger.info(f"Using metadata instance id as server_id: {_cached_instance_id}")
            return _cached_instance_id
    except Exception:
        pass

    # 3. Local / standalone
    _cached_instance_id = "ui-connector-standalone"
    logger.warning(f"Using fallback server_id: {_cached_instance_id}")
    return _cached_instance_id


# ─── Error helper ─────────────────────────────────────────────────────────────
async def send_error(
    websocket: WebSocket,
    code: str,
    message: str,
    conversation_id: str = None,
    recoverable: bool = True,
):
    """
    Send a structured ERROR event to the client. Never raises — if the socket
    is already gone, we just log it. This lets callers report a failure
    without needing to guard every send site.

    Payload shape:
        {
          "type": "ERROR",
          "code": "REDIS_UNAVAILABLE",
          "message": "Live stream temporarily unavailable — retrying.",
          "conversationId": "conv-52e5bf76",
          "recoverable": true,
          "timestamp": "2026-07-02T..."
        }
    """
    payload = {
        "type": EVENT_ERROR,
        "code": code,
        "message": message,
        "conversationId": conversation_id,
        "recoverable": recoverable,
        "timestamp": now_iso(),
    }
    try:
        await websocket.send_json(payload)
    except Exception as e:
        logger.warning(f"Could not deliver ERROR ({code}) to client: {e}")


async def redis_listener(conversation_id: str, websocket: WebSocket):
    """
    Listens on Redis channel for a conversation and forwards all messages to
    the connected WebSocket client. Channel format: {server_id}:{conversation_id}

    Handles three failure modes distinctly:
      - Connection drops mid-listen → notify client, attempt reconnect (bounded).
      - Malformed JSON on the channel → skip that message, keep the stream alive.
      - Anything else unexpected → notify client, exit cleanly.
    """
    server_id = await get_server_id()
    channel = f'{server_id}:{conversation_id}'

    MAX_RECONNECT_ATTEMPTS = 5
    RECONNECT_BACKOFF_SECONDS = 2
    attempt = 0

    while attempt <= MAX_RECONNECT_ATTEMPTS:
        pubsub = redis_client.pubsub()
        try:
            await pubsub.subscribe(channel)
            logger.info(f"Redis subscribed → channel: {channel} (attempt {attempt})")

            if attempt > 0:
                await send_error(
                    websocket,
                    code="STREAM_RESUMED",
                    message="Live stream resumed.",
                    conversation_id=conversation_id,
                    recoverable=True,
                )

            attempt = 0  # reset once a successful subscribe holds

            async for message in pubsub.listen():
                if message.get('type') != 'message':
                    continue
                try:
                    data = json.loads(message['data'])
                except (json.JSONDecodeError, TypeError) as e:
                    logger.warning(
                        f"Dropping malformed pub/sub message on {channel}: {e}"
                    )
                    continue

                try:
                    await websocket.send_json(data)
                    logger.info(f"Redis → WS | conv: {conversation_id}")
                except WebSocketDisconnect:
                    logger.info(
                        f"Client gone while forwarding | conv: {conversation_id}"
                    )
                    return
                except Exception as e:
                    logger.error(
                        f"Failed to forward message to client "
                        f"| conv: {conversation_id} | err: {e}"
                    )
                    return

        except (RedisConnectionError, RedisTimeoutError) as e:
            attempt += 1
            logger.error(
                f"Redis connection lost on {channel} "
                f"(attempt {attempt}/{MAX_RECONNECT_ATTEMPTS}): {e}"
            )
            await send_error(
                websocket,
                code="STREAM_PAUSED",
                message=(
                    "Live stream temporarily paused — reconnecting to backend."
                ),
                conversation_id=conversation_id,
                recoverable=True,
            )
            if attempt > MAX_RECONNECT_ATTEMPTS:
                await send_error(
                    websocket,
                    code="STREAM_UNAVAILABLE",
                    message=(
                        "Live stream could not be restored. "
                        "Please refresh to reconnect."
                    ),
                    conversation_id=conversation_id,
                    recoverable=False,
                )
                return
            await asyncio.sleep(RECONNECT_BACKOFF_SECONDS * attempt)

        except asyncio.CancelledError:
            logger.info(f"Redis listener cancelled | conv: {conversation_id}")
            raise

        except Exception as e:
            logger.exception(
                f"Unexpected Redis listener error | conv: {conversation_id}: {e}"
            )
            await send_error(
                websocket,
                code="STREAM_ERROR",
                message="An unexpected error stopped the live stream.",
                conversation_id=conversation_id,
                recoverable=False,
            )
            return

        finally:
            try:
                await pubsub.unsubscribe(channel)
                await pubsub.close()
            except Exception as e:
                logger.warning(f"pubsub cleanup on {channel} failed: {e}")


# ─── Auth (query-param access_token) ──────────────────────────────────────────
# Browser WebSocket clients (Salesforce LWC) cannot set custom headers, so the
# token arrives as a query parameter:
#     wss://<host>/ws?conversation_id=<id>&access_token=<token>
#
# verify_access_token() runs BEFORE the socket joins a conversation. The
# Google verification call is blocking (it fetches signing certs over HTTP
# on cache miss), so it's pushed to a thread to avoid stalling the event
# loop — a stall here would freeze forwarding on EVERY active socket.

from google.auth.transport import requests as grequests
from google.oauth2 import id_token


def _verify_token_sync(token: str) -> bool:
    try:
        # verify_token validates a Google-signed identity token:
        # signature, expiry, and issuer. Audience checked only when
        # WS_TOKEN_AUDIENCE is configured.
        id_info = id_token.verify_token(
            token,
            grequests.Request(),
            audience=WS_TOKEN_AUDIENCE,
        )
        logger.info(
            f"Token verified for: {id_info.get('email') or id_info.get('sub')}"
        )
        return True
    except Exception as e:
        logger.warning(f"Token verification failed: {e}")
        return False


async def verify_access_token(token: str) -> bool:
    if not AUTH_ENABLED:
        return True
    if not token or not token.strip():
        return False
    return await asyncio.to_thread(_verify_token_sync, token)


# ─── Helpers ──────────────────────────────────────────────────────────────────

def build_conversation_name(conversation_id: str) -> str:
    return f"projects/{PROJECT_ID}/locations/{LOCATION}/conversations/{conversation_id}"

def build_participant_name(conversation_id: str, participant_id: str) -> str:
    return f"projects/{PROJECT_ID}/locations/{LOCATION}/conversations/{conversation_id}/participants/{participant_id}"

def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


# ─── Join / Leave conversation (Redis bookkeeping) ────────────────────────────

class JoinError(Exception):
    """Raised when join_conversation cannot complete. Carries a client-safe
    error code and message so the WS handler can report it uniformly."""

    def __init__(self, code: str, message: str, recoverable: bool = False):
        super().__init__(message)
        self.code = code
        self.message = message
        self.recoverable = recoverable


async def join_conversation(conversation_id: str) -> list:
    """
    Called when a client connects to a conversation:
      1. Writes conversation_id -> server_id so the interpreter can route live turns here.
      2. Reads back any turns buffered before this join (for HISTORY_BATCH).

    Raises JoinError on unrecoverable Redis failures so the WS handler can
    close the socket with a meaningful reason.
    """
    server_id = await get_server_id()

    try:
        await redis_client.set(conversation_id, server_id, ex=SERVER_ID_KEY_TTL)
        logger.info(f"Registered server_id for conv: {conversation_id} -> {server_id}")
    except (RedisConnectionError, RedisTimeoutError) as e:
        logger.error(f"Redis unreachable while registering server_id: {e}")
        raise JoinError(
            code="REDIS_UNAVAILABLE",
            message="Cannot reach live stream backend. Please try again shortly.",
            recoverable=True,
        )
    except RedisError as e:
        logger.error(f"Redis error while registering server_id: {e}")
        raise JoinError(
            code="REDIS_ERROR",
            message="Backend error while joining the conversation.",
            recoverable=True,
        )

    turns_key = TURNS_KEY_TEMPLATE.format(conversation_id=conversation_id)
    try:
        raw_turns = await redis_client.lrange(turns_key, 0, -1)
    except (RedisConnectionError, RedisTimeoutError) as e:
        logger.error(f"Redis unreachable while loading history: {e}")
        raise JoinError(
            code="HISTORY_UNAVAILABLE",
            message=(
                "Connected, but couldn't load prior transcript. "
                "Live turns will still stream."
            ),
            recoverable=True,
        )
    except RedisError as e:
        logger.error(f"Redis error while loading history: {e}")
        raise JoinError(
            code="HISTORY_ERROR",
            message="Backend error while loading prior transcript.",
            recoverable=True,
        )

    turns = []
    skipped = 0
    for raw in raw_turns:
        try:
            turns.append(json.loads(raw))
        except (json.JSONDecodeError, TypeError) as e:
            skipped += 1
            logger.warning(f"Skipping malformed buffered turn for {conversation_id}: {e}")

    if skipped:
        logger.warning(
            f"Loaded {len(turns)} turn(s), skipped {skipped} malformed "
            f"for conv: {conversation_id}"
        )
    else:
        logger.info(f"Loaded {len(turns)} buffered turn(s) for conv: {conversation_id}")

    return turns


async def leave_conversation(conversation_id: str):
    """
    Called when the last client disconnects: clears the server_id key so the
    interpreter correctly reports 'no active viewer' instead of routing
    to a connection that no longer exists.
    """
    try:
        await redis_client.delete(conversation_id)
        logger.info(f"Cleared server_id for conv: {conversation_id}")
    except (RedisConnectionError, RedisTimeoutError) as e:
        # Not fatal — TTL on the key will eventually clear the stale pointer.
        logger.error(
            f"Redis unreachable during leave for {conversation_id} "
            f"(TTL will clean up): {e}"
        )
    except Exception as e:
        logger.error(f"Failed to clear server_id for conv {conversation_id}: {e}")


# ─── CCAI Production Payload Builders ─────────────────────────────────────────
# (unchanged — kept for the mock stream / future real-data shaping)

def build_conversation_lifecycle_payload(conversation_id: str, event_type: str) -> dict:
    return {
        "conversation": build_conversation_name(conversation_id),
        "type": event_type,
    }


def build_new_recognition_result_payload(
    conversation_id: str,
    participant_id: str,
    participant_role: str,
    transcript: str,
    is_final: bool,
    confidence: float,
    message_id: str,
) -> dict:
    return {
        "conversation": build_conversation_name(conversation_id),
        "participant": build_participant_name(conversation_id, participant_id),
        "participantRole": participant_role,
        "newRecognitionResult": {
            "messageId": message_id,
            "transcript": transcript,
            "isFinal": is_final,
            "confidence": confidence,
            "languageCode": "en-US",
            "speechWordInfo": [],
        },
    }


def build_new_message_payload(
    conversation_id: str,
    participant_id: str,
    participant_role: str,
    message_id: str,
    content: str,
) -> dict:
    return {
        "conversation": build_conversation_name(conversation_id),
        "newMessagePayload": {
            "name": f"projects/{PROJECT_ID}/locations/{LOCATION}/conversations/{conversation_id}/messages/{message_id}",
            "content": content,
            "languageCode": "en-US",
            "participant": build_participant_name(conversation_id, participant_id),
            "participantRole": participant_role,
            "createTime": now_iso(),
        },
    }


def build_agent_assist_payload(
    conversation_id: str,
    participant_id: str,
    suggestions: list,
) -> dict:
    return {
        "conversation": build_conversation_name(conversation_id),
        "participant": build_participant_name(conversation_id, participant_id),
        "humanAgentAssistantEvent": {
            "suggestionResults": [
                {
                    "suggestArticlesResponse": {
                        "articleAnswers": [
                            {
                                "title": s["title"],
                                "uri": s["uri"],
                                "snippets": [s["snippet"]],
                                "confidence": s["confidence"],
                            }
                            for s in suggestions
                        ]
                    }
                }
            ]
        },
    }


# ─── Connection Manager ────────────────────────────────────────────────────────

class ConnectionManager:
    def __init__(self):
        self.active: Dict[str, Set[WebSocket]] = {}

    async def connect(self, conversation_id: str, websocket: WebSocket):
        await websocket.accept()
        if conversation_id not in self.active:
            self.active[conversation_id] = set()
        self.active[conversation_id].add(websocket)
        logger.info(
            f"WS connected | conv: {conversation_id} "
            f"| clients: {len(self.active[conversation_id])}"
        )

    def disconnect(self, conversation_id: str, websocket: WebSocket):
        if conversation_id in self.active:
            self.active[conversation_id].discard(websocket)
            if not self.active[conversation_id]:
                del self.active[conversation_id]
        logger.info(f"WS disconnected | conv: {conversation_id}")

    async def broadcast(self, conversation_id: str, message: dict):
        if conversation_id not in self.active:
            return
        dead = set()
        for ws in self.active[conversation_id]:
            try:
                await ws.send_json(message)
            except WebSocketDisconnect:
                logger.info(f"Broadcast target already disconnected | conv: {conversation_id}")
                dead.add(ws)
            except Exception as e:
                logger.error(
                    f"Broadcast send failed | conv: {conversation_id} | err: {e}"
                )
                dead.add(ws)
        for ws in dead:
            self.active[conversation_id].discard(ws)

    def is_active(self, conversation_id: str) -> bool:
        return conversation_id in self.active and len(self.active[conversation_id]) > 0


manager = ConnectionManager()


# ─── Health ────────────────────────────────────────────────────────────────────

@app.get("/")
async def health():
    """
    Health endpoint reports Redis reachability so upstream monitoring can
    distinguish 'service up but backend down' from 'service down'.
    Also reports auth_enabled and server_id so the deployed state is
    verifiable without inspecting the pod spec.
    """
    redis_status = "unknown"
    try:
        pong = await redis_client.ping()
        redis_status = "connected" if pong else "no-response"
    except (RedisConnectionError, RedisTimeoutError) as e:
        redis_status = f"unreachable: {e}"
    except Exception as e:
        redis_status = f"error: {e}"

    return JSONResponse({
        "status": "ui-connector running",
        "auth_enabled": AUTH_ENABLED,
        "server_id": await get_server_id(),
        "redis": redis_status,
        "active_conversations": list(manager.active.keys()),
        "time": now_iso(),
    })


# ─── WebSocket ─────────────────────────────────────────────────────────────────

@app.websocket("/ws")
async def websocket_endpoint(
    websocket: WebSocket,
    conversation_id: str = Query(None, description="CCAI Conversation ID"),
    access_token: str = Query(None, description="Identity token (query param — browser WS clients cannot set headers)"),
):
    """
    Frontend connects here to receive live transcript events.
    URL: wss://<host>/ws?conversation_id=<id>&access_token=<token>

    Auth: the token is validated BEFORE the socket joins a conversation.
    When AUTH_ENABLED=false the token param is ignored (dev/testing).
    Rejections use close code 1008 (policy violation) with a structured
    ERROR event first, matching the existing frontend error contract.
    """
    # ── Validate query params BEFORE joining ─────────────────────────────────
    if not conversation_id or not conversation_id.strip():
        # Have to accept first to send a structured close reason on some clients.
        await websocket.accept()
        await send_error(
            websocket,
            code="MISSING_CONVERSATION_ID",
            message="Query parameter 'conversation_id' is required.",
            conversation_id=None,
            recoverable=False,
        )
        await websocket.close(
            code=WS_CLOSE_POLICY_VIOLATION,
            reason="Missing conversation_id",
        )
        return

    if AUTH_ENABLED and (not access_token or not access_token.strip()):
        await websocket.accept()
        await send_error(
            websocket,
            code="MISSING_ACCESS_TOKEN",
            message="Query parameter 'access_token' is required.",
            conversation_id=conversation_id,
            recoverable=False,
        )
        await websocket.close(
            code=WS_CLOSE_POLICY_VIOLATION,
            reason="Missing access_token",
        )
        return

    if not await verify_access_token(access_token):
        await websocket.accept()
        await send_error(
            websocket,
            code="INVALID_ACCESS_TOKEN",
            message="Access token is invalid or expired.",
            conversation_id=conversation_id,
            recoverable=False,
        )
        await websocket.close(
            code=WS_CLOSE_POLICY_VIOLATION,
            reason="Invalid access_token",
        )
        return

    # NOTE: never log the token itself — it lands in Cloud Logging otherwise.
    logger.info(f"Auth OK (auth_enabled={AUTH_ENABLED}) | conv: {conversation_id}")

    await manager.connect(conversation_id, websocket)
    stream_task: asyncio.Task = None

    try:
        # ── join-conversation: register server_id + replay buffered history ──
        try:
            buffered_turns = await join_conversation(conversation_id)
        except JoinError as je:
            await send_error(
                websocket,
                code=je.code,
                message=je.message,
                conversation_id=conversation_id,
                recoverable=je.recoverable,
            )
            # Backend unusable → close so the client can retry with backoff.
            await websocket.close(
                code=WS_CLOSE_TRY_AGAIN_LATER,
                reason=je.code,
            )
            return
        except Exception as e:
            logger.exception(
                f"Unexpected error during join | conv: {conversation_id}: {e}"
            )
            await send_error(
                websocket,
                code="INTERNAL_ERROR",
                message="Unexpected error while joining the conversation.",
                conversation_id=conversation_id,
                recoverable=False,
            )
            await websocket.close(
                code=WS_CLOSE_INTERNAL_ERROR,
                reason="Join failed",
            )
            return

        # ── Send history batch (even if empty, so client knows join succeeded) ──
        try:
            await websocket.send_json({
                "type": EVENT_HISTORY_BATCH,
                "conversationId": conversation_id,
                "turns": buffered_turns,
                "totalTurns": len(buffered_turns),
                "timestamp": now_iso(),
            })
            logger.info(
                f"Sent HISTORY_BATCH ({len(buffered_turns)} turns) "
                f"| conv: {conversation_id}"
            )
        except WebSocketDisconnect:
            logger.info(f"Client disconnected before HISTORY_BATCH | conv: {conversation_id}")
            return

        # ── live stream: forward future Redis-published turns over this socket ──
        stream_task = asyncio.create_task(redis_listener(conversation_id, websocket))

        # ── main receive loop: keep the socket alive, log inbound pings/msgs ─
        while True:
            try:
                data = await websocket.receive_text()
                logger.info(f"Client message | conv: {conversation_id} | data: {data}")
            except WebSocketDisconnect:
                logger.info(f"Client disconnected | conv: {conversation_id}")
                break

    except Exception as e:
        # Last-resort catch so a bug can't leak an unhandled exception up into
        # the ASGI layer and drop the socket without a reason.
        logger.exception(
            f"Unhandled WS error | conv: {conversation_id}: {e}"
        )
        await send_error(
            websocket,
            code="INTERNAL_ERROR",
            message="An unexpected error occurred.",
            conversation_id=conversation_id,
            recoverable=False,
        )
        try:
            await websocket.close(
                code=WS_CLOSE_INTERNAL_ERROR,
                reason="Internal error",
            )
        except Exception:
            pass

    finally:
        if stream_task and not stream_task.done():
            stream_task.cancel()
            try:
                await stream_task
            except (asyncio.CancelledError, Exception):
                pass

        manager.disconnect(conversation_id, websocket)

        # Only clear server_id if NO other clients remain on this conversation —
        # otherwise we'd kill routing for a viewer who's still connected.
        if not manager.is_active(conversation_id):
            await leave_conversation(conversation_id)


# ─── Conversation Status ───────────────────────────────────────────────────────

@app.get("/conversation-status")
async def conversation_status(conversation_id: str = Query(None)):
    """Check if a conversation has active WebSocket clients."""
    if not conversation_id or not conversation_id.strip():
        raise HTTPException(
            status_code=400,
            detail="Query parameter 'conversation_id' is required.",
        )

    return JSONResponse({
        "conversation_id": conversation_id,
        "full_conversation_name": build_conversation_name(conversation_id),
        "active": manager.is_active(conversation_id),
        "connected_clients": len(manager.active.get(conversation_id, set())),
        "timestamp": now_iso(),
    })
